const { EmbedBuilder } = require('discord.js');
const { getTopUsers } = require('../database');

module.exports = {
  name: 'ranking',
  description: 'Mostra o ranking de cristais do servidor',
  aliases: ['rank', 'top', 'leaderboard'],
  async execute(message, args, client) {
    const topUsers = await getTopUsers(message.guild.id, 10);
    
    if (topUsers.length === 0) {
      return message.reply('Ainda não há usuários no ranking!');
    }
    
    const medals = ['🥇', '🥈', '🥉'];
    
    let description = '';
    
    for (let i = 0; i < topUsers.length; i++) {
      const user = topUsers[i];
      const medal = medals[i] || `**${i + 1}.**`;
      const member = await message.guild.members.fetch(user.user_id).catch(() => null);
      const username = member ? member.user.tag : 'Usuário Desconhecido';
      
      description += `${medal} ${username} - \`${user.cristais.toLocaleString('pt-BR')}\` 💎\n`;
    }
    
    const embed = new EmbedBuilder()
      .setColor(0xFF00FF)
      .setTitle(`🏆 Ranking de Cristais - ${message.guild.name}`)
      .setDescription(description)
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: `Top ${topUsers.length} usuários` });

    await message.reply({ embeds: [embed] });
  },
};
