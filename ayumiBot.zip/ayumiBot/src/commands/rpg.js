const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateRPGStats, addInventoryItem, updateLastFight, updateMoedas, addBossBounty } = require('../database');
const items = require('../utils/items');
const attacks = require('../utils/attacks');

const ENEMIES = [
  { name: 'Goblin Fraco', maxHp: 40, attack: 5, defense: 2, exp: 10, moedas: 50, emoji: '👹', drop: 'goblin_fang' },
  { name: 'Orc', maxHp: 70, attack: 10, defense: 4, exp: 15, moedas: 100, emoji: '🐵', drop: 'orc_horn' },
  { name: 'Dragão Pequeno', maxHp: 120, attack: 15, defense: 6, exp: 25, moedas: 200, emoji: '🐉', drop: 'dragon_scale' },
  { name: 'Skeleton Knight', maxHp: 90, attack: 12, defense: 5, exp: 20, moedas: 150, emoji: '💀', drop: 'skeleton_bone' },
  { name: 'Bruxa', maxHp: 70, attack: 18, defense: 3, exp: 18, moedas: 120, emoji: '🧙', drop: 'witch_essence' },
];

const ATTACK_KEYS = ['golpe_basico', 'ataque_forte', 'defesa_agil', 'golpe_critico', 'regeneracao'];
const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

function getHpBar(current, max) {
  const percentage = Math.max(0, Math.min(100, (current / max) * 100));
  const filled = Math.floor(percentage / 10);
  const bar = '🟥'.repeat(filled) + '⬜'.repeat(10 - filled);
  return `${bar} ${current}/${max}`;
}

async function executeInteractiveBattle(message, enemy, user) {
  const color = COLORS[Math.floor(Math.random() * COLORS.length)];
  let playerHp = user.rpg_health;
  let enemyHp = enemy.maxHp;
  let battleLog = [];
  let gameActive = true;
  
  // Penalidade de fome
  let playerAttack = user.rpg_attack;
  let playerDefense = user.rpg_defense;
  let hungerWarning = '';
  
  if (user.hunger < 5) {
    playerAttack = Math.floor(playerAttack * 0.7); // -30% de ataque
    playerDefense = Math.floor(playerDefense * 0.7); // -30% de defesa
    hungerWarning = '\n⚠️ **Você está muito faminto! Ataque e defesa -30%!**';
    battleLog.push('⚠️ Você está muito fraco de fome...');
  }

  while (gameActive && playerHp > 0 && enemyHp > 0) {
    // Criar botões de ataques
    const buttons = ATTACK_KEYS.map((key, idx) => {
      const attack = attacks[key];
      return new ButtonBuilder()
        .setCustomId(`attack_${key}`)
        .setLabel(`${attack.emoji} ${attack.name}`)
        .setStyle(ButtonStyle.Primary);
    });

    const rows = [];
    for (let i = 0; i < buttons.length; i += 2) {
      rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 2)));
    }

    const battleEmbed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`⚔️ Batalha contra ${enemy.emoji} ${enemy.name}`)
      .addFields(
        { name: '🧑 Seu HP', value: getHpBar(playerHp, user.rpg_health), inline: false },
        { name: `${enemy.emoji} ${enemy.name}`, value: getHpBar(enemyHp, enemy.maxHp), inline: false },
        { name: 'Escolha seu ataque:', value: `Clique em um botão abaixo${hungerWarning}`, inline: false }
      )
      .setTimestamp();

    const response = await message.reply({ embeds: [battleEmbed], components: rows });

    // Coletor de interações
    const filter = (interaction) => interaction.user.id === message.author.id && interaction.customId.startsWith('attack_');
    const collector = response.createMessageComponentCollector({ filter, time: 30000 });

    await new Promise((resolve) => {
      collector.on('collect', async (interaction) => {
        const attackKey = interaction.customId.replace('attack_', '');
        const attack = attacks[attackKey];

        // Jogador ataca
        let playerDamage = 0;
        if (Math.random() * 100 <= attack.accuracy) {
          if (attack.healing) {
            playerDamage = attack.getHealing(user.rpg_health);
            playerHp = Math.min(user.rpg_health, playerHp + playerDamage);
            battleLog.push(`💚 **Você usou ${attack.name}** e recuperou ${playerDamage}❤️`);
          } else {
            playerDamage = attack.calculateDamage(playerAttack, enemy.defense);
            enemyHp -= playerDamage;
            battleLog.push(`⚔️ **Você usou ${attack.name}** e causou ${playerDamage} de dano! ${enemy.emoji} agora tem ${Math.max(0, enemyHp)}❤️`);
          }
        } else {
          battleLog.push(`❌ **Você usou ${attack.name}** mas errou!`);
        }

        if (enemyHp <= 0) {
          gameActive = false;
          collector.stop();
          resolve();
          return;
        }

        // Inimigo ataca
        const enemyAttackKey = ATTACK_KEYS[Math.floor(Math.random() * ATTACK_KEYS.length)];
        const enemyAttack = attacks[enemyAttackKey];
        let enemyDamage = 0;

        if (Math.random() * 100 <= enemyAttack.accuracy) {
          if (enemyAttack.healing) {
            enemyDamage = enemyAttack.getHealing(enemy.maxHp);
            enemyHp = Math.min(enemy.maxHp, enemyHp + enemyDamage);
            battleLog.push(`💚 **${enemy.name} usou ${enemyAttack.name}** e recuperou ${enemyDamage}❤️`);
          } else {
            enemyDamage = enemyAttack.calculateDamage(enemy.attack, playerDefense);
            playerHp -= enemyDamage;
            battleLog.push(`💢 **${enemy.name} usou ${enemyAttack.name}** e causou ${enemyDamage} de dano! Você agora tem ${Math.max(0, playerHp)}❤️`);
          }
        } else {
          battleLog.push(`❌ **${enemy.name} usou ${enemyAttack.name}** mas errou!`);
        }

        if (playerHp <= 0) {
          gameActive = false;
          collector.stop();
          resolve();
          return;
        }

        await interaction.deferUpdate();
        collector.resetTimer();
      });

      collector.on('end', () => {
        resolve();
      });
    });
  }

  await updateLastFight(message.author.id, message.guildId);

  let resultTitle = '';
  let resultColor = '';
  let rewards = 0;
  let moedas = 0;
  let loot = [];

  if (playerHp > 0) {
    resultTitle = `🎉 Você Venceu contra ${enemy.emoji} ${enemy.name}!`;
    resultColor = '#00FF00';
    rewards = enemy.exp;
    moedas = Math.floor(enemy.moedas * user.multiplicador_moedas);

    const newExp = user.rpg_exp + rewards;
    const reqExpForNextLevel = user.rpg_level * 150 + 100;
    const levelUp = newExp >= reqExpForNextLevel;

    let finalLevel = user.rpg_level;
    let finalExp = newExp;
    if (levelUp) {
      finalLevel = user.rpg_level + 1;
      finalExp = newExp - reqExpForNextLevel;
    }

    await updateRPGStats(message.author.id, message.guildId, {
      health: user.rpg_max_health,
      exp: finalExp,
      level: finalLevel,
      attack: 10 + (finalLevel - 1) * 1,
      defense: 5 + Math.floor((finalLevel - 1) * 0.8),
      max_health: 100 + (finalLevel - 1) * 3
    });

    await updateMoedas(message.author.id, message.guildId, moedas);

    // Drop do item específico (40% de chance)
    if (enemy.drop && Math.random() < 0.4) {
      const dropItem = items[enemy.drop];
      await addInventoryItem(message.author.id, message.guildId, enemy.drop);
      loot.push(`${dropItem.emoji} ${dropItem.name}`);
    }

    if (levelUp) {
      resultTitle = `🎉 Nível UP! Você chegou ao nível ${newLevel}!`;
    }
  } else {
    resultTitle = `💀 Você Perdeu para ${enemy.emoji} ${enemy.name}!`;
    resultColor = '#FF0000';
    const newHp = Math.max(10, user.rpg_health - 10);
    await updateRPGStats(message.author.id, message.guildId, { health: newHp });
  }

  const logText = battleLog.slice(-8).join('\n') || 'Batalha terminou...';
  const lootText = loot.length > 0 ? `\n**Loot:** ${loot.join(', ')}` : '';
  const updatedUser = await getUser(message.author.id, message.guildId);

  const embed = new EmbedBuilder()
    .setColor(resultColor || color)
    .setTitle(resultTitle)
    .addFields(
      { name: '⚔️ Resumo da Batalha', value: logText, inline: false },
      playerHp > 0
        ? { name: '🏆 Recompensas', value: `\`${rewards}\` EXP • \`${moedas}\` 🪙${lootText}`, inline: false }
        : { name: '😢 Derrota', value: `Você perdeu 10❤️ permanentemente!`, inline: false },
      { name: '📊 Multiplicador', value: `\`${updatedUser.multiplicador_moedas.toFixed(1)}x\` (${updatedUser.bosses_derrotados} bosses)`, inline: false }
    )
    .setTimestamp();

  await message.reply({ embeds: [embed] });
}

module.exports = {
  name: 'lutar',
  description: 'Lute contra um inimigo aleatório com sistema Pokémon',
  aliases: ['fight', 'battle', 'batalha', 'inimigo', 'combat'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);

    if (!user.rpg_class) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você precisa de um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem primeiro!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // Cooldown de 5 minutos
    if (user.last_fight) {
      const lastFightTime = new Date(user.last_fight).getTime();
      const timeLeft = (5 * 60 * 1000) - (Date.now() - lastFightTime);
      if (timeLeft > 0) {
        const minutes = Math.ceil(timeLeft / 60000);
        const embed = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏳ Você está cansado!')
          .setDescription(`Aguarde ${minutes} minuto${minutes > 1 ? 's' : ''} antes de lutar contra um inimigo novamente.\n\n💡 Você ainda pode desafiar um boss com \`ay.enfrentarboss\`!`)
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      }
    }

    const enemy = ENEMIES[Math.floor(Math.random() * ENEMIES.length)];
    await executeInteractiveBattle(message, enemy, user);
  },
};
