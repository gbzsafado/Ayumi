const { EmbedBuilder } = require('discord.js');
const { getUser, updateCristais, updateLastDaily, getPrefix } = require('../database');

module.exports = {
  name: 'daily',
  description: 'Receba sua recompensa diária',
  aliases: ['diario'],
  async execute(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const prefix = await getPrefix(guildId);
    const userData = await getUser(userId, guildId);
    
    const now = new Date();
    const lastDaily = userData.last_daily ? new Date(userData.last_daily) : null;
    
    if (lastDaily) {
      const timeDiff = now - lastDaily;
      const hoursLeft = 24 - (timeDiff / (1000 * 60 * 60));
      
      if (hoursLeft > 0) {
        const hours = Math.floor(hoursLeft);
        const minutes = Math.floor((hoursLeft - hours) * 60);
        
        const embed = new EmbedBuilder()
          .setColor(0xEE82EE)
          .setTitle('⏰ Aguarde!')
          .setDescription(`Você já coletou sua recompensa diária!\nVolte em **${hours}h ${minutes}m**`)
          .setTimestamp();
        
        return message.reply({ embeds: [embed] });
      }
    }
    
    const reward = Math.floor(Math.random() * 500) + 500;
    
    await updateCristais(userId, guildId, reward);
    await updateLastDaily(userId, guildId);
    
    const newBalance = Number(userData.cristais) + reward;
    
    const embed = new EmbedBuilder()
      .setColor(0xEE82EE)
      .setTitle('🎁 Recompensa Diária!')
      .setDescription(`Você recebeu **${reward.toLocaleString('pt-BR')}** 💎 cristais!`)
      .addFields(
        { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` cristais`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Use ${prefix}daily para coletar amanhã!` });

    await message.reply({ embeds: [embed] });
  },
};
