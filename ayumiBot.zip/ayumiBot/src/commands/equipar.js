const { EmbedBuilder } = require('discord.js');
const { getInventory, pool } = require('../database');
const items = require('../utils/items');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'equipar',
  description: 'Equipar ou desequipar um item',
  aliases: ['equip'],
  async execute(message, args) {
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (!args[0]) {
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('❌ Erro')
        .setDescription('Use: `ay.equipar <nome do item>`')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const itemName = args.join(' ').toLowerCase();
    const inventory = await getInventory(message.author.id, message.guildId);

    // Encontrar item no inventário
    let itemToEquip = null;
    let itemId = null;

    for (const [id, item] of Object.entries(items)) {
      if (item.name.toLowerCase() === itemName) {
        const invItem = inventory.find(i => i.item_id === id);
        if (invItem) {
          itemToEquip = item;
          itemId = id;
          break;
        }
      }
    }

    if (!itemToEquip) {
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('❌ Item não encontrado')
        .setDescription('Você não tem esse item no inventário!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // Alternar equip
    const invItem = inventory.find(i => i.item_id === itemId);
    const willEquip = !invItem.equipped;

    await pool.query(
      'UPDATE rpg_inventory SET equipped = $1 WHERE user_id = $2 AND guild_id = $3 AND item_id = $4',
      [willEquip, message.author.id, message.guildId, itemId]
    );

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(willEquip ? '✅ Item Equipado' : '📦 Item Desequipado')
      .setDescription(`${itemToEquip.emoji} **${itemToEquip.name}** ${willEquip ? 'foi equipado!' : 'foi desequipado!'}`)
      .setFooter({ text: itemToEquip.description })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
