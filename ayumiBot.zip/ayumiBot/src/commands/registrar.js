const { EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { isCharacterRegistered, registerCharacter, getUser } = require('../database');
const classes = require('../utils/classes');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'registrar',
  description: 'Registre seu personagem de RPG com uma classe',
  aliases: ['criar', 'create', 'newchar'],
  async execute(message, args) {
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const isRegistered = await isCharacterRegistered(message.author.id, message.guildId);

    if (isRegistered) {
      const user = await getUser(message.author.id, message.guildId);
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você já tem um personagem!')
        .setDescription(`Seu personagem **${user.character_name}** é um ${classes[user.rpg_class].name}`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // Criar select menu com as classes
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('class_select')
      .setPlaceholder('Escolha sua classe')
      .addOptions(
        Object.entries(classes).map(([key, classData]) => ({
          label: classData.name,
          value: key,
          description: classData.bonus,
          emoji: classData.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('⚔️ Criação de Personagem RPG')
      .setDescription('Bem-vindo ao mundo dos RPG! Escolha sua classe:')
      .addFields(
        { name: '⚔️ Guerreiro', value: 'Ataque +20%', inline: true },
        { name: '🔮 Mago', value: 'Ataque Mágico +25%', inline: true },
        { name: '🛡️ Cavaleiro', value: 'Defesa +40%', inline: true },
        { name: '🏹 Arqueiro', value: 'Crítico +15%', inline: true },
        { name: '✨ Clérigo', value: 'Regeneração +5%', inline: true },
        { name: '🗡️ Assassino', value: 'Crítico +30%', inline: true }
      )
      .setTimestamp();

    const msg = await message.reply({ embeds: [embed], components: [row] });

    // Listener para a seleção
    const filter = (interaction) => interaction.customId === 'class_select' && interaction.user.id === message.author.id;
    const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
      const selectedClass = interaction.values[0];

      // Mostrar modal para nome do personagem
      const modal = new ModalBuilder()
        .setCustomId('character_name_modal')
        .setTitle('Nome do Personagem')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('char_name_input')
              .setLabel('Digite o nome do seu personagem')
              .setStyle(TextInputStyle.Short)
              .setMinLength(3)
              .setMaxLength(20)
              .setPlaceholder('ex: Aragorn, Gandalf...')
          )
        );

      await interaction.showModal(modal);

      // Listener para o modal
      const modalFilter = (modalInt) => modalInt.customId === 'character_name_modal' && modalInt.user.id === message.author.id;
      
      try {
        const modalSubmission = await interaction.awaitModalSubmit({ filter: modalFilter, time: 300000 });
        const characterName = modalSubmission.fields.getTextInputValue('char_name_input');

        // Registrar o personagem
        await registerCharacter(message.author.id, message.guildId, characterName, selectedClass);

        const classData = classes[selectedClass];
        const resultEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Personagem Criado com Sucesso!')
          .setThumbnail(message.author.displayAvatarURL())
          .addFields(
            { name: '📛 Nome', value: `\`${characterName}\``, inline: true },
            { name: '🎭 Classe', value: classData.name, inline: true },
            { name: '📈 Bônus', value: classData.bonus, inline: false },
            { name: '⚔️ Ataque', value: `\`${classData.attack}\``, inline: true },
            { name: '🛡️ Defesa', value: `\`${classData.defense}\``, inline: true },
            { name: '❤️ HP', value: `\`${classData.health}\``, inline: true }
          )
          .setFooter({ text: 'Use ay.rpg para ver seus stats! Use ay.lutar para começar uma aventura!' })
          .setTimestamp();

        await modalSubmission.reply({ embeds: [resultEmbed] });
        collector.stop();
      } catch (error) {
        console.error('Erro ao aguardar modal:', error);
      }
    });

    collector.on('end', (collected) => {
      if (collected.size === 0) {
        message.edit({ components: [] }).catch(() => {});
      }
    });
  },
};
