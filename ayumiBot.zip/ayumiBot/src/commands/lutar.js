const { EmbedBuilder } = require('discord.js');
const { getUser, updateRPGStats, addInventoryItem, updateLastFight } = require('../database');
const items = require('../utils/items');

const ENEMIES = [
  { name: 'Goblin Fraco', maxHp: 30, attack: 5, defense: 2, exp: 25, emoji: '👹' },
  { name: 'Orc', maxHp: 50, attack: 10, defense: 4, exp: 50, emoji: '🐵' },
  { name: 'Dragão Pequeno', maxHp: 80, attack: 15, defense: 6, exp: 100, emoji: '🐉' },
  { name: 'Skeleton Knight', maxHp: 60, attack: 12, defense: 5, exp: 75, emoji: '💀' },
  { name: 'Bruxa', maxHp: 45, attack: 18, defense: 3, exp: 60, emoji: '🧙' },
];

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'lutar',
  description: 'Lute contra um inimigo aleatório',
  aliases: ['fight', 'battle', 'batalha'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    // Cooldown de 5 minutos
    if (user.last_fight) {
      const lastFightTime = new Date(user.last_fight).getTime();
      const timeLeft = (5 * 60 * 1000) - (Date.now() - lastFightTime);
      if (timeLeft > 0) {
        const minutes = Math.ceil(timeLeft / 60000);
        const embed = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏳ Você está cansado!')
          .setDescription(`Aguarde ${minutes} minuto${minutes > 1 ? 's' : ''} antes de lutar novamente.`)
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      }
    }

    const enemy = ENEMIES[Math.floor(Math.random() * ENEMIES.length)];
    let playerHp = user.rpg_health;
    let enemyHp = enemy.maxHp;
    let round = 0;
    let battleLog = [];

    // Simular batalha
    while (playerHp > 0 && enemyHp > 0 && round < 20) {
      round++;

      // Ataque do jogador
      const playerDamage = Math.max(1, user.rpg_attack - Math.floor(Math.random() * enemy.defense));
      enemyHp -= playerDamage;
      battleLog.push(`**Round ${round}:** Você ataca por ${playerDamage} dano! ${enemy.emoji} ${enemy.name} agora tem ${Math.max(0, enemyHp)}❤️`);

      if (enemyHp <= 0) break;

      // Ataque do inimigo
      const enemyDamage = Math.max(1, enemy.attack - Math.floor(Math.random() * user.rpg_defense));
      playerHp -= enemyDamage;
      battleLog.push(`${enemy.emoji} ${enemy.name} ataca por ${enemyDamage} dano! Você agora tem ${Math.max(0, playerHp)}❤️`);
    }

    await updateLastFight(message.author.id, message.guildId);

    let resultTitle = '';
    let resultColor = '';
    let rewards = 0;
    let loot = [];

    if (playerHp > 0) {
      resultTitle = `🎉 Você Venceu contra ${enemy.emoji} ${enemy.name}!`;
      resultColor = '#00FF00';
      rewards = enemy.exp;
      
      // Adicionar EXP e cristais
      const newExp = user.rpg_exp + rewards;
      const newLevel = Math.floor(newExp / 100) + 1;
      const levelUp = newLevel > user.rpg_level;

      await updateRPGStats(message.author.id, message.guildId, {
        health: user.rpg_max_health, // Full heal after battle
        exp: newExp % 100,
        level: newLevel,
        attack: 10 + (newLevel - 1) * 2,
        defense: 5 + (newLevel - 1),
        max_health: 100 + (newLevel - 1) * 5
      });

      // Loot aleatório
      if (Math.random() < 0.4) {
        const lootItems = Object.entries(items).filter(([_, item]) => item.rarity && item.rarity !== 'consumable');
        const randomLoot = lootItems[Math.floor(Math.random() * lootItems.length)];
        if (randomLoot) {
          await addInventoryItem(message.author.id, message.guildId, randomLoot[0]);
          loot.push(`${randomLoot[1].emoji} ${randomLoot[1].name}`);
        }
      }

      resultTitle = levelUp ? `🎉 Nível UP! Você chegou ao nível ${newLevel}!` : `🎉 Você Venceu!`;
    } else {
      resultTitle = `💀 Você Perdeu para ${enemy.emoji} ${enemy.name}!`;
      resultColor = '#FF0000';
      
      // Perder um pouco de HP permanente
      const newHp = Math.max(10, user.rpg_health - 10);
      await updateRPGStats(message.author.id, message.guildId, { health: newHp });
    }

    const logText = battleLog.slice(-5).join('\n') || 'Batalha terminou...';
    const lootText = loot.length > 0 ? `\n**Loot:** ${loot.join(', ')}` : '';

    const embed = new EmbedBuilder()
      .setColor(resultColor || color)
      .setTitle(resultTitle)
      .addFields(
        { name: '⚔️ Resumo da Batalha', value: logText, inline: false },
        playerHp > 0
          ? { name: '🏆 Recompensas', value: `\`${rewards}\` EXP${lootText}`, inline: false }
          : { name: '😢 Derrota', value: `Você perdeu 10❤️ permanentemente!`, inline: false }
      )
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
