const { EmbedBuilder } = require('discord.js');
const { getUser, updateHunger, updateLastHunt, updateMoedas } = require('../database');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

const HUNT_RESULTS = [
  { success: true, emoji: '🐇', prey: 'Coelho', hunger_restore: 3, moedas: 30 },
  { success: true, emoji: '🦌', prey: 'Veado', hunger_restore: 4, moedas: 50 },
  { success: true, emoji: '🐗', prey: 'Javali', hunger_restore: 5, moedas: 80 },
  { success: true, emoji: '🦅', prey: 'Águia', hunger_restore: 3, moedas: 40 },
  { success: false, emoji: '🐻', prey: 'Urso', hunger_restore: 0, moedas: -20 },
];

function getHungerBar(current, max) {
  const filled = Math.floor((current / max) * 10);
  const bar = '🟩'.repeat(filled) + '⬜'.repeat(10 - filled);
  return `${bar} ${current}/${max}`;
}

module.exports = {
  name: 'caca',
  description: 'Caçar comida para restaurar sua fome',
  aliases: ['hunt', 'caçar'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (!user.rpg_class) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você precisa de um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem primeiro!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // Cooldown de 10 minutos
    if (user.last_hunt) {
      const lastHuntTime = new Date(user.last_hunt).getTime();
      const timeLeft = (10 * 60 * 1000) - (Date.now() - lastHuntTime);
      if (timeLeft > 0) {
        const minutes = Math.ceil(timeLeft / 60000);
        const embed = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏳ Você está cansado de caçar!')
          .setDescription(`Aguarde ${minutes} minuto${minutes > 1 ? 's' : ''} antes de caçar novamente.`)
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      }
    }

    const result = HUNT_RESULTS[Math.floor(Math.random() * HUNT_RESULTS.length)];
    let newHunger = Math.min(10, user.hunger + result.hunger_restore);
    let newMoedas = user.moedas;

    if (result.success) {
      newMoedas = Math.max(0, user.moedas + result.moedas);
      await updateMoedas(message.author.id, message.guildId, result.moedas);
    } else {
      newMoedas = Math.max(0, user.moedas + result.moedas);
      if (result.moedas < 0) {
        await updateMoedas(message.author.id, message.guildId, result.moedas);
      }
    }

    await updateHunger(message.author.id, message.guildId, newHunger);
    await updateLastHunt(message.author.id, message.guildId);

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(result.success ? `🎯 Caça Bem-Sucedida!` : `😰 Encontrou um Predador!`);

    if (result.success) {
      embed.setDescription(`Você conseguiu caçar um ${result.emoji} **${result.prey}**!`)
        .addFields(
          { name: '🍖 Comida Obtida', value: `+${result.hunger_restore} fome`, inline: true },
          { name: '🪙 Moedas', value: `+${result.moedas} 🪙`, inline: true },
          { name: '🔥 Fome Atual', value: getHungerBar(newHunger, 10), inline: false }
        );
    } else {
      embed.setDescription(`Você encontrou um ${result.emoji} **${result.prey}** perigoso demais!\nVocê fugiu assustado e perdeu algumas moedas...`)
        .addFields(
          { name: '🪙 Moedas Perdidas', value: `${result.moedas} 🪙`, inline: false },
          { name: '🔥 Fome Atual', value: getHungerBar(user.hunger, 10), inline: false }
        );
    }

    embed.setTimestamp();
    await message.reply({ embeds: [embed] });
  },
};
