const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getUser, getShopStock, updateShopStock, getPrefix } = require('../database');
const items = require('../utils/items');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

const SHOP_ITEMS = ['sword_iron', 'sword_steel', 'shield_wooden', 'shield_iron', 'potion_health', 'potion_strength', 'amulet_power'];

module.exports = {
  name: 'loja',
  description: 'Compre itens com moedas medievais',
  aliases: ['shop', 'comprar'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const prefix = await getPrefix(message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const stock = await getShopStock(message.guildId);

    const itemsList = SHOP_ITEMS
      .map((itemId, idx) => {
        const item = items[itemId];
        const quantity = stock[itemId] || 0;
        return `**${idx + 1}.** ${item.emoji} **${item.name}** - \`500\` 🪙 (${quantity} em estoque)`;
      })
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('🛍️ Loja do Reino')
      .setDescription(`**Seu saldo:** \`${Number(user.moedas)}\` 🪙\n\n**Itens Disponíveis:**\n${itemsList}`)
      .addFields(
        { name: '📦 Sistema de Estoque', value: 'O estoque muda a cada 30 minutos! Compre antes que os itens acabem!', inline: false }
      )
      .setFooter({ text: `Use ${prefix}comprar [número] para comprar um item` })
      .setTimestamp();

    const select = new StringSelectMenuBuilder()
      .setCustomId('shop_select')
      .setPlaceholder('Escolha um item para comprar!')
      .addOptions(
        SHOP_ITEMS.map((itemId, idx) => {
          const item = items[itemId];
          const quantity = stock[itemId] || 0;
          return {
            label: `${item.name} (${quantity} em estoque)`,
            description: item.description,
            value: idx.toString(),
            emoji: item.emoji,
            disabled: quantity === 0
          };
        })
      );

    const row = new ActionRowBuilder().addComponents(select);
    const response = await message.reply({ embeds: [embed], components: [row] });

    const filter = (interaction) => interaction.user.id === message.author.id && interaction.customId === 'shop_select';
    const collector = response.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
      const selectedIdx = parseInt(interaction.values[0]);
      const itemId = SHOP_ITEMS[selectedIdx];
      const item = items[itemId];
      const currentStock = stock[itemId] || 0;

      if (currentStock === 0) {
        await interaction.reply({ content: '❌ Este item está fora de estoque!', ephemeral: true });
        return;
      }

      const updatedUser = await getUser(message.author.id, message.guildId);
      if (updatedUser.moedas < 500) {
        await interaction.reply({ content: '❌ Você não tem moedas suficientes! Precisa de 500 🪙', ephemeral: true });
        return;
      }

      await require('../database').updateMoedas(message.author.id, message.guildId, -500);
      await require('../database').addInventoryItem(message.author.id, message.guildId, itemId);
      await updateShopStock(message.guildId, itemId, -1);

      const confirmEmbed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('✅ Compra Realizada!')
        .setDescription(`Você comprou:\n${item.emoji} **${item.name}** por 500 🪙`)
        .setTimestamp();

      await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
    });

    collector.on('end', () => {
      message.edit({ components: [] }).catch(() => {});
    });
  },
};
