const { EmbedBuilder } = require('discord.js');
const { getUser, getPrefix } = require('../database');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const STOCKS = {
  'CRIS': { name: 'Cristal Corp', basePrice: 1000 },
  'MINA': { name: 'Mina Ouro', basePrice: 800 },
  'FORT': { name: 'Fortuna Inc', basePrice: 1200 },
  'MAGI': { name: 'Magia Ltd', basePrice: 1500 },
  'DRAC': { name: 'Draconium Co', basePrice: 2000 }
};

async function getOrCreateStockPrice(guildId, symbol) {
  const result = await pool.query(
    'SELECT * FROM stock_prices WHERE guild_id = $1 AND stock_symbol = $2',
    [guildId, symbol]
  );

  if (result.rows.length === 0) {
    const basePrice = STOCKS[symbol].basePrice;
    await pool.query(
      'INSERT INTO stock_prices (guild_id, stock_symbol, current_price) VALUES ($1, $2, $3)',
      [guildId, symbol, basePrice]
    );
    return basePrice;
  }

  return result.rows[0].current_price;
}

async function updateStockPrice(guildId, symbol) {
  const currentPrice = await getOrCreateStockPrice(guildId, symbol);
  const change = Math.floor((Math.random() - 0.5) * 400);
  const newPrice = Math.max(100, currentPrice + change);
  
  await pool.query(
    'UPDATE stock_prices SET current_price = $1, last_updated = CURRENT_TIMESTAMP WHERE guild_id = $2 AND stock_symbol = $3',
    [newPrice, guildId, symbol]
  );

  return newPrice;
}

async function getUserStocks(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function buyStock(userId, guildId, symbol, quantity) {
  const price = await getOrCreateStockPrice(guildId, symbol);
  const cost = price * quantity;

  const user = await getUser(userId, guildId);
  if (user.cristais < cost) {
    return { success: false, message: 'Cristais insuficientes!' };
  }

  await pool.query('UPDATE users SET cristais = cristais - $1 WHERE user_id = $2 AND guild_id = $3', [cost, userId, guildId]);

  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3',
    [userId, guildId, symbol]
  );

  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO user_stocks (user_id, guild_id, stock_symbol, quantity) VALUES ($1, $2, $3, $4)',
      [userId, guildId, symbol, quantity]
    );
  } else {
    await pool.query(
      'UPDATE user_stocks SET quantity = quantity + $1 WHERE user_id = $2 AND guild_id = $3 AND stock_symbol = $4',
      [quantity, userId, guildId, symbol]
    );
  }

  return { success: true, cost };
}

async function sellStock(userId, guildId, symbol, quantity) {
  const price = await getOrCreateStockPrice(guildId, symbol);
  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3',
    [userId, guildId, symbol]
  );

  if (result.rows.length === 0 || result.rows[0].quantity < quantity) {
    return { success: false, message: 'Você não tem essa quantidade de ações!' };
  }

  const profit = price * quantity;
  await pool.query('UPDATE users SET cristais = cristais + $1 WHERE user_id = $2 AND guild_id = $3', [profit, userId, guildId]);

  if (result.rows[0].quantity === quantity) {
    await pool.query('DELETE FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3', [userId, guildId, symbol]);
  } else {
    await pool.query(
      'UPDATE user_stocks SET quantity = quantity - $1 WHERE user_id = $2 AND guild_id = $3 AND stock_symbol = $4',
      [quantity, userId, guildId, symbol]
    );
  }

  return { success: true, profit };
}

module.exports = {
  name: 'bolsa',
  description: 'Sistema de bolsa de valores em cristais',
  aliases: ['stock', 'mercado'],
  async execute(message, args, client) {
    const prefix = await getPrefix(message.guildId);
    const userId = message.author.id;
    const guildId = message.guild.id;

    if (!args[0]) {
      // Mostrar ações disponíveis
      const prices = {};
      for (const symbol in STOCKS) {
        prices[symbol] = await getOrCreateStockPrice(guildId, symbol);
      }

      const stockList = Object.entries(prices)
        .map(([symbol, price]) => `\`${symbol}\` - ${STOCKS[symbol].name}: **${price.toLocaleString('pt-BR')}** 💎`)
        .join('\n');

      const embed = new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('📈 Bolsa de Valores')
        .setDescription('Preços das ações disponíveis:')
        .addFields(
          { name: '🏢 Ações', value: stockList, inline: false },
          { name: 'Comandos', value: `\`${prefix}bolsa comprar [SÍMBOLO] [quantidade]\`\n\`${prefix}bolsa vender [SÍMBOLO] [quantidade]\`\n\`${prefix}bolsa carteira\``, inline: false }
        )
        .setFooter({ text: 'Preços mudam a cada atividade!' })
        .setTimestamp();

      return message.reply({ embeds: [embed] });
    }

    if (args[0].toLowerCase() === 'comprar') {
      if (!args[1] || !args[2]) {
        return message.reply('❌ Use: `' + prefix + 'bolsa comprar [SÍMBOLO] [quantidade]`');
      }

      const symbol = args[1].toUpperCase();
      const quantity = parseInt(args[2]);

      if (!STOCKS[symbol]) {
        return message.reply('❌ Símbolo inválido!');
      }

      if (isNaN(quantity) || quantity <= 0) {
        return message.reply('❌ Quantidade inválida!');
      }

      const result = await buyStock(userId, guildId, symbol, quantity);
      if (!result.success) {
        return message.reply('❌ ' + result.message);
      }

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Ação Comprada!')
        .addFields(
          { name: 'Ação', value: `${STOCKS[symbol].name} (${symbol})`, inline: true },
          { name: 'Quantidade', value: `${quantity}`, inline: true },
          { name: 'Custo Total', value: `${result.cost.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setTimestamp();

      return message.reply({ embeds: [embed] });
    }

    if (args[0].toLowerCase() === 'vender') {
      if (!args[1] || !args[2]) {
        return message.reply('❌ Use: `' + prefix + 'bolsa vender [SÍMBOLO] [quantidade]`');
      }

      const symbol = args[1].toUpperCase();
      const quantity = parseInt(args[2]);

      if (!STOCKS[symbol]) {
        return message.reply('❌ Símbolo inválido!');
      }

      if (isNaN(quantity) || quantity <= 0) {
        return message.reply('❌ Quantidade inválida!');
      }

      const result = await sellStock(userId, guildId, symbol, quantity);
      if (!result.success) {
        return message.reply('❌ ' + result.message);
      }

      const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('✅ Ação Vendida!')
        .addFields(
          { name: 'Ação', value: `${STOCKS[symbol].name} (${symbol})`, inline: true },
          { name: 'Quantidade', value: `${quantity}`, inline: true },
          { name: 'Lucro', value: `${result.profit.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setTimestamp();

      return message.reply({ embeds: [embed] });
    }

    if (args[0].toLowerCase() === 'carteira') {
      const stocks = await getUserStocks(userId, guildId);

      if (stocks.length === 0) {
        return message.reply('❌ Você não tem nenhuma ação!');
      }

      let totalValue = 0;
      const stocksInfo = [];

      for (const stock of stocks) {
        const price = await getOrCreateStockPrice(guildId, stock.stock_symbol);
        const value = price * stock.quantity;
        totalValue += value;

        stocksInfo.push(`\`${stock.stock_symbol}\` - ${STOCKS[stock.stock_symbol].name}: ${stock.quantity}x @ ${price.toLocaleString('pt-BR')} 💎 = ${value.toLocaleString('pt-BR')} 💎`);
      }

      const embed = new EmbedBuilder()
        .setColor(0xBA55D3)
        .setTitle('💼 Sua Carteira')
        .setDescription(stocksInfo.join('\n'))
        .addFields(
          { name: 'Valor Total', value: `${totalValue.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp();

      return message.reply({ embeds: [embed] });
    }

    return message.reply('❌ Subcomando inválido! Use: `comprar`, `vender` ou `carteira`');
  }
};
