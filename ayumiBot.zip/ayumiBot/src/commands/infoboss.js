const { EmbedBuilder } = require('discord.js');
const { getPrefix } = require('../database');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

const BOSSES = [
  { name: 'Rei Dragão', emoji: '👑', dificuldade: 'Extrema' },
  { name: 'Arquimago Negro', emoji: '🔮', dificuldade: 'Extrema' },
  { name: 'Titã Antigo', emoji: '⛏️', dificuldade: 'Extrema' },
  { name: 'Demônio Primordial', emoji: '😈', dificuldade: 'Extrema' },
];

module.exports = {
  name: 'infoboss',
  description: 'Informações sobre os desafios de boss',
  aliases: ['bosses', 'desafios', 'boss_info'],
  async execute(message, args) {
    const prefix = await getPrefix(message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    const bossList = BOSSES
      .map((boss, idx) => `${idx + 1}. ${boss.emoji} **${boss.name}** (${boss.dificuldade})`)
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('👑 Desafios de Boss')
      .setDescription('Use `ay.enfrentarboss` para desafiar um boss aleatório!\n\n**Bosses Disponíveis:**\n' + bossList)
      .addFields(
        { name: '💡 Dicas', value: '• Cada boss derrotado aumenta seu multiplicador de moedas em +0.1x\n• Bosses são muito mais difíceis que inimigos normais\n• Prepare-se bem antes de enfrentar um boss!', inline: false },
        { name: '🪙 Recompensas', value: '• Moedas: Baseado no multiplicador (1000+ moedas por boss)\n• EXP: Muito mais do que inimigos normais\n• Progresso: Aumento permanente de multiplicador', inline: false }
      )
      .setFooter({ text: `Use ${prefix}enfrentarboss para desafiar um boss!` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
