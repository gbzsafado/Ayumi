const { EmbedBuilder } = require('discord.js');
const { getUser, getInventory, addInventoryItem, removeInventoryItem } = require('../database');
const items = require('../utils/items');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'craft',
  description: 'Craft um item usando materiais',
  aliases: ['craftear', 'confeccionar', 'fazer'],
  async execute(message, args) {
    if (!args[0]) {
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];
      const craftableItems = Object.entries(items).filter(([_, item]) => item.recipe);
      
      const recipeList = craftableItems.map(([id, item]) => {
        const requirements = Object.entries(item.recipe)
          .map(([matId, qty]) => `${items[matId].emoji} ${qty}x ${items[matId].name}`)
          .join(' + ');
        return `\`${id}\` → ${item.emoji} **${item.name}** (${item.rarity})\n   ${requirements}`;
      }).join('\n\n');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🔨 Receitas de Crafting Disponíveis')
        .setDescription(`Use \`ay.craft <nome-do-item>\` para craftear\n\n${recipeList}`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const itemId = args[0].toLowerCase();
    const item = items[itemId];

    if (!item || !item.recipe) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Item não encontrado')
        .setDescription(`\`${itemId}\` não é um item craftável. Use \`ay.craft\` para ver todas as receitas!`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const inventory = await getInventory(message.author.id, message.guildId);
    const inventoryMap = Object.fromEntries(inventory.map(inv => [inv.item_id, inv.quantity]));

    // Verificar se tem todos os materiais
    const missing = [];
    for (const [matId, required] of Object.entries(item.recipe)) {
      const have = inventoryMap[matId] || 0;
      if (have < required) {
        const mat = items[matId];
        missing.push(`${mat.emoji} ${mat.name}: tem ${have}/${required}`);
      }
    }

    if (missing.length > 0) {
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Materiais Insuficientes')
        .setDescription(`Para craftear ${item.emoji} **${item.name}**, você precisa:\n\n${missing.join('\n')}`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    // Remover materiais
    for (const [matId, required] of Object.entries(item.recipe)) {
      for (let i = 0; i < required; i++) {
        await removeInventoryItem(message.author.id, message.guildId, matId);
      }
    }

    // Adicionar item craftado
    await addInventoryItem(message.author.id, message.guildId, itemId);

    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const requirements = Object.entries(item.recipe)
      .map(([matId, qty]) => `${items[matId].emoji} ${qty}x ${items[matId].name}`)
      .join(' + ');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('✨ Crafting Bem-Sucedido!')
      .addFields(
        { name: '📦 Item Criado', value: `${item.emoji} **${item.name}** (${item.rarity})`, inline: false },
        { name: '⚙️ Materiais Usados', value: requirements, inline: false },
        { name: '📜 Descrição', value: item.description, inline: false }
      )
      .setTimestamp();
    
    if (item.attack) embed.addFields({ name: '⚔️ Ataque', value: `+${item.attack}`, inline: true });
    if (item.defense) embed.addFields({ name: '🛡️ Defesa', value: `+${item.defense}`, inline: true });

    await message.reply({ embeds: [embed] });
  },
};
