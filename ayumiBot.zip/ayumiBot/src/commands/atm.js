const { EmbedBuilder } = require('discord.js');
const { getUser } = require('../database');

module.exports = {
  name: 'atm',
  description: 'Mostra seu saldo de cristais',
  aliases: ['saldo', 'carteira'],
  async execute(message, args, client) {
    const user = message.mentions.users.first() || message.author;
    const userData = await getUser(user.id, message.guild.id);
    
    const embed = new EmbedBuilder()
      .setColor(0xBA55D3)
      .setTitle('💎 Caixa Eletrônico')
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '👤 Usuário', value: `<@${user.id}>`, inline: true },
        { name: '💰 Cristais', value: `\`${userData.cristais.toLocaleString('pt-BR')}\``, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Solicitado por ${message.author.tag}` });

    await message.reply({ embeds: [embed] });
  },
};
