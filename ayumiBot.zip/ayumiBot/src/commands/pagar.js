const { EmbedBuilder } = require('discord.js');
const { getUser, transferCristais } = require('../database');

module.exports = {
  name: 'pagar',
  description: 'Transfere cristais para outro usuário',
  aliases: ['pay', 'transferir', 'enviar'],
  async execute(message, args, client) {
    const targetUser = message.mentions.users.first();
    
    if (!targetUser) {
      return message.reply('Por favor, mencione um usuário para transferir cristais!\nExemplo: `ay.pagar @usuario 100`');
    }
    
    if (targetUser.id === message.author.id) {
      return message.reply('Você não pode transferir cristais para si mesmo!');
    }
    
    if (targetUser.bot) {
      return message.reply('Você não pode transferir cristais para um bot!');
    }
    
    const amount = parseInt(args[1]);
    
    if (isNaN(amount) || amount <= 0) {
      return message.reply('Por favor, forneça uma quantidade válida de cristais!\nExemplo: `ay.pagar @usuario 100`');
    }
    
    const userData = await getUser(message.author.id, message.guild.id);
    const userCristais = Number(userData.cristais);
    
    if (userCristais < amount) {
      const embed = new EmbedBuilder()
        .setColor(0xDB7093)
        .setTitle('❌ Saldo Insuficiente!')
        .setDescription(`Você não tem cristais suficientes para essa transferência.`)
        .addFields(
          { name: '💰 Seu Saldo', value: `\`${userCristais.toLocaleString('pt-BR')}\` cristais`, inline: true },
          { name: '💸 Valor Solicitado', value: `\`${amount.toLocaleString('pt-BR')}\` cristais`, inline: true }
        )
        .setTimestamp();
      
      return message.reply({ embeds: [embed] });
    }
    
    const result = await transferCristais(message.author.id, targetUser.id, message.guild.id, amount);
    
    if (!result.success) {
      return message.reply(result.message);
    }
    
    const newBalance = userCristais - amount;
    
    const embed = new EmbedBuilder()
      .setColor(0xDB7093)
      .setTitle('💸 Transferência Realizada!')
      .setDescription(`Você transferiu **${amount.toLocaleString('pt-BR')}** 💎 cristais para ${targetUser}!`)
      .addFields(
        { name: '💰 Seu Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` cristais`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Transferência de ${message.author.tag}` });

    await message.reply({ embeds: [embed] });
  },
};
