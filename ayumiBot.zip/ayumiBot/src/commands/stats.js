const { EmbedBuilder } = require('discord.js');
const { getUser, isCharacterRegistered, getPrefix } = require('../database');
const classes = require('../utils/classes');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

function getHungerBar(current, max) {
  const filled = Math.floor((current / max) * 10);
  const bar = '🟩'.repeat(filled) + '⬜'.repeat(10 - filled);
  const status = current < 5 ? ' ⚠️ ENFRAQUECIDO' : '';
  return `${bar} ${current}/${max}${status}`;
}

module.exports = {
  name: 'rpg',
  description: 'Ver seus stats de RPG',
  aliases: ['stats', 'personagem', 'character'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const prefix = await getPrefix(message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const isRegistered = await isCharacterRegistered(message.author.id, message.guildId);

    if (!isRegistered) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você não tem um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem e começar sua jornada!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const reqExpNextLevel = user.rpg_level * 150 + 100;
    const expPercentage = Math.floor((user.rpg_exp / reqExpNextLevel) * 100);
    const expBar = '█'.repeat(Math.floor((user.rpg_exp / reqExpNextLevel) * 20)) + 
                   '░'.repeat(20 - Math.floor((user.rpg_exp / reqExpNextLevel) * 20));

    const classData = classes[user.rpg_class];

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`⚔️ ${user.character_name || message.author.username}`)
      .setDescription(`${classData.emoji} ${classData.name} • ${classData.bonus}`)
      .setThumbnail(message.author.displayAvatarURL())
      .addFields(
        { name: '🎖️ Nível', value: `\`${user.rpg_level}\``, inline: true },
        { name: '⭐ EXP', value: `\`${user.rpg_exp}/${reqExpNextLevel}\` (${expPercentage}%)\n${expBar}`, inline: false },
        { name: '❤️ HP', value: `\`${user.rpg_health}/${user.rpg_max_health}\``, inline: true },
        { name: '⚔️ Ataque', value: `\`${user.rpg_attack}\``, inline: true },
        { name: '🛡️ Defesa', value: `\`${user.rpg_defense}\``, inline: true },
        { name: '\u200B', value: '\u200B', inline: false },
        { name: '🔥 Fome', value: getHungerBar(user.hunger || 10, 10), inline: false },
        { name: '🪙 Moedas Medievais', value: `\`${Number(user.moedas)}\``, inline: true },
        { name: '👑 Bosses Derrotados', value: `\`${user.bosses_derrotados}\``, inline: true },
        { name: '📈 Multiplicador', value: `\`${user.multiplicador_moedas.toFixed(1)}x\``, inline: true }
      )
      .setFooter({ text: `Use ${prefix}lutar para batalhar ou ${prefix}enfrentarboss para bosses!` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
