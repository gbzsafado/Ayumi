const { EmbedBuilder } = require('discord.js');
const { setCristais, getUser } = require('../database');

const OWNER_ID = '1275126713592053780';

module.exports = {
  name: 'setcristal',
  description: 'Define a quantidade de cristais de um usuário (apenas para o dono)',
  aliases: ['add', 'setcrystals', 'addcrystals'],
  async execute(message, args, client) {
    if (message.author.id !== OWNER_ID) {
      return message.reply('❌ Você não tem permissão para usar este comando!');
    }

    const targetUser = message.mentions.users.first();
    const amount = parseInt(args[1]);

    if (!targetUser) {
      return message.reply('Use: `ay.setcristal @usuario <valor>`\nExemplo: `ay.setcristal @usuario 1000`');
    }

    if (isNaN(amount) || amount < 0) {
      return message.reply('Por favor, forneça uma quantidade válida de cristais!');
    }

    try {
      await setCristais(targetUser.id, message.guildId, amount);
      const userData = await getUser(targetUser.id, message.guildId);

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('💎 Cristais Definidos')
        .setDescription(`Cristais de ${targetUser} foram ajustados para \`${amount}\` 💎`)
        .addFields(
          { name: 'Usuário', value: targetUser.tag, inline: true },
          { name: 'Novo Saldo', value: `\`${amount.toLocaleString('pt-BR')}\``, inline: true },
          { name: 'Modificado por', value: message.author.tag, inline: true }
        )
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erro ao setar cristais:', error);
      return message.reply('❌ Ocorreu um erro ao definir os cristais!');
    }
  },
};
