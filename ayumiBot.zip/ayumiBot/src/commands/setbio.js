const { EmbedBuilder } = require('discord.js');
const { updateBio } = require('../database');

module.exports = {
  name: 'setbio',
  description: 'Define sua bio de perfil',
  aliases: ['setabout', 'bio', 'sobre'],
  async execute(message, args, client) {
    const bio = args.join(' ');
    
    if (bio.length === 0) {
      return message.reply('Use: `ay.setbio <texto>`\nExemplo: `ay.setbio Adorei ganhar cristais! 💎`\n\nPara remover: `ay.setbio remover`');
    }
    
    if (bio.toLowerCase() === 'remover') {
      await updateBio(message.author.id, message.guild.id, null);
      
      const embed = new EmbedBuilder()
        .setColor(0xEE82EE)
        .setTitle('✨ Bio Removida!')
        .setDescription('Sua bio foi removida com sucesso.')
        .setTimestamp();
      
      return message.reply({ embeds: [embed] });
    }
    
    if (bio.length > 150) {
      return message.reply('❌ Sua bio não pode ter mais de 150 caracteres!');
    }
    
    await updateBio(message.author.id, message.guild.id, bio);
    
    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✨ Bio Atualizada!')
      .setDescription(`Sua bio foi alterada para:\n\n_${bio}_`)
      .setTimestamp();
    
    await message.reply({ embeds: [embed] });
  },
};
