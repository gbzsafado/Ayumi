const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateRPGStats, addInventoryItem, updateLastFight, updateMoedas, addBossBounty } = require('../database');
const items = require('../utils/items');
const attacks = require('../utils/attacks');

const BOSSES = [
  { id: 'rei_dragao', name: 'Rei Dragão', maxHp: 250, attack: 20, defense: 10, exp: 100, moedas: 1000, emoji: '👑', dificuldade: 'Extrema', drop: 'dragon_heart' },
  { id: 'arquimago', name: 'Arquimago Negro', maxHp: 200, attack: 25, defense: 8, exp: 90, moedas: 800, emoji: '🔮', dificuldade: 'Extrema', drop: 'archmage_tome' },
  { id: 'titan', name: 'Titã Antigo', maxHp: 300, attack: 18, defense: 15, exp: 120, moedas: 1200, emoji: '⛏️', dificuldade: 'Extrema', drop: 'titan_crystal' },
  { id: 'demonio', name: 'Demônio Primordial', maxHp: 280, attack: 22, defense: 12, exp: 110, moedas: 1100, emoji: '😈', dificuldade: 'Extrema', drop: 'demon_claw' },
];

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];
const ATTACK_KEYS = ['golpe_basico', 'ataque_forte', 'defesa_agil', 'golpe_critico', 'regeneracao'];

function getHpBar(current, max) {
  const percentage = Math.max(0, Math.min(100, (current / max) * 100));
  const filled = Math.floor(percentage / 10);
  const bar = '🟥'.repeat(filled) + '⬜'.repeat(10 - filled);
  return `${bar} ${current}/${max}`;
}

async function executeBattle(message, boss, user) {
  const color = COLORS[Math.floor(Math.random() * COLORS.length)];
  let playerHp = user.rpg_health;
  let bossHp = boss.maxHp;
  let battleLog = [];
  let gameActive = true;
  
  // Penalidade de fome
  let playerAttack = user.rpg_attack;
  let playerDefense = user.rpg_defense;
  let hungerWarning = '';
  
  if (user.hunger < 5) {
    playerAttack = Math.floor(playerAttack * 0.7);
    playerDefense = Math.floor(playerDefense * 0.7);
    hungerWarning = '\n⚠️ **Você está muito faminto! Ataque e defesa -30%!**';
    battleLog.push('⚠️ Você está muito fraco de fome...');
  }

  while (gameActive && playerHp > 0 && bossHp > 0) {
    // Criar botões de ataques
    const buttons = ATTACK_KEYS.map((key, idx) => {
      const attack = attacks[key];
      return new ButtonBuilder()
        .setCustomId(`boss_attack_${key}`)
        .setLabel(`${attack.emoji} ${attack.name}`)
        .setStyle(ButtonStyle.Danger);
    });

    const rows = [];
    for (let i = 0; i < buttons.length; i += 2) {
      rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 2)));
    }

    const battleEmbed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`👑 Batalha contra Boss ${boss.emoji} ${boss.name}`)
      .addFields(
        { name: '🧑 Seu HP', value: getHpBar(playerHp, user.rpg_health), inline: false },
        { name: `${boss.emoji} ${boss.name}`, value: getHpBar(bossHp, boss.maxHp), inline: false },
        { name: 'Escolha seu ataque:', value: `Clique em um botão abaixo${hungerWarning}`, inline: false }
      )
      .setTimestamp();

    const response = await message.reply({ embeds: [battleEmbed], components: rows });

    // Coletor de interações
    const filter = (interaction) => interaction.user.id === message.author.id && interaction.customId.startsWith('boss_attack_');
    const collector = response.createMessageComponentCollector({ filter, time: 30000 });

    await new Promise((resolve) => {
      collector.on('collect', async (interaction) => {
        const attackKey = interaction.customId.replace('boss_attack_', '');
        const attack = attacks[attackKey];

        // Jogador ataca
        let playerDamage = 0;
        if (Math.random() * 100 <= attack.accuracy) {
          if (attack.healing) {
            playerDamage = attack.getHealing(user.rpg_health);
            playerHp = Math.min(user.rpg_health, playerHp + playerDamage);
            battleLog.push(`💚 **Você usou ${attack.name}** e recuperou ${playerDamage}❤️`);
          } else {
            playerDamage = attack.calculateDamage(playerAttack, boss.defense);
            bossHp -= playerDamage;
            battleLog.push(`⚔️ **Você usou ${attack.name}** e causou ${playerDamage} de dano! ${boss.emoji} agora tem ${Math.max(0, bossHp)}❤️`);
          }
        } else {
          battleLog.push(`❌ **Você usou ${attack.name}** mas errou!`);
        }

        if (bossHp <= 0) {
          gameActive = false;
          collector.stop();
          resolve();
          return;
        }

        // Boss ataca
        const bossAttackKey = ATTACK_KEYS[Math.floor(Math.random() * ATTACK_KEYS.length)];
        const bossAttack = attacks[bossAttackKey];
        let bossDamage = 0;

        if (Math.random() * 100 <= bossAttack.accuracy) {
          if (bossAttack.healing) {
            bossDamage = bossAttack.getHealing(boss.maxHp);
            bossHp = Math.min(boss.maxHp, bossHp + bossDamage);
            battleLog.push(`💚 **${boss.name} usou ${bossAttack.name}** e recuperou ${bossDamage}❤️`);
          } else {
            bossDamage = bossAttack.calculateDamage(boss.attack, playerDefense);
            playerHp -= bossDamage;
            battleLog.push(`💢 **${boss.name} usou ${bossAttack.name}** e causou ${bossDamage} de dano! Você agora tem ${Math.max(0, playerHp)}❤️`);
          }
        } else {
          battleLog.push(`❌ **${boss.name} usou ${bossAttack.name}** mas errou!`);
        }

        if (playerHp <= 0) {
          gameActive = false;
          collector.stop();
          resolve();
          return;
        }

        await interaction.deferUpdate();
        collector.resetTimer();
      });

      collector.on('end', () => {
        resolve();
      });
    });
  }

  // Usar cooldown separado para boss
  await require('../database').pool.query(
    'UPDATE users SET last_boss_fight = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [message.author.id, message.guildId]
  );

  let resultTitle = '';
  let resultColor = '';
  let rewards = 0;
  let moedas = 0;
  let loot = [];
  let bossDefeated = false;

  if (playerHp > 0) {
    resultTitle = `👑 BOSS DERROTADO! ${boss.emoji} ${boss.name}!`;
    resultColor = '#00FF00';
    rewards = boss.exp;
    moedas = Math.floor(boss.moedas * user.multiplicador_moedas);
    bossDefeated = true;
    
    await addBossBounty(message.author.id, message.guildId);
    
    // Adicionar EXP e moedas (com requisito exponencial)
    const newExp = user.rpg_exp + rewards;
    const reqExpForNextLevel = user.rpg_level * 150 + 100;
    const levelUp = newExp >= reqExpForNextLevel;

    let finalLevel = user.rpg_level;
    let finalExp = newExp;
    if (levelUp) {
      finalLevel = user.rpg_level + 1;
      finalExp = newExp - reqExpForNextLevel;
    }

    await updateRPGStats(message.author.id, message.guildId, {
      health: user.rpg_max_health,
      exp: finalExp,
      level: finalLevel,
      attack: 10 + (finalLevel - 1) * 1,
      defense: 5 + Math.floor((finalLevel - 1) * 0.8),
      max_health: 100 + (finalLevel - 1) * 3
    });

    await updateMoedas(message.author.id, message.guildId, moedas);

    // Drop do boss (15% de chance)
    if (boss.drop && Math.random() < 0.15) {
      const dropItem = items[boss.drop];
      await addInventoryItem(message.author.id, message.guildId, boss.drop);
      loot.push(`${dropItem.emoji} ${dropItem.name} ⭐`);
    }

    // Loot aleatório
    if (Math.random() < 0.6) {
      const lootItems = Object.entries(items).filter(([_, item]) => item.rarity && item.rarity !== 'consumable');
      const randomLoot = lootItems[Math.floor(Math.random() * lootItems.length)];
      if (randomLoot) {
        await addInventoryItem(message.author.id, message.guildId, randomLoot[0]);
        loot.push(`${randomLoot[1].emoji} ${randomLoot[1].name}`);
      }
    }

    if (levelUp) {
      resultTitle = `👑 BOSS DERROTADO E LEVEL UP! ${newLevel}!`;
    }
  } else {
    resultTitle = `💀 Você Perdeu para ${boss.emoji} ${boss.name}!`;
    resultColor = '#FF0000';
    
    // Perder HP permanente
    const newHp = Math.max(10, user.rpg_health - 20);
    await updateRPGStats(message.author.id, message.guildId, { health: newHp });
  }

  const logText = battleLog.slice(-5).join('\n') || 'Batalha terminou...';
  const lootText = loot.length > 0 ? `\n**Loot:** ${loot.join(', ')}` : '';
  const updatedUser = await getUser(message.author.id, message.guildId);

  const embed = new EmbedBuilder()
    .setColor(resultColor || color)
    .setTitle(resultTitle)
    .addFields(
      { name: '⚔️ Resumo da Batalha contra Boss', value: logText, inline: false },
      playerHp > 0
        ? { name: '🏆 Recompensas', value: `\`${rewards}\` EXP • \`${moedas}\` 🪙${lootText}`, inline: false }
        : { name: '😢 Derrota', value: `Você perdeu 20❤️! Boss muito poderoso...`, inline: false },
      { name: '📊 Multiplicador', value: `\`${updatedUser.multiplicador_moedas.toFixed(1)}x\` (${updatedUser.bosses_derrotados} bosses derrotados)`, inline: false }
    )
    .setTimestamp();

  await message.reply({ embeds: [embed] });
}

module.exports = {
  name: 'enfrentarboss',
  description: 'Desafie um boss e ganhe muito mais moedas com multiplicador',
  aliases: ['desafiarboss', 'boss', 'desafio'],
  async execute(message, args, client) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    // Cooldown de 5 minutos SEPARADO para bosses
    if (user.last_boss_fight) {
      const lastBossTime = new Date(user.last_boss_fight).getTime();
      const timeLeft = (5 * 60 * 1000) - (Date.now() - lastBossTime);
      if (timeLeft > 0) {
        const minutes = Math.ceil(timeLeft / 60000);
        const embed = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⏳ Você está cansado do Boss!')
          .setDescription(`Aguarde ${minutes} minuto${minutes > 1 ? 's' : ''} antes de desafiar outro boss.\n\n💡 Você ainda pode lutar contra inimigos com \`ay.lutar\`!`)
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      }
    }

    // Se o usuário passou um número, desafia esse boss
    if (args[0]) {
      const bossIndex = parseInt(args[0]) - 1;
      if (bossIndex >= 0 && bossIndex < BOSSES.length) {
        const boss = BOSSES[bossIndex];
        return executeBattle(message, boss, user);
      }
    }

    // Mostrar menu de seleção
    const select = new StringSelectMenuBuilder()
      .setCustomId('boss_select')
      .setPlaceholder('Escolha um boss para enfrentar!')
      .addOptions(
        BOSSES.map((boss, idx) => ({
          label: `${boss.emoji} ${boss.name}`,
          description: `HP: ${boss.maxHp} | ATK: ${boss.attack} | DEF: ${boss.defense} | 🪙 ${boss.moedas}`,
          value: idx.toString(),
        }))
      );

    const row = new ActionRowBuilder().addComponents(select);

    const bossList = BOSSES
      .map((boss, idx) => `**${idx + 1}.** ${boss.emoji} **${boss.name}** (${boss.dificuldade})\n    HP: ${boss.maxHp} | ATK: ${boss.attack} | DEF: ${boss.defense} | Moedas: ${boss.moedas}`)
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('👑 Escolha seu Desafio de Boss')
      .setDescription('Selecione um boss no menu abaixo ou use `ay.enfrentarboss [número]` para desafiar diretamente!\n\n' + bossList)
      .addFields(
        { name: '💡 Dicas', value: '• Cada boss derrotado aumenta seu multiplicador de moedas em +0.1x\n• Bosses são muito mais difíceis que inimigos normais\n• Prepare-se bem antes de enfrentar um boss!', inline: false }
      )
      .setFooter({ text: 'Você está cansado por 5 minutos após uma batalha!' })
      .setTimestamp();

    const response = await message.reply({ embeds: [embed], components: [row] });

    // Coletor de interações
    const filter = (interaction) => interaction.user.id === message.author.id && interaction.customId === 'boss_select';
    const collector = response.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (interaction) => {
      const selectedIndex = parseInt(interaction.values[0]);
      const selectedBoss = BOSSES[selectedIndex];

      await interaction.deferReply();
      const updatedUser = await getUser(message.author.id, message.guildId);
      await executeBattle(interaction, selectedBoss, updatedUser);
      collector.stop();
    });

    collector.on('end', (collected) => {
      if (collected.size === 0) {
        message.edit({ components: [] }).catch(() => {});
      }
    });
  },
};
