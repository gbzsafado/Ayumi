const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateRPGStats, addInventoryItem, updateMoedas } = require('../database');
const items = require('../utils/items');

const REGIONS = {
  floresta: {
    name: '🌴 Floresta Amazônica',
    description: 'Uma floresta tropical exuberante cheia de mistérios e tesouros',
    emoji: '🌴',
    enemies: [
      { name: 'Lobo da Floresta', maxHp: 50, attack: 8, defense: 3, exp: 15, moedas: 75, emoji: '🐺', drop: 'wolf_fang' },
      { name: 'Abelha Gigante', maxHp: 35, attack: 6, defense: 2, exp: 12, moedas: 60, emoji: '🐝', drop: 'bee_stinger' },
      { name: 'Enraizado', maxHp: 80, attack: 7, defense: 5, exp: 20, moedas: 100, emoji: '🌳', drop: 'tree_bark' },
    ],
    newDrops: {
      'wolf_fang': { name: 'Fang de Lobo', emoji: '🦷', type: 'material', rarity: 'common', description: 'Um fang afiado de Lobo da Floresta' },
      'bee_stinger': { name: 'Ferrão de Abelha', emoji: '🪡', type: 'material', rarity: 'common', description: 'Um ferrão venenoso de Abelha Gigante' },
      'tree_bark': { name: 'Casca de Árvore', emoji: '🌳', type: 'material', rarity: 'common', description: 'Casca grossa e resistente de um Enraizado' },
    }
  },
  montanha: {
    name: '❄️ Pico Nevado',
    description: 'Um pico montanhoso coberto de neve com temperaturas extremas',
    emoji: '❄️',
    enemies: [
      { name: 'Golem de Pedra', maxHp: 100, attack: 12, defense: 8, exp: 25, moedas: 150, emoji: '🪨', drop: 'stone_core' },
      { name: 'Harpia', maxHp: 60, attack: 14, defense: 4, exp: 22, moedas: 120, emoji: '🦅', drop: 'harpy_feather' },
      { name: 'Minerador Mutante', maxHp: 75, attack: 10, defense: 6, exp: 20, moedas: 130, emoji: '⛏️', drop: 'crystal_ore' },
    ],
    newDrops: {
      'stone_core': { name: 'Núcleo de Pedra', emoji: '⚫', type: 'material', rarity: 'rare', description: 'O núcleo brilhante de um Golem de Pedra' },
      'harpy_feather': { name: 'Pena de Harpia', emoji: '🪶', type: 'material', rarity: 'common', description: 'Uma pena dourada de uma Harpia' },
      'crystal_ore': { name: 'Minério de Cristal', emoji: '💎', type: 'material', rarity: 'rare', description: 'Um minério precioso brilhante' },
    }
  },
  caverna: {
    name: '⛏️ Mina Abandonada',
    description: 'Uma mina antiga repleta de minérios valiosos e perigos esquecidos',
    emoji: '⛏️',
    enemies: [
      { name: 'Aranha Gigante', maxHp: 70, attack: 11, defense: 5, exp: 18, moedas: 110, emoji: '🕷️', drop: 'spider_silk' },
      { name: 'Morcego Vampiro', maxHp: 55, attack: 13, defense: 3, exp: 17, moedas: 95, emoji: '🦇', drop: 'bat_fang' },
      { name: 'Beholder', maxHp: 120, attack: 16, defense: 7, exp: 30, moedas: 200, emoji: '👁️', drop: 'beholder_eye' },
    ],
    newDrops: {
      'spider_silk': { name: 'Seda de Aranha', emoji: '🕸️', type: 'material', rarity: 'rare', description: 'Uma seda brilhante de Aranha Gigante' },
      'bat_fang': { name: 'Fang de Morcego', emoji: '🦷', type: 'material', rarity: 'common', description: 'Um fang afiado de Morcego Vampiro' },
      'beholder_eye': { name: 'Olho de Beholder', emoji: '👁️', type: 'material', rarity: 'epic', description: 'Um olho mágico e poderoso de um Beholder' },
    }
  },
  deserto: {
    name: '🏛️ Templo Antigo',
    description: 'Um templo antigo perdido no tempo, guardado por entidades misteriosas',
    emoji: '🏛️',
    enemies: [
      { name: 'Escorpião Escuro', maxHp: 65, attack: 12, defense: 6, exp: 19, moedas: 105, emoji: '🦂', drop: 'scorpion_tail' },
      { name: 'Múmia', maxHp: 85, attack: 9, defense: 7, exp: 21, moedas: 125, emoji: '🪦', drop: 'mummy_wraps' },
      { name: 'Djinn do Deserto', maxHp: 110, attack: 15, defense: 8, exp: 28, moedas: 180, emoji: '🌪️', drop: 'djinn_essence' },
    ],
    newDrops: {
      'scorpion_tail': { name: 'Cauda de Escorpião', emoji: '🦂', type: 'material', rarity: 'common', description: 'Uma cauda venenosa de Escorpião Escuro' },
      'mummy_wraps': { name: 'Amarras de Múmia', emoji: '👻', type: 'material', rarity: 'rare', description: 'Fitas antigas de uma Múmia mileniar' },
      'djinn_essence': { name: 'Essência de Djinn', emoji: '💨', type: 'material', rarity: 'epic', description: 'Uma essência mágica e etérea de um Djinn' },
    }
  },
  templo: {
    name: '👑 Templo dos Guardiões',
    description: 'O lugar mais perigoso do reino - apenas bosses únicos habitam este local sagrado',
    emoji: '👑',
    isBossRegion: true,
    enemies: [
      { name: 'Guardião de Cristal', maxHp: 260, attack: 24, defense: 16, exp: 105, moedas: 520, emoji: '💎', drop: 'guardian_crystal' },
      { name: 'Príncipe das Trevas', maxHp: 230, attack: 30, defense: 11, exp: 95, moedas: 470, emoji: '🌑', drop: 'shadow_essence' },
      { name: 'Fênix Ancestral', maxHp: 240, attack: 27, defense: 13, exp: 100, moedas: 490, emoji: '🔥', drop: 'phoenix_feather' },
      { name: 'Leviatã Abissal', maxHp: 290, attack: 23, defense: 17, exp: 115, moedas: 560, emoji: '🌊', drop: 'leviathan_scale' },
    ],
    newDrops: {
      'guardian_crystal': { name: 'Cristal do Guardião', emoji: '💎', type: 'material', rarity: 'epic', description: 'Um cristal luminoso de um Guardião de Cristal' },
      'shadow_essence': { name: 'Essência das Trevas', emoji: '🌑', type: 'material', rarity: 'epic', description: 'Uma essência sombria e poderosa do Príncipe das Trevas' },
      'phoenix_feather': { name: 'Pena de Fênix', emoji: '🔥', type: 'material', rarity: 'epic', description: 'Uma pena flamejante da Fênix Ancestral' },
      'leviathan_scale': { name: 'Escama de Leviatã', emoji: '🌊', type: 'material', rarity: 'epic', description: 'Uma escama gigante e resistente do Leviatã Abissal' },
    }
  }
};

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

function getHpBar(current, max) {
  const percentage = Math.max(0, Math.min(100, (current / max) * 100));
  const filled = Math.floor(percentage / 10);
  const bar = '🟥'.repeat(filled) + '⬜'.repeat(10 - filled);
  return `${bar} ${current}/${max}`;
}

module.exports = {
  name: 'explore',
  description: 'Explore diferentes regiões perigosas',
  aliases: ['exp', 'explorar'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (!user.rpg_class) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você precisa de um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem primeiro!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const regionKey = args[0]?.toLowerCase();

    if (!regionKey) {
      const regionsList = Object.entries(REGIONS)
        .map(([key, region]) => `**${region.emoji} ${region.name}** - ${region.description}`)
        .join('\n\n');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🗺️ Regiões Disponíveis para Explorar')
        .setDescription(regionsList)
        .addFields(
          { name: '💡 Como usar', value: `Use \`ay.explore [região]\` para explorar\nExemplo: \`ay.explore floresta\``, inline: false }
        )
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const region = REGIONS[regionKey];
    if (!region) {
      return message.reply('❌ Região não encontrada! Use `ay.explore` para ver as regiões disponíveis.');
    }

    // Seleciona inimigo aleatório da região
    const enemy = region.enemies[Math.floor(Math.random() * region.enemies.length)];
    let playerHp = user.rpg_health;
    let enemyHp = enemy.maxHp;
    let gameActive = true;

    // Penalidade de fome
    let playerAttack = user.rpg_attack;
    let playerDefense = user.rpg_defense;
    let hungerWarning = '';

    if (user.hunger < 5) {
      playerAttack = Math.floor(playerAttack * 0.7);
      playerDefense = Math.floor(playerDefense * 0.7);
      hungerWarning = '\n⚠️ **Você está muito faminto! Ataque e defesa -30%!**';
    }

    // Batalha automática
    let battleLog = [];
    let rounds = 0;
    const maxRounds = 20;

    while (gameActive && playerHp > 0 && enemyHp > 0 && rounds < maxRounds) {
      rounds++;

      // Ataque do jogador
      const playerDamage = Math.max(1, Math.floor(playerAttack + Math.random() * 5 - playerDefense * 0.3));
      enemyHp -= playerDamage;
      battleLog.push(`🗡️ Você atacou ${enemy.emoji} ${enemy.name} causando ${playerDamage} de dano!`);

      if (enemyHp <= 0) {
        gameActive = false;
        break;
      }

      // Ataque do inimigo
      const enemyDamage = Math.max(1, Math.floor(enemy.attack + Math.random() * 5 - playerDefense));
      playerHp -= enemyDamage;
      battleLog.push(`⚔️ ${enemy.emoji} ${enemy.name} atacou você causando ${enemyDamage} de dano!`);

      if (playerHp <= 0) {
        gameActive = false;
        break;
      }
    }

    // Determina resultado
    if (playerHp <= 0) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle(`☠️ Você foi derrotado em ${region.emoji} ${region.name}!`)
        .setDescription('Você perdeu 50% de suas moedas medievais...')
        .addFields(
          { name: '📋 Relato da Batalha', value: battleLog.slice(-5).join('\n') || 'Você caiu rapidamente...' }
        )
        .setTimestamp();

      const lostMoedas = Math.floor(user.moedas * 0.5);
      await updateMoedas(message.author.id, message.guildId, -lostMoedas);

      return message.reply({ embeds: [embed] });
    }

    // Vitória!
    const expGained = enemy.exp;
    const moedasGained = Math.floor(enemy.moedas * (1 + Math.random() * 0.3));
    const dropChance = Math.random() < 0.4; // 40% de chance de drop

    await updateRPGStats(message.author.id, message.guildId, { exp: user.rpg_exp + expGained });
    await updateMoedas(message.author.id, message.guildId, moedasGained);

    if (dropChance && enemy.drop) {
      await addInventoryItem(message.author.id, message.guildId, enemy.drop, 1);
    }

    const dropItem = enemy.drop && dropChance ? region.newDrops[enemy.drop] : null;
    const dropText = dropItem ? `\n🎁 **Drop:** ${dropItem.emoji} ${dropItem.name}` : '';

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle(`🎉 Vitória em ${region.emoji} ${region.name}!`)
      .setDescription(`Você derrotou ${enemy.emoji} ${enemy.name}!${dropText}`)
      .addFields(
        { name: '⭐ EXP Ganho', value: `+${expGained}`, inline: true },
        { name: '🪙 Moedas Ganhas', value: `+${moedasGained}`, inline: true },
        { name: '📋 Relato da Batalha', value: battleLog.slice(-5).join('\n') }
      )
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
