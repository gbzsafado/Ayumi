const { EmbedBuilder } = require('discord.js');
const { getUser, getUserMissions, getOrCreateMission, startMission, completeMission, updateMoedas, updateRPGStats, getPrefix } = require('../database');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

const ALL_MISSIONS = [
  'matar_10_goblin',
  'matar_5_orc',
  'caca_20_vezes',
  'forjar_espada',
  'nivel_10',
];

module.exports = {
  name: 'missao',
  description: 'Ver e aceitar missões',
  aliases: ['quest', 'quests', 'missões'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const prefix = await getPrefix(message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (!user.rpg_class) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você precisa de um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem primeiro!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    if (!args[0]) {
      const userMissions = await getUserMissions(message.author.id, message.guildId);
      
      const activeMissions = userMissions.filter(m => m.status === 'active');
      const completedMissions = userMissions.filter(m => m.status === 'completed');

      const missionsText = ALL_MISSIONS.map(mid => {
        const mission = activeMissions.find(m => m.mission_id === mid);
        if (mission) return `✅ ${mission.title}`;
        return `⬜ ${mid.replace(/_/g, ' ').toUpperCase()}`;
      }).join('\n');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('📜 Missões Disponíveis')
        .addFields(
          { name: 'Missões Ativas', value: activeMissions.length > 0 ? activeMissions.map(m => `✅ ${m.title}`).join('\n') : 'Nenhuma', inline: false },
          { name: 'Missões Completas', value: completedMissions.length > 0 ? completedMissions.map(m => `🏆 ${m.title}`).join('\n') : 'Nenhuma', inline: false },
          { name: 'Disponíveis', value: missionsText, inline: false }
        )
        .setDescription(`Use \`${prefix}missao info <nome>\` para detalhes ou \`${prefix}missao aceitar <nome>\``)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'info') {
      let missionId = args[1];
      if (!missionId) return message.reply('Indique uma missão!');

      let mission = await getOrCreateMission(missionId);
      
      // Se não encontrou, tenta procurar pelo nome
      if (!mission) {
        const searchName = args.slice(1).join('_').toLowerCase();
        for (const id of ALL_MISSIONS) {
          const m = await getOrCreateMission(id);
          if (m && m.title.toLowerCase().includes(searchName)) {
            missionId = id;
            mission = m;
            break;
          }
        }
      }
      
      if (!mission) return message.reply('Missão não encontrada! Use `ay.missao` para ver a lista.');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(mission.title)
        .setDescription(mission.description)
        .addFields(
          { name: '⭐ Dificuldade', value: mission.difficulty, inline: true },
          { name: '📊 Tipo', value: mission.type, inline: true },
          { name: '⭐ Recompensa EXP', value: `${mission.reward_exp} EXP`, inline: true },
          { name: '🪙 Recompensa Moedas', value: `${mission.reward_moedas} 🪙`, inline: true }
        )
        .setFooter({ text: `Use ${prefix}missao aceitar ${missionId}` })
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    if (subcommand === 'aceitar') {
      let missionId = args[1];
      if (!missionId) return message.reply('Indique uma missão!');

      // Tenta encontrar a missão pelo nome ou ID
      let mission = await getOrCreateMission(missionId);
      
      // Se não encontrou, tenta procurar pelo nome
      if (!mission) {
        const searchName = args.slice(1).join('_').toLowerCase();
        for (const id of ALL_MISSIONS) {
          const m = await getOrCreateMission(id);
          if (m && m.title.toLowerCase().includes(searchName)) {
            missionId = id;
            mission = m;
            break;
          }
        }
      }
      
      if (!mission) return message.reply('Missão não encontrada! Use `ay.missao` para ver a lista.');

      const success = await startMission(message.author.id, message.guildId, missionId);
      if (success) {
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('🎯 Missão Aceita!')
          .setDescription(`Você aceitou: **${mission.title}**\n\n${mission.description}`)
          .addFields(
            { name: '📊 Recompensas', value: `${mission.reward_exp} EXP • ${mission.reward_moedas} 🪙`, inline: false }
          )
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      } else {
        return message.reply('Você já tem essa missão!');
      }
    }

    if (subcommand === 'completar' || subcommand === 'complete') {
      const missionId = args[1];
      if (!missionId) return message.reply('Indique uma missão!');

      const mission = await getOrCreateMission(missionId);
      if (!mission) return message.reply('Missão não encontrada!');

      await completeMission(message.author.id, message.guildId, missionId);
      await updateMoedas(message.author.id, message.guildId, mission.reward_moedas);
      await updateRPGStats(message.author.id, message.guildId, {
        exp: user.rpg_exp + mission.reward_exp
      });

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🏆 Missão Completa!')
        .setDescription(`Você completou: **${mission.title}**`)
        .addFields(
          { name: '⭐ EXP Ganho', value: `+${mission.reward_exp}`, inline: true },
          { name: '🪙 Moedas Ganhas', value: `+${mission.reward_moedas}`, inline: true }
        )
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }
  },
};
