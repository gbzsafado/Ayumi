const { EmbedBuilder } = require('discord.js');
const { getUser, updateCristais, updateLastWork, getPrefix } = require('../database');

const trabalhos = [
  { nome: 'Programador', emoji: '💻', min: 100, max: 500 },
  { nome: 'Médico', emoji: '🏥', min: 150, max: 600 },
  { nome: 'Chef', emoji: '👨‍🍳', min: 80, max: 250 },
  { nome: 'Motorista', emoji: '🚗', min: 50, max: 200 },
  { nome: 'Professor', emoji: '📚', min: 100, max: 280 },
  { nome: 'Artista', emoji: '🎨', min: 70, max: 320 },
  { nome: 'Músico', emoji: '🎵', min: 60, max: 300 },
  { nome: 'Streamer', emoji: '🎮', min: 50, max: 200 },
  { nome: 'Youtuber', emoji: '📹', min: 40, max: 145 },
  { nome: 'Fotógrafo', emoji: '📷', min: 90, max: 270 },
];

module.exports = {
  name: 'work',
  description: 'Trabalhe para ganhar cristais',
  aliases: ['work', 'trampo'],
  async execute(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guild.id;
    const prefix = await getPrefix(guildId);
    const userData = await getUser(userId, guildId);
    
    const now = new Date();
    const lastWork = userData.last_work ? new Date(userData.last_work) : null;
    
    const cooldownMinutes = 30;
    
    if (lastWork) {
      const timeDiff = now - lastWork;
      const minutesLeft = cooldownMinutes - (timeDiff / (1000 * 60));
      
      if (minutesLeft > 0) {
        const minutes = Math.floor(minutesLeft);
        const seconds = Math.floor((minutesLeft - minutes) * 60);
        
        const embed = new EmbedBuilder()
          .setColor(0xFFB6C1)
          .setTitle('😓 Você está cansado!')
          .setDescription(`Descanse um pouco antes de trabalhar novamente.\nVolte em **${minutes}m ${seconds}s**`)
          .setTimestamp();
        
        return message.reply({ embeds: [embed] });
      }
    }
    
    const trabalho = trabalhos[Math.floor(Math.random() * trabalhos.length)];
    const reward = Math.floor(Math.random() * (trabalho.max - trabalho.min + 1)) + trabalho.min;
    
    await updateCristais(userId, guildId, reward);
    await updateLastWork(userId, guildId);
    
    const newBalance = Number(userData.cristais) + reward;
    
    const embed = new EmbedBuilder()
      .setColor(0xFFB6C1)
      .setTitle(`${trabalho.emoji} Trabalho Concluído!`)
      .setDescription(`Você trabalhou como **${trabalho.nome}** e ganhou **${reward.toLocaleString('pt-BR')}** 💎 cristais!`)
      .addFields(
        { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` cristais`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Use ${prefix}work para trabalhar novamente em ${cooldownMinutes} minutos!` });

    await message.reply({ embeds: [embed] });
  },
};
