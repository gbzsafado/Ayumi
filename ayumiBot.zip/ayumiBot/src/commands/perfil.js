const { EmbedBuilder } = require('discord.js');
const { getUser, getTopUsers } = require('../database');

module.exports = {
  name: 'perfil',
  description: 'Mostra seu perfil no bot',
  aliases: ['profile', 'p'],
  async execute(message, args, client) {
    const user = message.mentions.users.first() || message.author;
    const userId = user.id;
    const guildId = message.guild.id;
    
    const userData = await getUser(userId, guildId);
    const topUsers = await getTopUsers(guildId, 1000);
    
    const cristais = Number(userData.cristais);
    const level = Math.floor(cristais / 1000) + 1;
    const ranking = topUsers.findIndex(u => u.user_id === userId) + 1;
    
    const createdAt = new Date(userData.created_at);
    const accountAge = Math.floor((Date.now() - createdAt.getTime()) / (1000 * 60 * 60 * 24));
    
    const member = await message.guild.members.fetch(userId).catch(() => null);
    const joinedAt = member ? new Date(member.joinedAt) : null;
    const serverAge = joinedAt ? Math.floor((Date.now() - joinedAt.getTime()) / (1000 * 60 * 60 * 24)) : 0;
    
    const colors = [
      0xFF69B4,
      0xFF1493,
      0xFFB6C1,
      0xDB7093,
      0xFF00FF,
      0xDA70D6,
      0xBA55D3,
      0xEE82EE,
    ];
    
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    const progressBar = '█'.repeat(level > 10 ? 10 : level) + '░'.repeat(Math.max(0, 10 - level));
    
    const fields = [
      { name: '💎 Cristais', value: `\`${cristais.toLocaleString('pt-BR')}\` 💎`, inline: true },
      { name: '⭐ Nível', value: `${level}`, inline: true },
      { name: '🏆 Ranking', value: `${ranking}º lugar`, inline: true },
    ];
    
    if (userData.bio) {
      fields.push({ name: '✨ Sobre mim', value: userData.bio, inline: false });
    }
    
    fields.push(
      { name: '📊 Progresso', value: `\`${progressBar}\``, inline: false },
      { name: '📅 Data de Criação', value: `<t:${Math.floor(createdAt.getTime() / 1000)}:F>\n_${accountAge} dias atrás_`, inline: true },
      { name: '📍 No Servidor há', value: `${serverAge} dias`, inline: true }
    );
    
    const embed = new EmbedBuilder()
      .setColor(randomColor)
      .setTitle(`👤 Perfil de ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(...fields)
      .setFooter({ text: `ID: ${userId}` })
      .setTimestamp();
    
    await message.reply({ embeds: [embed] });
  },
};
