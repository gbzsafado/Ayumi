const { EmbedBuilder, version } = require('discord.js');

module.exports = {
  name: 'info',
  description: 'Mostra informações sobre o bot',
  async execute(message, args, client) {
    const uptime = formatUptime(client.uptime);
    
    const embed = new EmbedBuilder()
      .setColor(0xFFB6C1)
      .setTitle('Informações do Bot')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'Nome', value: client.user.tag, inline: true },
        { name: 'Servidores', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Usuários', value: `${client.users.cache.size}`, inline: true },
        { name: 'Uptime', value: uptime, inline: true },
        { name: 'Discord.js', value: `v${version}`, inline: true },
        { name: 'Node.js', value: process.version, inline: true },
      )
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};

function formatUptime(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  if (seconds > 0) parts.push(`${seconds}s`);

  return parts.join(' ') || '0s';
}
