const { EmbedBuilder } = require('discord.js');
const { getUser, updateCristais } = require('../database');

module.exports = {
  name: 'coinflip',
  description: 'Cara ou Coroa com apostas',
  aliases: ['coin', 'moeda', 'flip'],
  async execute(message, args, client) {
    const choice = args[0]?.toLowerCase();
    const amount = parseInt(args[1]);
    
    if (!choice || !['cara', 'coroa', 'c', 'co'].includes(choice)) {
      return message.reply('Use: `ay.coinflip <cara|coroa> <valor>`\nExemplo: `ay.coinflip cara 100`');
    }
    
    if (isNaN(amount) || amount <= 0) {
      return message.reply('Por favor, forneça uma quantidade válida de cristais!\nExemplo: `ay.coinflip cara 100`');
    }
    
    const userId = message.author.id;
    const guildId = message.guild.id;
    const userData = await getUser(userId, guildId);
    const userCristais = Number(userData.cristais);
    
    if (userCristais < amount) {
      const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('❌ Saldo Insuficiente!')
        .setDescription(`Você não tem cristais suficientes para essa aposta.`)
        .addFields(
          { name: '💰 Seu Saldo', value: `\`${userCristais.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💸 Valor Apostado', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setTimestamp();
      
      return message.reply({ embeds: [embed] });
    }
    
    const result = Math.random() < 0.5 ? 'Cara' : 'Coroa';
    const userChoice = choice === 'c' ? 'Cara' : choice === 'co' ? 'Coroa' : choice.charAt(0).toUpperCase() + choice.slice(1);
    const won = result === userChoice;
    
    const colors = [
      0xFF69B4,
      0xFF1493,
      0xFFB6C1,
      0xDB7093,
      0xFF00FF,
      0xDA70D6,
      0xBA55D3,
      0xEE82EE,
    ];
    
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    
    if (won) {
      const winnings = amount * 2;
      await updateCristais(userId, guildId, winnings);
      const newBalance = userCristais + winnings;
      
      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🎉 VITÓRIA! 🎉')
        .setDescription(`Você acertou em **${result}**!`)
        .addFields(
          { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '🏆 Ganho', value: `\`${winnings.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setFooter({ text: `Solicitado por ${message.author.tag}` })
        .setTimestamp();
      
      await message.reply({ embeds: [embed] });
    } else {
      await updateCristais(userId, guildId, -amount);
      const newBalance = userCristais - amount;
      
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('☠️ DERROTA! ☠️')
        .setDescription(`Saiu **${result}**, você escolheu **${userChoice}**!`)
        .addFields(
          { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💸 Perdido', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setFooter({ text: `Solicitado por ${message.author.tag}` })
        .setTimestamp();
      
      await message.reply({ embeds: [embed] });
    }
  },
};
