const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'limpar',
  description: 'Limpa mensagens do canal',
  async execute(message, args, client) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return message.reply('Você não tem permissão para usar este comando!');
    }

    const amount = parseInt(args[0]);

    if (isNaN(amount) || amount < 1 || amount > 100) {
      return message.reply('Por favor, forneça um número entre 1 e 100!');
    }

    try {
      await message.delete();
      const deleted = await message.channel.bulkDelete(amount, true);
      
      const embed = new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('🗑️ Mensagens Apagadas')
        .setDescription(`${deleted.size} mensagens foram removidas do canal!`)
        .setTimestamp();
      
      const reply = await message.channel.send({ embeds: [embed] });
      
      setTimeout(() => reply.delete().catch(() => {}), 3000);
    } catch (error) {
      console.error(error);
      message.channel.send('Ocorreu um erro ao tentar limpar as mensagens!');
    }
  },
};
