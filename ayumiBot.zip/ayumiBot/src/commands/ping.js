const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Mostra a latência do bot',
  async execute(message, args, client) {
    const sent = await message.reply('Calculando...');
    const latency = sent.createdTimestamp - message.createdTimestamp;
    const apiLatency = Math.round(client.ws.ping);
    
    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'Latência', value: `${latency}ms`, inline: true },
        { name: 'API', value: `${apiLatency}ms`, inline: true }
      )
      .setTimestamp();
    
    await sent.edit({ embeds: [embed] });
  },
};
