const { EmbedBuilder } = require('discord.js');
const { getUser, getUserGuild, createUserGuild, joinGuild } = require('../database');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'guilda',
  description: 'Criar ou gerenciar uma guilda',
  aliases: ['guild', 'guildas', 'guilds'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (!user.rpg_class) {
      const embed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('❌ Você precisa de um personagem!')
        .setDescription('Use `ay.registrar` para criar seu personagem primeiro!')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const userGuild = await getUserGuild(message.author.id);

    if (!args[0]) {
      if (userGuild) {
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle(`⚔️ Sua Guilda: ${userGuild.guild_name}`)
          .addFields(
            { name: '👤 Cargo', value: userGuild.role.toUpperCase(), inline: true },
            { name: '📅 Entrada', value: `<t:${Math.floor(new Date(userGuild.joined_at).getTime() / 1000)}:R>`, inline: true },
            { name: '\u200B', value: '\u200B', inline: false },
            { name: 'Comandos', value: '`ay.guilda info` - Ver info\n`ay.guilda sair` - Sair da guilda', inline: false }
          )
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      } else {
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('⚔️ Guildas')
          .setDescription('Você não está em uma guilda!')
          .addFields(
            { name: 'Criar Guilda', value: '`ay.guilda criar <nome>`', inline: false },
            { name: 'Entrar em Guilda', value: '`ay.guilda entrar <nome>`', inline: false }
          )
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      }
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'criar') {
      const guildName = args.slice(1).join(' ');
      if (!guildName || guildName.length < 3 || guildName.length > 50) {
        return message.reply('Nome da guilda deve ter entre 3 e 50 caracteres!');
      }

      if (userGuild) {
        return message.reply('Você já está em uma guilda! Use `ay.guilda sair` primeiro.');
      }

      const success = await createUserGuild(message.author.id, guildName);
      if (success) {
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('🎉 Guilda Criada!')
          .setDescription(`Você criou a guilda **${guildName}**!`)
          .addFields(
            { name: '👑 Cargo', value: 'LÍDER', inline: true },
            { name: '⚔️ Membros', value: '1', inline: true }
          )
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      } else {
        return message.reply('Erro ao criar guilda!');
      }
    }

    if (subcommand === 'entrar') {
      const guildName = args.slice(1).join(' ');
      if (!guildName) return message.reply('Indique o nome da guilda!');

      if (userGuild) {
        return message.reply('Você já está em uma guilda! Use `ay.guilda sair` primeiro.');
      }

      const success = await joinGuild(message.author.id, guildName);
      if (success) {
        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('✅ Entrou em Guilda!')
          .setDescription(`Você entrou na guilda **${guildName}**!`)
          .addFields(
            { name: '👤 Cargo', value: 'MEMBRO', inline: true }
          )
          .setTimestamp();
        return message.reply({ embeds: [embed] });
      } else {
        return message.reply('Erro ao entrar na guilda!');
      }
    }

    if (subcommand === 'sair') {
      if (!userGuild) return message.reply('Você não está em uma guilda!');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('👋 Saiu da Guilda')
        .setDescription(`Você saiu de **${userGuild.guild_name}**`)
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    if (subcommand === 'info') {
      if (!userGuild) return message.reply('Você não está em uma guilda!');

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(`⚔️ ${userGuild.guild_name}`)
        .addFields(
          { name: '👑 Líder', value: 'Sistema de Guildas v1', inline: true },
          { name: '👥 Membros', value: '1+', inline: true },
          { name: '📅 Fundada', value: `<t:${Math.floor(new Date(userGuild.joined_at).getTime() / 1000)}:R>`, inline: false },
          { name: 'Vantagens', value: '• Acesso a missões de guilda\n• Bônus cooperativo\n• Chat de guilda', inline: false }
        )
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }
  },
};
