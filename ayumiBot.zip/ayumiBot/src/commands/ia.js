const { EmbedBuilder } = require('discord.js');
const OpenAI = require('openai').default;

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'ia',
  description: 'Chat com IA para fazer comandos e resolver dúvidas',
  aliases: ['ai', 'chat', 'gpt'],
  async execute(message, args, client) {
    if (!args.length) {
      const embed = new EmbedBuilder()
        .setColor(0xFF00FF)
        .setTitle('🤖 Assistente IA')
        .setDescription('Use a IA para fazer comandos, resolver dúvidas e muito mais!')
        .addFields(
          { name: '📝 Comando', value: '`ay.ia [sua pergunta]`', inline: false },
          { name: '💡 Exemplos', value: '`ay.ia como fazer um comando de ping?`\n`ay.ia qual é a capital da França?`\n`ay.ia me escreva um poema`', inline: false },
          { name: '⚙️ Linguagens', value: 'JavaScript, Python, Java, C++, Go, Rust e muito mais!', inline: false }
        )
        .setFooter({ text: 'A IA pode ajudar com código e dúvidas gerais!' });
      
      return message.reply({ embeds: [embed] });
    }

    if (!process.env.OPENAI_API_KEY) {
      return message.reply('❌ A chave da API OpenAI não foi configurada! Peça ao dono do bot para adicionar.');
    }

    await message.channel.sendTyping();

    try {
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      const prompt = args.join(' ');

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'Você é um assistente IA especializado e versátil, parecido com um engenheiro de software senior. Você pode:\n\n1. Programação: Ajude com código em QUALQUER linguagem (JavaScript, Python, Java, C++, Go, Rust, TypeScript, etc)\n2. Resolução de Problemas: Analise erros, debug de código, otimizações\n3. Explicações: Conceitos técnicos, arquitetura, design patterns, best practices\n4. Dúvidas Gerais: Respostas úteis e precisas sobre qualquer tema\n5. Boas Práticas: Security, performance, código limpo\n\nSeu estilo:\n- Prático e direto, sem floreios desnecessários\n- Use blocos de código formatados com a linguagem\n- Se for código complexo, explique a lógica\n- Reconheça limitações quando existirem\n- Mantenha respostas concisas mas completas\n- Use português do Brasil\n\nContexto do Bot Discord:\n- Nome: Ayumi (Scooby Doo no Discord)\n- Plataforma: Replit com Node.js\n- Banco de dados: PostgreSQL\n\nCOMandos Disponíveis do Bot (prefixo: ay.):\nGeral: ping, info, botinfo, ajuda, servidor, avatar\nEconomia: daily, trabalhar, atm, pagar, ranking, registrar\nJogos: coinflip, blackjack, mines, crime\nPerfil: perfil, setbio, stats\nRPG: explore, rpg, lutar, enfrentarboss, mission (missao), craft, inventario, equipar, guilda, caca, infoboss, loja\nAdmin: setprefix, setcristal, limpar, ia\n\nVocê pode explicar como usar qualquer comando, ajudar a entender a mecânica do jogo, sugerir estratégias ou responder qualquer dúvida sobre o bot.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 2048,
      });

      const content = response.choices[0].message.content;
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];

      // Dividir a resposta em chunks de 1024 caracteres para o Discord
      const chunks = [];
      for (let i = 0; i < content.length; i += 1024) {
        chunks.push(content.slice(i, i + 1024));
      }

      // Enviar primeira resposta como reply
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🤖 Resposta da IA')
        .setDescription(chunks[0])
        .setFooter({ 
          text: `Pergunta de ${message.author.username}`,
          iconURL: message.author.displayAvatarURL({ dynamic: true })
        })
        .setTimestamp();

      const reply = await message.reply({ embeds: [embed] });

      // Enviar chunks restantes como mensagens adicionais
      for (let i = 1; i < chunks.length; i++) {
        const followUpEmbed = new EmbedBuilder()
          .setColor(color)
          .setDescription(chunks[i]);

        await message.channel.send({ embeds: [followUpEmbed] });
      }

    } catch (error) {
      console.error('Erro ao chamar OpenAI:', error);
      
      if (error.status === 401) {
        return message.reply('❌ Chave da API OpenAI inválida!');
      } else if (error.status === 429) {
        return message.reply('⏳ Muitas requisições! Tente novamente em alguns segundos.');
      } else if (error.status === 500) {
        return message.reply('❌ Erro nos servidores da OpenAI. Tente novamente mais tarde.');
      }
      
      return message.reply('❌ Ocorreu um erro ao processar sua pergunta. Tente novamente!');
    }
  },
};
