const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'avatar',
  description: 'Mostra o avatar de um usuário',
  async execute(message, args, client) {
    const user = message.mentions.users.first() || message.author;
    
    const embed = new EmbedBuilder()
      .setColor(0xFF00FF)
      .setTitle(`Avatar de ${user.tag}`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
