const { EmbedBuilder } = require('discord.js');
const { getUser, updateMoedas, pool } = require('../database');

const STOCKS = {
  coca: { name: '🥤 Coca Cola', symbol: 'COCA', basePrice: 150, emoji: '🥤' },
  sprite: { name: '🥤 Sprite', symbol: 'SPRT', basePrice: 140, emoji: '🥤' },
  samsung: { name: '📱 Samsung', symbol: 'SMSG', basePrice: 320, emoji: '📱' },
  iphone: { name: '📱 iPhone', symbol: 'APPL', basePrice: 450, emoji: '🍎' },
  ferrari: { name: '🏎️ Ferrari', symbol: 'FRRI', basePrice: 2500, emoji: '🏎️' },
  lamborghini: { name: '🏎️ Lamborghini', symbol: 'LMBRG', basePrice: 2800, emoji: '🏎️' }
};

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

function getStockPrice(stockKey) {
  const base = STOCKS[stockKey].basePrice;
  const variation = (Math.random() - 0.5) * 0.4; // ±20% variation
  return Math.floor(base * (1 + variation));
}

module.exports = {
  name: 'bolsa',
  description: 'Bolsa de valores - compre e venda ações',
  aliases: ['stock', 'acao'],
  async execute(message, args) {
    const user = await getUser(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    try {
      // Inicializar tabela de portfólio se não existir
      await pool.query(`
        CREATE TABLE IF NOT EXISTS user_stocks (
          id SERIAL PRIMARY KEY,
          user_id VARCHAR(255) NOT NULL,
          guild_id VARCHAR(255) NOT NULL,
          stock_key VARCHAR(50) NOT NULL,
          quantity INTEGER DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(user_id, guild_id, stock_key)
        )
      `);

      const subcommand = args[0]?.toLowerCase();

      if (!subcommand || subcommand === 'list') {
        // Mostrar ações disponíveis
        const stocksList = Object.entries(STOCKS)
          .map(([key, stock]) => {
            const price = getStockPrice(key);
            return `${stock.emoji} **${stock.name}** (${stock.symbol}): 🪙${price}`;
          })
          .join('\n');

        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('📊 Bolsa de Valores')
          .setDescription('Compre e venda ações para ganhar moedas!')
          .addFields(
            { name: '💹 Ações Disponíveis', value: stocksList, inline: false },
            { name: '💡 Como Usar', value: `\`ay.bolsa comprar [ação] [qtd]\` - Comprar ação\n\`ay.bolsa vender [ação] [qtd]\` - Vender ação\n\`ay.bolsa portfolio\` - Ver seu portfólio`, inline: false }
          )
          .setTimestamp();

        return message.reply({ embeds: [embed] });
      }

      if (subcommand === 'comprar') {
        const stockKey = args[1]?.toLowerCase();
        const quantity = parseInt(args[2]);

        if (!stockKey || !STOCKS[stockKey]) {
          return message.reply('❌ Ação não encontrada! Use: `ay.bolsa comprar [coca|sprite|samsung|iphone|ferrari|lamborghini] [quantidade]`');
        }

        if (!quantity || quantity <= 0) {
          return message.reply('❌ Quantidade inválida!');
        }

        const price = getStockPrice(stockKey);
        const totalCost = price * quantity;

        if (user.moedas < totalCost) {
          return message.reply(`❌ Você não tem moedas suficientes! Precisa de 🪙${totalCost}, mas tem apenas 🪙${user.moedas}`);
        }

        // Atualizar portfólio
        await pool.query(`
          INSERT INTO user_stocks (user_id, guild_id, stock_key, quantity)
          VALUES ($1, $2, $3, $4)
          ON CONFLICT (user_id, guild_id, stock_key) DO UPDATE SET quantity = user_stocks.quantity + $4
        `, [message.author.id, message.guildId, stockKey, quantity]);

        // Descontar moedas
        await updateMoedas(message.author.id, message.guildId, -totalCost);

        const embed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle(`✅ Compra Realizada!`)
          .addFields(
            { name: `${STOCKS[stockKey].emoji} Ação`, value: STOCKS[stockKey].name, inline: true },
            { name: '📊 Quantidade', value: `${quantity}`, inline: true },
            { name: '💵 Preço Unitário', value: `🪙${price}`, inline: true },
            { name: '💰 Total Gasto', value: `🪙${totalCost}`, inline: true },
            { name: '🪙 Saldo Restante', value: `🪙${user.moedas - totalCost}`, inline: true }
          )
          .setTimestamp();

        return message.reply({ embeds: [embed] });
      }

      if (subcommand === 'vender') {
        const stockKey = args[1]?.toLowerCase();
        const quantity = parseInt(args[2]);

        if (!stockKey || !STOCKS[stockKey]) {
          return message.reply('❌ Ação não encontrada!');
        }

        if (!quantity || quantity <= 0) {
          return message.reply('❌ Quantidade inválida!');
        }

        // Verificar quantidade possuída
        const result = await pool.query(
          'SELECT quantity FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_key = $3',
          [message.author.id, message.guildId, stockKey]
        );

        const owned = result.rows[0]?.quantity || 0;
        if (owned < quantity) {
          return message.reply(`❌ Você só possui ${owned} ${STOCKS[stockKey].symbol}(s)!`);
        }

        const price = getStockPrice(stockKey);
        const totalGain = price * quantity;

        // Atualizar portfólio
        if (owned === quantity) {
          await pool.query(
            'DELETE FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_key = $3',
            [message.author.id, message.guildId, stockKey]
          );
        } else {
          await pool.query(
            'UPDATE user_stocks SET quantity = quantity - $1 WHERE user_id = $2 AND guild_id = $3 AND stock_key = $4',
            [quantity, message.author.id, message.guildId, stockKey]
          );
        }

        // Adicionar moedas
        await updateMoedas(message.author.id, message.guildId, totalGain);

        const embed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle(`✅ Venda Realizada!`)
          .addFields(
            { name: `${STOCKS[stockKey].emoji} Ação`, value: STOCKS[stockKey].name, inline: true },
            { name: '📊 Quantidade', value: `${quantity}`, inline: true },
            { name: '💵 Preço Unitário', value: `🪙${price}`, inline: true },
            { name: '💰 Total Recebido', value: `🪙${totalGain}`, inline: true },
            { name: '📈 Lucro/Prejuízo', value: `🪙+${totalGain}`, inline: true }
          )
          .setTimestamp();

        return message.reply({ embeds: [embed] });
      }

      if (subcommand === 'portfolio' || subcommand === 'portifolio') {
        const result = await pool.query(
          'SELECT stock_key, quantity FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND quantity > 0 ORDER BY stock_key',
          [message.author.id, message.guildId]
        );

        if (result.rows.length === 0) {
          return message.reply('❌ Você não possui nenhuma ação!');
        }

        let portfolioValue = 0;
        const holdings = result.rows.map(row => {
          const stock = STOCKS[row.stock_key];
          const price = getStockPrice(row.stock_key);
          const value = price * row.quantity;
          portfolioValue += value;
          return `${stock.emoji} **${stock.name}** (${stock.symbol}): ${row.quantity} ações @ 🪙${price} = **🪙${value}**`;
        }).join('\n');

        const embed = new EmbedBuilder()
          .setColor(color)
          .setTitle('💼 Seu Portfólio de Ações')
          .setDescription(holdings)
          .addFields(
            { name: '💰 Valor Total do Portfólio', value: `🪙${portfolioValue}`, inline: false }
          )
          .setTimestamp();

        return message.reply({ embeds: [embed] });
      }

      return message.reply('❌ Subcomando inválido! Use: `ay.bolsa` | `ay.bolsa comprar [ação] [qtd]` | `ay.bolsa vender [ação] [qtd]` | `ay.bolsa portfolio`');

    } catch (error) {
      console.error('Erro no comando bolsa:', error);
      return message.reply('❌ Erro ao processar comando de bolsa!');
    }
  }
};
