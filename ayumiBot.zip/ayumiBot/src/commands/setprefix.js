const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { setPrefix } = require('../database');

module.exports = {
  name: 'setprefix',
  description: 'Define o prefixo do bot para este servidor (requer permissão de administrador)',
  aliases: ['prefix', 'mudarprefix'],
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return message.reply('❌ Você precisa ser administrador para usar este comando!');
    }

    const newPrefix = args[0];

    if (!newPrefix || newPrefix.length > 10) {
      return message.reply('Use: `ay.setprefix <novo-prefixo>`\nO prefixo deve ter no máximo 10 caracteres!');
    }

    try {
      await setPrefix(message.guildId, newPrefix);

      const embed = new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('⚙️ Prefixo Alterado')
        .setDescription(`O prefixo do servidor foi alterado com sucesso!`)
        .addFields(
          { name: 'Novo Prefixo', value: `\`${newPrefix}\``, inline: true },
          { name: 'Exemplo', value: `\`${newPrefix}ping\``, inline: true }
        )
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erro ao definir prefixo:', error);
      return message.reply('❌ Ocorreu um erro ao definir o prefixo!');
    }
  },
};
