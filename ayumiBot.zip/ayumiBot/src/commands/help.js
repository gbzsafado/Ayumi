const { EmbedBuilder } = require('discord.js');
const { getPrefix } = require('../database');

module.exports = {
  name: 'help',
  description: 'Mostra todos os comandos disponíveis',
  aliases: ['ajuda'],
  async execute(message, args, client) {
    const prefix = await getPrefix(message.guildId);

    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('📚 Comandos Disponíveis')
      .setDescription(`Use o prefixo: \`${prefix}\``)
      .addFields(
        { name: '📌 Geral', value: `\`${prefix}ping\` - Latência do bot\n\`${prefix}info\` - Info do bot\n\`${prefix}botinfo\` - Info detalhada\n\`${prefix}servidor\` - Info do servidor\n\`${prefix}avatar\` - Avatar de usuário`, inline: false },
        { name: '💰 Economia', value: `\`${prefix}daily\` - Recompensa diária\n\`${prefix}trabalhar\` - Ganhar moedas\n\`${prefix}atm\` - Ver saldo\n\`${prefix}pagar\` - Transferir moedas\n\`${prefix}ranking\` - Top 10\n\`${prefix}registrar\` - Criar conta\n\`${prefix}coinflip\` - Cara ou coroa\n\`${prefix}blackjack\` - Jogo de 21\n\`${prefix}mines\` - Jogo de minas\n\`${prefix}crime\` - Cometer crime\n\`${prefix}bolsa\` - Ver ações\n\`${prefix}bolsa comprar\` - Comprar ação\n\`${prefix}bolsa vender\` - Vender ação`, inline: false },
        { name: '👤 Perfil', value: `\`${prefix}perfil\` - Ver perfil\n\`${prefix}setbio\` - Setar bio\n\`${prefix}stats\` - Estatísticas\n\`${prefix}inventario\` - Seu inventário`, inline: false },
        { name: '⚔️ RPG & Exploração', value: `\`${prefix}explore\` - Explorar regiões\n\`${prefix}rpg\` - Menu RPG\n\`${prefix}lutar\` - Lutar contra inimigos\n\`${prefix}craft\` - Craftar itens\n\`${prefix}missao\` - Missões\n\`${prefix}guilda\` - Guildas\n\`${prefix}loja\` - Loja de itens`, inline: false },
        { name: '🔧 Moderação', value: `\`${prefix}setprefix\` - Customizar prefixo\n\`${prefix}limpar\` - Limpar mensagens`, inline: false }
      )
      .setFooter({ text: `Dúvidas? Use ${prefix}help para mais informações!` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
