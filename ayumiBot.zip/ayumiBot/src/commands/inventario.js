const { EmbedBuilder } = require('discord.js');
const { getInventory } = require('../database');
const items = require('../utils/items');

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  name: 'inventario',
  description: 'Ver seu inventário',
  aliases: ['inv', 'bolsa', 'items'],
  async execute(message, args) {
    const inventory = await getInventory(message.author.id, message.guildId);
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];

    if (inventory.length === 0) {
      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🎒 Inventário Vazio')
        .setDescription('Você não tem nenhum item! Derrote inimigos para conseguir loot.')
        .setTimestamp();
      return message.reply({ embeds: [embed] });
    }

    const itemsList = inventory
      .map(inv => {
        const item = items[inv.item_id];
        const equipped = inv.equipped ? ' 🟡' : '';
        return `${item.emoji} **${item.name}** x${inv.quantity}${equipped}`;
      })
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`🎒 Inventário de ${message.author.username}`)
      .setDescription(itemsList)
      .setFooter({ text: `Total: ${inventory.length} tipo${inventory.length > 1 ? 's' : ''} de item` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
