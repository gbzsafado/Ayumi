const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`Bot conectado como ${client.user.tag}!`);
    console.log(`Servindo ${client.guilds.cache.size} servidor(es)`);
    
    client.user.setActivity('ay.ajuda', { type: ActivityType.Listening });
  },
};
