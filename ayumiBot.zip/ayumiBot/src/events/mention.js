const { EmbedBuilder, Events } = require('discord.js');
const { getPrefix } = require('../database');

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    if (message.mentions.has(client.user)) {
      const prefix = await getPrefix(message.guildId);

      const embed = new EmbedBuilder()
        .setColor(0xBA55D3)
        .setTitle('👋 Olá!')
        .setDescription(`Meu prefixo neste servidor é: \`${prefix}\``)
        .addFields(
          { name: 'Use', value: `\`${prefix}ajuda\` para ver todos os comandos!` }
        )
        .setTimestamp();

      await message.reply({ embeds: [embed] });
    }
  },
};
