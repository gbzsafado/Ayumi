const { Events, EmbedBuilder } = require('discord.js');

module.exports = {
  name: Events.GuildMemberAdd,
  once: false,
  execute(member, client) {
    const channel = member.guild.systemChannel;
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(0xF4A6D7)
      .setTitle('Bem-vindo(a)!')
      .setDescription(`Olá ${member}, bem-vindo(a) ao **${member.guild.name}**!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: `Membro #${member.guild.memberCount}` });

    channel.send({ embeds: [embed] });
  },
};
