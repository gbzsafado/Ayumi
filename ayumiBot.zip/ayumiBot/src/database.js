const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

async function initDatabase() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        cristais BIGINT DEFAULT 0,
        last_daily TIMESTAMP,
        last_work TIMESTAMP,
        bio VARCHAR(150),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id)
      )
    `);
    
    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS bio VARCHAR(150)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_crime TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_level INTEGER DEFAULT 1
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_exp BIGINT DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_health INTEGER DEFAULT 100
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_max_health INTEGER DEFAULT 100
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_attack INTEGER DEFAULT 10
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_defense INTEGER DEFAULT 5
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_fight TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_boss_fight TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_class VARCHAR(50)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS character_name VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS moedas BIGINT DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS bosses_derrotados INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS multiplicador_moedas FLOAT DEFAULT 1.0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS hunger INTEGER DEFAULT 10
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_hunt TIMESTAMP
    `);
    
    await client.query(`
      CREATE TABLE IF NOT EXISTS guilds (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL UNIQUE,
        prefix VARCHAR(10) DEFAULT 'ay.',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS rpg_inventory (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        item_id VARCHAR(100) NOT NULL,
        quantity INTEGER DEFAULT 1,
        equipped BOOLEAN DEFAULT false,
        UNIQUE(user_id, guild_id, item_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS shop_stock (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        item_id VARCHAR(100) NOT NULL,
        quantity INTEGER DEFAULT 5,
        last_rotated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guild_id, item_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_guilds (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        guild_name VARCHAR(100) NOT NULL,
        role VARCHAR(50) DEFAULT 'member',
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_name)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS missions (
        id SERIAL PRIMARY KEY,
        mission_id VARCHAR(100) NOT NULL UNIQUE,
        title VARCHAR(100) NOT NULL,
        description TEXT,
        type VARCHAR(50),
        reward_exp INTEGER,
        reward_moedas INTEGER,
        difficulty VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_missions (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        mission_id VARCHAR(100) NOT NULL,
        status VARCHAR(50) DEFAULT 'active',
        progress INTEGER DEFAULT 0,
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP,
        UNIQUE(user_id, guild_id, mission_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_stocks (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        stock_symbol VARCHAR(10) NOT NULL,
        quantity INTEGER DEFAULT 0,
        UNIQUE(user_id, guild_id, stock_symbol)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS stock_prices (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        stock_symbol VARCHAR(10) NOT NULL,
        current_price BIGINT DEFAULT 1000,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guild_id, stock_symbol)
      )
    `);
    
    console.log('Banco de dados inicializado!');
  } catch (error) {
    console.error('Erro ao inicializar banco de dados:', error);
  } finally {
    client.release();
  }
}

async function getUser(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, 0)',
      [userId, guildId]
    );
    return { user_id: userId, guild_id: guildId, moedas: 0, cristais: 0, last_daily: null, last_work: null, rpg_level: 1, rpg_exp: 0, rpg_health: 100, rpg_max_health: 100, rpg_attack: 10, rpg_defense: 5, bosses_derrotados: 0, multiplicador_moedas: 1.0 };
  }
  
  return result.rows[0];
}

async function registerCharacter(userId, guildId, characterName, className) {
  const classes = require('./utils/classes');
  const classData = classes[className];
  
  if (!classData) {
    throw new Error('Classe inválida!');
  }

  await pool.query(
    `UPDATE users 
     SET rpg_class = $1, character_name = $2, rpg_attack = $3, rpg_defense = $4, rpg_max_health = $5, rpg_health = $5
     WHERE user_id = $6 AND guild_id = $7`,
    [className, characterName, classData.attack, classData.defense, classData.health, userId, guildId]
  );
}

async function isCharacterRegistered(userId, guildId) {
  const result = await pool.query(
    'SELECT rpg_class FROM users WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  
  if (result.rows.length === 0) return false;
  return result.rows[0].rpg_class !== null;
}

async function updateCristais(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = users.cristais + $3`,
    [userId, guildId, amount]
  );
}

async function updateMoedas(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET moedas = users.moedas + $3`,
    [userId, guildId, amount]
  );
}

async function setCristais(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = $3`,
    [userId, guildId, amount]
  );
}

async function updateLastDaily(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_daily = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateLastWork(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_work = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function getTopUsers(guildId, limit = 10) {
  const result = await pool.query(
    'SELECT * FROM users WHERE guild_id = $1 ORDER BY cristais DESC LIMIT $2',
    [guildId, limit]
  );
  return result.rows;
}

async function transferCristais(fromUserId, toUserId, guildId, amount) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    
    const fromUserResult = await client.query(
      'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2 FOR UPDATE',
      [fromUserId, guildId]
    );
    
    if (fromUserResult.rows.length === 0) {
      await client.query(
        'INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, 0)',
        [fromUserId, guildId]
      );
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const fromUser = fromUserResult.rows[0];
    if (fromUser.cristais < amount) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const updateResult = await client.query(
      'UPDATE users SET cristais = cristais - $1 WHERE user_id = $2 AND guild_id = $3 AND cristais >= $1 RETURNING cristais',
      [amount, fromUserId, guildId]
    );
    
    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    await client.query(
      `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
       ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = users.cristais + $3`,
      [toUserId, guildId, amount]
    );
    
    await client.query('COMMIT');
    return { success: true };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function updateBio(userId, guildId, bio) {
  await pool.query(
    'UPDATE users SET bio = $1 WHERE user_id = $2 AND guild_id = $3',
    [bio || null, userId, guildId]
  );
}

async function getPrefix(guildId) {
  const result = await pool.query(
    'SELECT prefix FROM guilds WHERE guild_id = $1',
    [guildId]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO guilds (guild_id, prefix) VALUES ($1, $2)',
      [guildId, 'ay.']
    );
    return 'ay.';
  }
  
  return result.rows[0].prefix;
}

async function setPrefix(guildId, prefix) {
  await pool.query(
    `INSERT INTO guilds (guild_id, prefix) VALUES ($1, $2)
     ON CONFLICT (guild_id) DO UPDATE SET prefix = $2`,
    [guildId, prefix]
  );
}

async function updateLastCrime(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_crime = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateRPGStats(userId, guildId, stats) {
  const updates = [];
  const values = [userId, guildId];
  let paramCount = 3;
  
  if (stats.health !== undefined) {
    updates.push(`rpg_health = $${paramCount++}`);
    values.push(stats.health);
  }
  if (stats.exp !== undefined) {
    updates.push(`rpg_exp = $${paramCount++}`);
    values.push(stats.exp);
  }
  if (stats.level !== undefined) {
    updates.push(`rpg_level = $${paramCount++}`);
    values.push(stats.level);
  }
  if (stats.attack !== undefined) {
    updates.push(`rpg_attack = $${paramCount++}`);
    values.push(stats.attack);
  }
  if (stats.defense !== undefined) {
    updates.push(`rpg_defense = $${paramCount++}`);
    values.push(stats.defense);
  }
  if (stats.max_health !== undefined) {
    updates.push(`rpg_max_health = $${paramCount++}`);
    values.push(stats.max_health);
  }

  if (updates.length > 0) {
    await pool.query(
      `UPDATE users SET ${updates.join(', ')} WHERE user_id = $1 AND guild_id = $2`,
      values
    );
  }
}

async function addInventoryItem(userId, guildId, itemId, quantity = 1) {
  await pool.query(
    `INSERT INTO rpg_inventory (user_id, guild_id, item_id, quantity)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (user_id, guild_id, item_id) DO UPDATE
     SET quantity = rpg_inventory.quantity + $4`,
    [userId, guildId, itemId, quantity]
  );
}

async function getInventory(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM rpg_inventory WHERE user_id = $1 AND guild_id = $2 ORDER BY item_id',
    [userId, guildId]
  );
  return result.rows;
}

async function removeInventoryItem(userId, guildId, itemId, quantity = 1) {
  await pool.query(
    `UPDATE rpg_inventory 
     SET quantity = quantity - $4
     WHERE user_id = $1 AND guild_id = $2 AND item_id = $3 AND quantity >= $4`,
    [userId, guildId, itemId, quantity]
  );

  await pool.query(
    `DELETE FROM rpg_inventory WHERE quantity <= 0 AND user_id = $1 AND guild_id = $2`,
    [userId, guildId]
  );
}

async function updateLastFight(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_fight = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function addBossBounty(userId, guildId) {
  await pool.query(
    `UPDATE users 
     SET bosses_derrotados = bosses_derrotados + 1, 
         multiplicador_moedas = multiplicador_moedas + 0.1
     WHERE user_id = $1 AND guild_id = $2`,
    [userId, guildId]
  );
}

async function getShopStock(guildId) {
  const result = await pool.query(
    'SELECT item_id, quantity FROM shop_stock WHERE guild_id = $1',
    [guildId]
  );
  
  const stock = {};
  result.rows.forEach(row => {
    stock[row.item_id] = row.quantity;
  });
  
  return stock;
}

async function updateShopStock(guildId, itemId, change) {
  await pool.query(
    `INSERT INTO shop_stock (guild_id, item_id, quantity) VALUES ($1, $2, 5)
     ON CONFLICT (guild_id, item_id) DO UPDATE SET quantity = MAX(0, shop_stock.quantity + $3)`,
    [guildId, itemId, change]
  );
}

async function rotateShopStock(guildId) {
  const SHOP_ITEMS = ['sword_iron', 'sword_steel', 'shield_wooden', 'shield_iron', 'potion_health', 'potion_strength', 'amulet_power'];
  for (const itemId of SHOP_ITEMS) {
    await pool.query(
      `INSERT INTO shop_stock (guild_id, item_id, quantity, last_rotated) VALUES ($1, $2, 5, CURRENT_TIMESTAMP)
       ON CONFLICT (guild_id, item_id) DO UPDATE SET quantity = 5, last_rotated = CURRENT_TIMESTAMP`,
      [guildId, itemId]
    );
  }
}

async function updateHunger(userId, guildId, hunger) {
  await pool.query(
    'UPDATE users SET hunger = $1 WHERE user_id = $2 AND guild_id = $3',
    [hunger, userId, guildId]
  );
}

async function updateLastHunt(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_hunt = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function createUserGuild(userId, guildName) {
  try {
    await pool.query(
      'INSERT INTO user_guilds (user_id, guild_id, guild_name, role) VALUES ($1, $2, $3, $4)',
      [userId, Math.random().toString(36), guildName, 'leader']
    );
    return true;
  } catch {
    return false;
  }
}

async function getUserGuild(userId) {
  const result = await pool.query(
    'SELECT * FROM user_guilds WHERE user_id = $1',
    [userId]
  );
  return result.rows[0] || null;
}

async function joinGuild(userId, guildName) {
  try {
    await pool.query(
      'INSERT INTO user_guilds (user_id, guild_id, guild_name, role) VALUES ($1, $2, $3, $4)',
      [userId, Math.random().toString(36), guildName, 'member']
    );
    return true;
  } catch {
    return false;
  }
}

async function getOrCreateMission(missionId) {
  const MISSIONS = {
    'matar_10_goblin': { title: '💀 Matador de Goblins', description: 'Mate 10 Goblins', type: 'Matar', reward_exp: 50, reward_moedas: 100, difficulty: 'Fácil' },
    'matar_5_orc': { title: '🐵 Caçador de Orcs', description: 'Mate 5 Orcs', type: 'Matar', reward_exp: 75, reward_moedas: 200, difficulty: 'Normal' },
    'caca_20_vezes': { title: '🎯 Caçador Experiente', description: 'Caçe 20 vezes', type: 'Caçar', reward_exp: 100, reward_moedas: 150, difficulty: 'Normal' },
    'forjar_espada': { title: '⚒️ Ferreiro', description: 'Forje uma Espada de Aço', type: 'Craftar', reward_exp: 60, reward_moedas: 120, difficulty: 'Fácil' },
    'nivel_10': { title: '📈 Herói Ascendente', description: 'Alcance Nível 10', type: 'Nível', reward_exp: 200, reward_moedas: 500, difficulty: 'Difícil' },
  };
  
  const mission = MISSIONS[missionId];
  if (!mission) return null;
  
  await pool.query(
    `INSERT INTO missions (mission_id, title, description, type, reward_exp, reward_moedas, difficulty)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT DO NOTHING`,
    [missionId, mission.title, mission.description, mission.type, mission.reward_exp, mission.reward_moedas, mission.difficulty]
  );
  
  return mission;
}

async function getUserMissions(userId, guildId) {
  const result = await pool.query(
    `SELECT um.*, m.* FROM user_missions um 
     LEFT JOIN missions m ON um.mission_id = m.mission_id 
     WHERE um.user_id = $1 AND um.guild_id = $2`,
    [userId, guildId]
  );
  return result.rows;
}

async function startMission(userId, guildId, missionId) {
  try {
    await pool.query(
      `INSERT INTO user_missions (user_id, guild_id, mission_id, status, progress)
       VALUES ($1, $2, $3, 'active', 0)`,
      [userId, guildId, missionId]
    );
    return true;
  } catch {
    return false;
  }
}

async function completeMission(userId, guildId, missionId) {
  await pool.query(
    `UPDATE user_missions SET status = 'completed', completed_at = CURRENT_TIMESTAMP
     WHERE user_id = $1 AND guild_id = $2 AND mission_id = $3`,
    [userId, guildId, missionId]
  );
}

module.exports = {
  pool,
  initDatabase,
  getUser,
  updateCristais,
  updateMoedas,
  setCristais,
  updateLastDaily,
  updateLastWork,
  getTopUsers,
  transferCristais,
  updateBio,
  getPrefix,
  setPrefix,
  updateLastCrime,
  updateRPGStats,
  addInventoryItem,
  getInventory,
  removeInventoryItem,
  updateLastFight,
  registerCharacter,
  isCharacterRegistered,
  addBossBounty,
  getShopStock,
  updateShopStock,
  rotateShopStock,
  updateHunger,
  updateLastHunt,
  createUserGuild,
  getUserGuild,
  joinGuild,
  getOrCreateMission,
  getUserMissions,
  startMission,
  completeMission
};
