const { Client, GatewayIntentBits, Collection, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { initDatabase, getPrefix, rotateShopStock } = require('./database');
const express = require('express');
const app = express();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
  ]
});

client.commands = new Collection();
client.aliases = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  client.commands.set(command.name, command);
  
  if (command.aliases && Array.isArray(command.aliases)) {
    for (const alias of command.aliases) {
      client.aliases.set(alias, command.name);
    }
  }
}

const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

const DEFAULT_PREFIX = process.env.PREFIX || 'ay.';

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;

  const prefix = await getPrefix(message.guildId);
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.commands.get(commandName) 
    || client.commands.get(client.aliases.get(commandName));

  if (!command) return;

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error(error);
    await message.reply('Ocorreu um erro ao executar esse comando!');
  }
});

const token = process.env.DISCORD_BOT_TOKEN;

if (!token) {
  console.error('ERRO: Token do Discord não encontrado!');
  console.log('Por favor, configure a variável de ambiente DISCORD_BOT_TOKEN');
  process.exit(1);
}

initDatabase().then(() => {
  client.login(token);

  // Servidor HTTP para UptimeRobot manter o bot acordado
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', bot: client.user?.tag || 'connecting' });
  });

  app.listen(3000, () => {
    console.log('✅ Servidor HTTP rodando na porta 3000');
  });

  // Rotação de estoque a cada 30 minutos
  setInterval(async () => {
    try {
      const guilds = client.guilds.cache.map(g => g.id);
      for (const guildId of guilds) {
        await rotateShopStock(guildId);
      }
      console.log('✅ Estoque da loja rotacionado!');
    } catch (error) {
      console.error('Erro ao rotacionar estoque:', error);
    }
  }, 30 * 60 * 1000); // 30 minutos
});
