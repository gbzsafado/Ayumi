module.exports = {
  // ITEMS DE DROP (Básicos - dropeados por inimigos)
  'goblin_fang': {
    name: 'Dente de Goblin',
    emoji: '🦷',
    type: 'material',
    rarity: 'common',
    description: 'Um dente afiado de Goblin'
  },
  'orc_horn': {
    name: 'Chifre de Orc',
    emoji: '🔔',
    type: 'material',
    rarity: 'common',
    description: 'Um chifre resistente de Orc'
  },
  'dragon_scale': {
    name: 'Escama de Dragão',
    emoji: '🐲',
    type: 'material',
    rarity: 'rare',
    description: 'Uma escama reluzente de Dragão'
  },
  'skeleton_bone': {
    name: 'Osso de Skeleton',
    emoji: '🦴',
    type: 'material',
    rarity: 'common',
    description: 'Um osso forte de Skeleton'
  },
  'witch_essence': {
    name: 'Essência de Bruxa',
    emoji: '🌙',
    type: 'material',
    rarity: 'rare',
    description: 'Uma essência mágica de Bruxa'
  },

  // ITEMS DE DROP (Boss - dropeados por bosses)
  'dragon_heart': {
    name: 'Coração de Dragão',
    emoji: '❤️‍🔥',
    type: 'material',
    rarity: 'epic',
    description: 'O coração poderoso de um Rei Dragão'
  },
  'archmage_tome': {
    name: 'Tomo do Arquimago',
    emoji: '📖',
    type: 'material',
    rarity: 'epic',
    description: 'Um tomo antigo com conhecimento arcano'
  },
  'titan_crystal': {
    name: 'Cristal do Titã',
    emoji: '💠',
    type: 'material',
    rarity: 'epic',
    description: 'Um cristal gigantesco de um Titã'
  },
  'demon_claw': {
    name: 'Garra de Demônio',
    emoji: '🪶',
    type: 'material',
    rarity: 'epic',
    description: 'Uma garra sombria de um Demônio'
  },

  // ITEMS CRAFTÁVEIS (Armas/Armaduras)
  'sword_iron': {
    name: 'Espada de Ferro',
    emoji: '⚔️',
    type: 'weapon',
    rarity: 'common',
    attack: 5,
    description: 'Uma espada simples de ferro',
    craftable: false
  },
  'sword_steel': {
    name: 'Espada de Aço',
    emoji: '⚔️',
    type: 'weapon',
    rarity: 'rare',
    attack: 10,
    description: 'Uma espada feita de aço de qualidade',
    recipe: {
      'goblin_fang': 5,
      'orc_horn': 3,
      'skeleton_bone': 4
    }
  },
  'sword_legendary': {
    name: 'Espada Lendária de Dragão',
    emoji: '⚡',
    type: 'weapon',
    rarity: 'epic',
    attack: 25,
    description: 'Uma espada forjada com o coração de um Dragão',
    recipe: {
      'dragon_heart': 1,
      'dragon_scale': 10,
      'sword_steel': 1
    }
  },
  'shield_wooden': {
    name: 'Escudo de Madeira',
    emoji: '🛡️',
    type: 'armor',
    rarity: 'common',
    defense: 3,
    description: 'Um escudo básico de madeira',
    craftable: false
  },
  'shield_iron': {
    name: 'Escudo de Ferro',
    emoji: '🛡️',
    type: 'armor',
    rarity: 'rare',
    defense: 7,
    description: 'Um escudo resistente de ferro',
    recipe: {
      'skeleton_bone': 8,
      'orc_horn': 5
    }
  },
  'shield_legendary': {
    name: 'Escudo Épico de Titã',
    emoji: '⛔',
    type: 'armor',
    rarity: 'epic',
    defense: 20,
    description: 'Um escudo forjado com cristal de um Titã',
    recipe: {
      'titan_crystal': 1,
      'demon_claw': 5,
      'shield_iron': 1
    }
  },
  'amulet_power': {
    name: 'Amuleto do Poder',
    emoji: '💎',
    type: 'accessory',
    rarity: 'epic',
    attack: 3,
    defense: 3,
    description: 'Um amuleto que aumenta força e resistência',
    recipe: {
      'dragon_scale': 8,
      'archmage_tome': 1,
      'witch_essence': 6
    }
  },
  'potion_health': {
    name: 'Poção de Vida',
    emoji: '🧪',
    type: 'consumable',
    rarity: 'consumable',
    value: 30,
    description: 'Recupera 30 pontos de vida'
  },
  'potion_strength': {
    name: 'Poção de Força',
    emoji: '🧪',
    type: 'consumable',
    rarity: 'consumable',
    value: 5,
    description: 'Aumenta ataque em 5 por uma batalha'
  },
};
