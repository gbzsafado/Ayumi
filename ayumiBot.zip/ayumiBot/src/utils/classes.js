module.exports = {
  guerreiro: {
    name: 'Guerreiro',
    emoji: '⚔️',
    bonus: 'Ataque +20%',
    attack: 12,
    defense: 5,
    health: 100
  },
  mago: {
    name: 'Mago',
    emoji: '🔮',
    bonus: 'Ataque Mágico +25%',
    attack: 14,
    defense: 3,
    health: 80
  },
  cavaleiro: {
    name: 'Cavaleiro',
    emoji: '🛡️',
    bonus: 'Defesa +40%',
    attack: 10,
    defense: 8,
    health: 120
  },
  arqueiro: {
    name: 'Arqueiro',
    emoji: '🏹',
    bonus: 'Crítico +15%',
    attack: 13,
    defense: 4,
    health: 90
  },
  clerigo: {
    name: 'Clérigo',
    emoji: '✨',
    bonus: 'Regeneração +5%',
    attack: 11,
    defense: 6,
    health: 110
  },
  assassino: {
    name: 'Assassino',
    emoji: '🗡️',
    bonus: 'Crítico +30%',
    attack: 15,
    defense: 3,
    health: 75
  }
};
