module.exports = {
  'golpe_basico': {
    name: 'Golpe Básico',
    emoji: '👊',
    accuracy: 100,
    calculateDamage: (attack, defense) => Math.max(1, attack - Math.floor(Math.random() * defense)),
    description: 'Um golpe simples e confiável'
  },
  'ataque_forte': {
    name: 'Ataque Forte',
    emoji: '⚡',
    accuracy: 85,
    calculateDamage: (attack, defense) => Math.max(1, Math.floor((attack * 1.5) - Math.floor(Math.random() * (defense * 0.5)))),
    description: 'Um ataque poderoso mas menos preciso'
  },
  'defesa_agil': {
    name: 'Defesa Ágil',
    emoji: '🛡️',
    accuracy: 100,
    calculateDamage: (attack, defense) => Math.max(1, attack - Math.floor(Math.random() * (defense * 1.5))),
    description: 'Minimiza dano recebido no próximo turno'
  },
  'golpe_critico': {
    name: 'Golpe Crítico',
    emoji: '💥',
    accuracy: 60,
    calculateDamage: (attack, defense) => Math.max(1, Math.floor((attack * 2) - Math.floor(Math.random() * defense))),
    description: 'Chance de dano dobrado!'
  },
  'regeneracao': {
    name: 'Regeneração',
    emoji: '💚',
    accuracy: 100,
    calculateDamage: (attack, defense) => 0,
    healing: true,
    description: 'Recupera sua vida',
    getHealing: (maxHp) => Math.floor(maxHp * 0.3)
  }
};
