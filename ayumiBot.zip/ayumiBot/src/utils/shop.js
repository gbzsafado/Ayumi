module.exports = {
  'sword_iron': {
    price: 500,
    name: 'Espada de Ferro',
    emoji: '⚔️',
    description: 'Uma espada simples de ferro'
  },
  'sword_steel': {
    price: 1500,
    name: 'Espada de Aço',
    emoji: '⚔️',
    description: 'Uma espada feita de aço de qualidade'
  },
  'shield_wooden': {
    price: 300,
    name: 'Escudo de Madeira',
    emoji: '🛡️',
    description: 'Um escudo básico de madeira'
  },
  'shield_iron': {
    price: 1000,
    name: 'Escudo de Ferro',
    emoji: '🛡️',
    description: 'Um escudo resistente de ferro'
  },
  'potion_health': {
    price: 200,
    name: 'Poção de Vida',
    emoji: '🧪',
    description: 'Recupera 30 pontos de vida'
  },
  'potion_strength': {
    price: 300,
    name: 'Poção de Força',
    emoji: '🧪',
    description: 'Aumenta ataque em 5 por uma batalha'
  },
  'amulet_power': {
    price: 3000,
    name: 'Amuleto do Poder',
    emoji: '💎',
    description: 'Um amuleto que aumenta força e resistência'
  }
};
