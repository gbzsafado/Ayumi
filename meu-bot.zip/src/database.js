const { Pool } = require('pg');

delete process.env.PGPORT;
delete process.env.PGHOST;
delete process.env.PGUSER;
delete process.env.PGPASSWORD;
delete process.env.PGDATABASE;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

async function initDatabase() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        cristais BIGINT DEFAULT 0,
        last_daily TIMESTAMP,
        last_work TIMESTAMP,
        bio VARCHAR(150),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id)
      )
    `);
    
    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS bio VARCHAR(150)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_crime TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_level INTEGER DEFAULT 1
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_exp BIGINT DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_health INTEGER DEFAULT 100
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_max_health INTEGER DEFAULT 100
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_attack INTEGER DEFAULT 10
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_defense INTEGER DEFAULT 5
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_mobility INTEGER DEFAULT 50
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_fight TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_boss_fight TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS rpg_class VARCHAR(50)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS character_name VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS moedas BIGINT DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS bosses_derrotados INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS multiplicador_moedas FLOAT DEFAULT 1.0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS hunger INTEGER DEFAULT 10
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_hunt TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_rest TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_mine TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS current_map VARCHAR(50) DEFAULT 'floresta_sombria'
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_ayumi_gift TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS equipped_weapon VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS weapon_bonus INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS equipped_armor VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS armor_bonus INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS equipped_shield VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS shield_bonus INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS last_raid TIMESTAMP
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS active_mission VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS mission_progress JSONB DEFAULT '{}'::jsonb
    `);
    
    await client.query(`
      CREATE TABLE IF NOT EXISTS guilds (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL UNIQUE,
        prefix VARCHAR(10) DEFAULT 'ay.',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS rpg_inventory (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        item_id VARCHAR(100) NOT NULL,
        quantity INTEGER DEFAULT 1,
        equipped BOOLEAN DEFAULT false,
        UNIQUE(user_id, guild_id, item_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS shop_stock (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        item_id VARCHAR(100) NOT NULL,
        quantity INTEGER DEFAULT 5,
        last_rotated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guild_id, item_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_guilds (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        guild_name VARCHAR(100) NOT NULL,
        role VARCHAR(50) DEFAULT 'member',
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_name)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS missions (
        id SERIAL PRIMARY KEY,
        mission_id VARCHAR(100) NOT NULL UNIQUE,
        title VARCHAR(100) NOT NULL,
        description TEXT,
        type VARCHAR(50),
        reward_exp INTEGER,
        reward_moedas INTEGER,
        difficulty VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_missions (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        mission_id VARCHAR(100) NOT NULL,
        status VARCHAR(50) DEFAULT 'active',
        progress INTEGER DEFAULT 0,
        started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        completed_at TIMESTAMP,
        UNIQUE(user_id, guild_id, mission_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_stocks (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        stock_symbol VARCHAR(10) NOT NULL,
        quantity INTEGER DEFAULT 0,
        UNIQUE(user_id, guild_id, stock_symbol)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS stock_prices (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        stock_symbol VARCHAR(10) NOT NULL,
        current_price BIGINT DEFAULT 1000,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guild_id, stock_symbol)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS user_guardians (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        guardian_type VARCHAR(50) NOT NULL,
        guardian_name VARCHAR(100),
        level INTEGER DEFAULT 1,
        xp INTEGER DEFAULT 0,
        health INTEGER DEFAULT 50,
        max_health INTEGER DEFAULT 50,
        attack INTEGER DEFAULT 10,
        defense INTEGER DEFAULT 5,
        evolution_stage INTEGER DEFAULT 1,
        afinidade INTEGER DEFAULT 0,
        traits VARCHAR(255),
        talento_especial VARCHAR(100),
        last_train TIMESTAMP,
        last_affection TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id)
      )
    `);

    await client.query(`
      ALTER TABLE user_guardians ADD COLUMN IF NOT EXISTS afinidade INTEGER DEFAULT 0
    `);

    await client.query(`
      ALTER TABLE user_guardians ADD COLUMN IF NOT EXISTS traits VARCHAR(255)
    `);

    await client.query(`
      ALTER TABLE user_guardians ADD COLUMN IF NOT EXISTS talento_especial VARCHAR(100)
    `);

    await client.query(`
      ALTER TABLE user_guardians ADD COLUMN IF NOT EXISTS last_affection TIMESTAMP
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS bug_reports (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        username VARCHAR(255),
        titulo VARCHAR(100),
        descricao VARCHAR(500),
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        guild_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    console.log('Banco de dados inicializado!');
  } catch (error) {
    console.error('Erro ao inicializar banco de dados:', error);
  } finally {
    client.release();
  }
}

async function getUser(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, 0)',
      [userId, guildId]
    );
    return { user_id: userId, guild_id: guildId, moedas: 0, cristais: 0, last_daily: null, last_work: null, rpg_level: 1, rpg_exp: 0, rpg_health: 100, rpg_max_health: 100, rpg_attack: 10, rpg_defense: 5, bosses_derrotados: 0, multiplicador_moedas: 1.0 };
  }
  
  return result.rows[0];
}

async function registerCharacter(userId, guildId, characterName, className) {
  const CLASSES = {
    guerreiro: { attack: 65, defense: 80, health: 110, mobility: 35 },
    mago: { attack: 90, defense: 25, health: 70, mobility: 50 },
    assassino: { attack: 85, defense: 30, health: 75, mobility: 85 },
    tanque: { attack: 35, defense: 95, health: 160, mobility: 20 },
    arqueiro: { attack: 80, defense: 55, health: 110, mobility: 75 }
  };

  const classData = CLASSES[className];
  if (!classData) {
    throw new Error('Classe inválida!');
  }

  await pool.query(
    `UPDATE users 
     SET rpg_class = $1, character_name = $2, rpg_attack = $3, rpg_defense = $4, rpg_max_health = $5, rpg_health = $5, rpg_level = 1, rpg_exp = 0, rpg_mobility = $8
     WHERE user_id = $6 AND guild_id = $7`,
    [className, characterName, classData.attack, classData.defense, classData.health, userId, guildId, classData.mobility]
  );
}


async function updateCristais(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = users.cristais + $3`,
    [userId, guildId, amount]
  );
}

async function updateMoedas(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET moedas = users.moedas + $3`,
    [userId, guildId, amount]
  );
}

async function setCristais(userId, guildId, amount) {
  await pool.query(
    `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = $3`,
    [userId, guildId, amount]
  );
}

async function updateLastDaily(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_daily = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateLastWork(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_work = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function getTopUsers(guildId, limit = 10) {
  const result = await pool.query(
    'SELECT * FROM users WHERE guild_id = $1 ORDER BY cristais DESC LIMIT $2',
    [guildId, limit]
  );
  return result.rows;
}

async function transferCristais(fromUserId, toUserId, guildId, amount) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    
    const fromUserResult = await client.query(
      'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2 FOR UPDATE',
      [fromUserId, guildId]
    );
    
    if (fromUserResult.rows.length === 0) {
      await client.query(
        'INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, 0)',
        [fromUserId, guildId]
      );
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const fromUser = fromUserResult.rows[0];
    if (fromUser.cristais < amount) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const updateResult = await client.query(
      'UPDATE users SET cristais = cristais - $1 WHERE user_id = $2 AND guild_id = $3 AND cristais >= $1 RETURNING cristais',
      [amount, fromUserId, guildId]
    );
    
    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    await client.query(
      `INSERT INTO users (user_id, guild_id, cristais) VALUES ($1, $2, $3)
       ON CONFLICT (user_id, guild_id) DO UPDATE SET cristais = users.cristais + $3`,
      [toUserId, guildId, amount]
    );
    
    await client.query('COMMIT');
    return { success: true };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function transferMoedas(fromUserId, toUserId, guildId, amount) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    
    const fromUserResult = await client.query(
      'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2 FOR UPDATE',
      [fromUserId, guildId]
    );
    
    if (fromUserResult.rows.length === 0) {
      await client.query(
        'INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, 0)',
        [fromUserId, guildId]
      );
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const fromUser = fromUserResult.rows[0];
    if (fromUser.moedas < amount) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    const updateResult = await client.query(
      'UPDATE users SET moedas = moedas - $1 WHERE user_id = $2 AND guild_id = $3 AND moedas >= $1 RETURNING moedas',
      [amount, fromUserId, guildId]
    );
    
    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, message: 'Saldo insuficiente!' };
    }
    
    await client.query(
      `INSERT INTO users (user_id, guild_id, moedas) VALUES ($1, $2, $3)
       ON CONFLICT (user_id, guild_id) DO UPDATE SET moedas = users.moedas + $3`,
      [toUserId, guildId, amount]
    );
    
    await client.query('COMMIT');
    return { success: true };
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function updateBio(userId, guildId, bio) {
  await pool.query(
    'UPDATE users SET bio = $1 WHERE user_id = $2 AND guild_id = $3',
    [bio || null, userId, guildId]
  );
}

async function getPrefix(guildId) {
  const result = await pool.query(
    'SELECT prefix FROM guilds WHERE guild_id = $1',
    [guildId]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO guilds (guild_id, prefix) VALUES ($1, $2)',
      [guildId, 'ay.']
    );
    return 'ay.';
  }
  
  return result.rows[0].prefix;
}

async function setPrefix(guildId, prefix) {
  await pool.query(
    `INSERT INTO guilds (guild_id, prefix) VALUES ($1, $2)
     ON CONFLICT (guild_id) DO UPDATE SET prefix = $2`,
    [guildId, prefix]
  );
}

async function updateLastCrime(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_crime = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateRPGStats(userId, guildId, stats) {
  const updates = [];
  const values = [userId, guildId];
  let paramCount = 3;
  
  if (stats.health !== undefined) {
    updates.push(`rpg_health = $${paramCount++}`);
    values.push(stats.health);
  }
  if (stats.exp !== undefined) {
    updates.push(`rpg_exp = $${paramCount++}`);
    values.push(stats.exp);
  }
  if (stats.level !== undefined) {
    updates.push(`rpg_level = $${paramCount++}`);
    values.push(stats.level);
  }
  if (stats.attack !== undefined) {
    updates.push(`rpg_attack = $${paramCount++}`);
    values.push(stats.attack);
  }
  if (stats.defense !== undefined) {
    updates.push(`rpg_defense = $${paramCount++}`);
    values.push(stats.defense);
  }
  if (stats.max_health !== undefined) {
    updates.push(`rpg_max_health = $${paramCount++}`);
    values.push(stats.max_health);
  }
  if (stats.last_rest !== undefined) {
    updates.push(`last_rest = $${paramCount++}`);
    values.push(stats.last_rest || new Date());
  }
  if (stats.last_mine !== undefined) {
    updates.push(`last_mine = $${paramCount++}`);
    values.push(stats.last_mine || new Date());
  }

  if (updates.length > 0) {
    await pool.query(
      `UPDATE users SET ${updates.join(', ')} WHERE user_id = $1 AND guild_id = $2`,
      values
    );
  }
}

async function addInventoryItem(userId, guildId, itemId, quantity = 1) {
  await pool.query(
    `INSERT INTO rpg_inventory (user_id, guild_id, item_id, quantity)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (user_id, guild_id, item_id) DO UPDATE
     SET quantity = rpg_inventory.quantity + $4`,
    [userId, guildId, itemId, quantity]
  );
}

async function getInventory(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM rpg_inventory WHERE user_id = $1 AND guild_id = $2 ORDER BY item_id',
    [userId, guildId]
  );
  return result.rows;
}

async function removeInventoryItem(userId, guildId, itemId, quantity = 1) {
  await pool.query(
    `UPDATE rpg_inventory 
     SET quantity = quantity - $4
     WHERE user_id = $1 AND guild_id = $2 AND item_id = $3 AND quantity >= $4`,
    [userId, guildId, itemId, quantity]
  );

  await pool.query(
    `DELETE FROM rpg_inventory WHERE quantity <= 0 AND user_id = $1 AND guild_id = $2`,
    [userId, guildId]
  );
}

async function updateLastFight(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_fight = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function addBossBounty(userId, guildId) {
  await pool.query(
    `UPDATE users 
     SET bosses_derrotados = bosses_derrotados + 1, 
         multiplicador_moedas = multiplicador_moedas + 0.1
     WHERE user_id = $1 AND guild_id = $2`,
    [userId, guildId]
  );
}

async function getShopStock(guildId) {
  const result = await pool.query(
    'SELECT item_id, quantity FROM shop_stock WHERE guild_id = $1',
    [guildId]
  );
  
  const stock = {};
  result.rows.forEach(row => {
    stock[row.item_id] = row.quantity;
  });
  
  return stock;
}

async function updateShopStock(guildId, itemId, change) {
  await pool.query(
    `INSERT INTO shop_stock (guild_id, item_id, quantity) VALUES ($1, $2, 5)
     ON CONFLICT (guild_id, item_id) DO UPDATE SET quantity = MAX(0, shop_stock.quantity + $3)`,
    [guildId, itemId, change]
  );
}

async function rotateShopStock(guildId) {
  const SHOP_ITEMS = ['sword_iron', 'sword_steel', 'shield_wooden', 'shield_iron', 'potion_health', 'potion_strength', 'amulet_power'];
  for (const itemId of SHOP_ITEMS) {
    await pool.query(
      `INSERT INTO shop_stock (guild_id, item_id, quantity, last_rotated) VALUES ($1, $2, 5, CURRENT_TIMESTAMP)
       ON CONFLICT (guild_id, item_id) DO UPDATE SET quantity = 5, last_rotated = CURRENT_TIMESTAMP`,
      [guildId, itemId]
    );
  }
}

async function updateHunger(userId, guildId, hunger) {
  await pool.query(
    'UPDATE users SET hunger = $1 WHERE user_id = $2 AND guild_id = $3',
    [hunger, userId, guildId]
  );
}

async function updateLastHunt(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_hunt = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function createUserGuild(userId, guildName) {
  try {
    await pool.query(
      'INSERT INTO user_guilds (user_id, guild_id, guild_name, role) VALUES ($1, $2, $3, $4)',
      [userId, Math.random().toString(36), guildName, 'leader']
    );
    return true;
  } catch {
    return false;
  }
}

async function getUserGuild(userId) {
  const result = await pool.query(
    'SELECT * FROM user_guilds WHERE user_id = $1',
    [userId]
  );
  return result.rows[0] || null;
}

async function joinGuild(userId, guildName) {
  try {
    await pool.query(
      'INSERT INTO user_guilds (user_id, guild_id, guild_name, role) VALUES ($1, $2, $3, $4)',
      [userId, Math.random().toString(36), guildName, 'member']
    );
    return true;
  } catch {
    return false;
  }
}

async function getOrCreateMission(missionId) {
  const MISSIONS = {
    'matar_10_goblin': { title: '💀 Matador de Goblins', description: 'Mate 10 Goblins', type: 'Matar', reward_exp: 50, reward_moedas: 100, difficulty: 'Fácil' },
    'matar_5_orc': { title: '🐵 Caçador de Orcs', description: 'Mate 5 Orcs', type: 'Matar', reward_exp: 75, reward_moedas: 200, difficulty: 'Normal' },
    'caca_20_vezes': { title: '🎯 Caçador Experiente', description: 'Caçe 20 vezes', type: 'Caçar', reward_exp: 100, reward_moedas: 150, difficulty: 'Normal' },
    'forjar_espada': { title: '⚒️ Ferreiro', description: 'Forje uma Espada de Aço', type: 'Craftar', reward_exp: 60, reward_moedas: 120, difficulty: 'Fácil' },
    'nivel_10': { title: '📈 Herói Ascendente', description: 'Alcance Nível 10', type: 'Nível', reward_exp: 200, reward_moedas: 500, difficulty: 'Difícil' },
  };
  
  const mission = MISSIONS[missionId];
  if (!mission) return null;
  
  await pool.query(
    `INSERT INTO missions (mission_id, title, description, type, reward_exp, reward_moedas, difficulty)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT DO NOTHING`,
    [missionId, mission.title, mission.description, mission.type, mission.reward_exp, mission.reward_moedas, mission.difficulty]
  );
  
  return mission;
}

async function getUserMissions(userId, guildId) {
  const result = await pool.query(
    `SELECT um.*, m.* FROM user_missions um 
     LEFT JOIN missions m ON um.mission_id = m.mission_id 
     WHERE um.user_id = $1 AND um.guild_id = $2`,
    [userId, guildId]
  );
  return result.rows;
}

async function startMission(userId, guildId, missionId) {
  try {
    await pool.query(
      `INSERT INTO user_missions (user_id, guild_id, mission_id, status, progress)
       VALUES ($1, $2, $3, 'active', 0)`,
      [userId, guildId, missionId]
    );
    return true;
  } catch {
    return false;
  }
}

async function completeMission(userId, guildId, missionId) {
  await pool.query(
    `UPDATE user_missions SET status = 'completed', completed_at = CURRENT_TIMESTAMP
     WHERE user_id = $1 AND guild_id = $2 AND mission_id = $3`,
    [userId, guildId, missionId]
  );
}

async function updateInventory(userId, guildId, material, quantity) {
  await pool.query(
    `INSERT INTO rpg_inventory (user_id, guild_id, item_id, quantity)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (user_id, guild_id, item_id) DO UPDATE
     SET quantity = rpg_inventory.quantity + $4`,
    [userId, guildId, material, quantity]
  );
}

async function getInventory(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM rpg_inventory WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function updateLastMine(userId, guildId) {
  await pool.query(
    'UPDATE users SET last_mine = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateMissionProgress(userId, guildId, missionId, progressValue) {
  const user = await getUser(userId, guildId);
  const currentProgress = user.mission_progress || {};
  currentProgress[missionId] = (currentProgress[missionId] || 0) + progressValue;
  
  await pool.query(
    'UPDATE users SET mission_progress = $1 WHERE user_id = $2 AND guild_id = $3',
    [JSON.stringify(currentProgress), userId, guildId]
  );
  
  return currentProgress[missionId];
}

async function checkMissionCompletion(userId, guildId, missionId, requiredProgress) {
  const user = await getUser(userId, guildId);
  const currentProgress = user.mission_progress || {};
  const progress = currentProgress[missionId] || 0;
  
  return progress >= requiredProgress;
}

async function completeMissionReward(userId, guildId, missionId, coins, xp) {
  // Dar recompensa
  await updateMoedas(userId, guildId, coins);
  await updateRPGStats(userId, guildId, { 
    exp: (await getUser(userId, guildId)).rpg_exp + xp,
    active_mission: null,
    mission_progress: JSON.stringify({})
  });
}

async function getGuardian(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM user_guardians WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows[0] || null;
}

async function createGuardian(userId, guildId, guardianType, guardianName) {
  const GUARDIAN_STATS = {
    slime: { health: 40, attack: 8, defense: 12 },
    fada: { health: 35, attack: 6, defense: 8 },
    golem: { health: 60, attack: 10, defense: 18 },
    goblin: { health: 45, attack: 12, defense: 6 }
  };
  
  const stats = GUARDIAN_STATS[guardianType] || GUARDIAN_STATS.slime;
  
  await pool.query(
    `INSERT INTO user_guardians (user_id, guild_id, guardian_type, guardian_name, health, max_health, attack, defense)
     VALUES ($1, $2, $3, $4, $5, $5, $6, $7)
     ON CONFLICT (user_id, guild_id) DO UPDATE SET 
       guardian_type = $3, guardian_name = $4, health = $5, max_health = $5, 
       attack = $6, defense = $7, level = 1, xp = 0, evolution_stage = 1`,
    [userId, guildId, guardianType, guardianName, stats.health, stats.attack, stats.defense]
  );
}

async function updateGuardianStats(userId, guildId, stats) {
  const updates = [];
  const values = [userId, guildId];
  let paramCount = 3;
  
  if (stats.xp !== undefined) {
    updates.push(`xp = $${paramCount++}`);
    values.push(stats.xp);
  }
  if (stats.level !== undefined) {
    updates.push(`level = $${paramCount++}`);
    values.push(stats.level);
  }
  if (stats.health !== undefined) {
    updates.push(`health = $${paramCount++}`);
    values.push(stats.health);
  }
  if (stats.max_health !== undefined) {
    updates.push(`max_health = $${paramCount++}`);
    values.push(stats.max_health);
  }
  if (stats.attack !== undefined) {
    updates.push(`attack = $${paramCount++}`);
    values.push(stats.attack);
  }
  if (stats.defense !== undefined) {
    updates.push(`defense = $${paramCount++}`);
    values.push(stats.defense);
  }
  if (stats.evolution_stage !== undefined) {
    updates.push(`evolution_stage = $${paramCount++}`);
    values.push(stats.evolution_stage);
  }
  if (stats.last_train !== undefined) {
    updates.push(`last_train = $${paramCount++}`);
    values.push(stats.last_train);
  }
  
  if (updates.length > 0) {
    await pool.query(
      `UPDATE user_guardians SET ${updates.join(', ')} WHERE user_id = $1 AND guild_id = $2`,
      values
    );
  }
}

async function updateGuardianLastTrain(userId, guildId) {
  await pool.query(
    'UPDATE user_guardians SET last_train = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function updateGuardianAfinidade(userId, guildId, amount) {
  const guardian = await getGuardian(userId, guildId);
  if (!guardian) return;
  
  let newAfinidade = Math.min(100, (guardian.afinidade || 0) + amount);
  let newTraits = guardian.traits;
  let newTalento = guardian.talento_especial;
  
  if (newAfinidade >= 75 && !guardian.traits) {
    const TRAITS = [
      'Guardião Esperto',
      'Leal',
      'Selvagem',
      'Alma Antiga',
      'Determinado',
      'Colecionador',
      'Adaptável',
      'Sortudo'
    ];
    newTraits = TRAITS[Math.floor(Math.random() * TRAITS.length)];
  }
  
  if (newAfinidade >= 100 && !guardian.talento_especial) {
    const TALENTS = ['Explosão Guardião', 'Proteção Absoluta', 'Cura Sagrada', 'Velocidade Extrema'];
    newTalento = TALENTS[Math.floor(Math.random() * TALENTS.length)];
  }
  
  await pool.query(
    'UPDATE user_guardians SET afinidade = $1, traits = $2, talento_especial = $3 WHERE user_id = $4 AND guild_id = $5',
    [newAfinidade, newTraits, newTalento, userId, guildId]
  );
}

async function updateGuardianLastAffection(userId, guildId) {
  await pool.query(
    'UPDATE user_guardians SET last_affection = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
}

async function query(sql, values = []) {
  return await pool.query(sql, values);
}

async function execute(sql, values = []) {
  return await pool.query(sql, values);
}

module.exports = {
  pool,
  initDatabase,
  getUser,
  registerCharacter,
  updateCristais,
  updateMoedas,
  setCristais,
  updateLastDaily,
  updateLastWork,
  getTopUsers,
  transferCristais,
  transferMoedas,
  updateBio,
  getPrefix,
  setPrefix,
  updateLastCrime,
  updateRPGStats,
  updateInventory,
  getInventory,
  updateLastMine,
  updateMissionProgress,
  checkMissionCompletion,
  completeMissionReward,
  getGuardian,
  createGuardian,
  updateGuardianStats,
  updateGuardianLastTrain,
  updateGuardianAfinidade,
  updateGuardianLastAffection,
  query,
  execute
};
