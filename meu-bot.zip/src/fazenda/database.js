const { pool } = require('../database');

async function initFazendaDatabase() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS fazendas (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        nome VARCHAR(100) DEFAULT 'Minha Fazenda',
        nivel INTEGER DEFAULT 1,
        exp BIGINT DEFAULT 0,
        moedas_fazenda BIGINT DEFAULT 1000,
        energia INTEGER DEFAULT 100,
        max_energia INTEGER DEFAULT 100,
        slots_plantio INTEGER DEFAULT 6,
        estacao VARCHAR(20) DEFAULT 'PRIMAVERA',
        clima VARCHAR(20) DEFAULT 'ENSOLARADO',
        ultimo_clima TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ultima_estacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_plantacoes (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        slot INTEGER NOT NULL,
        planta_tipo VARCHAR(50) NOT NULL,
        raridade VARCHAR(20) DEFAULT 'COMUM',
        mutacao VARCHAR(50),
        agua INTEGER DEFAULT 0,
        fertilizante VARCHAR(50),
        plantado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        pronto_em TIMESTAMP,
        regado_em TIMESTAMP,
        esta_estufa BOOLEAN DEFAULT FALSE,
        UNIQUE(user_id, guild_id, slot)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_animais (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        animal_tipo VARCHAR(50) NOT NULL,
        nome VARCHAR(100),
        nivel INTEGER DEFAULT 1,
        felicidade INTEGER DEFAULT 100,
        saude INTEGER DEFAULT 100,
        doenca VARCHAR(50),
        ultimo_produto TIMESTAMP,
        ultimo_alimentado TIMESTAMP,
        construcao_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_construcoes (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        construcao_tipo VARCHAR(50) NOT NULL,
        nivel INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id, construcao_tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_ferramentas (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        ferramenta_tipo VARCHAR(50) NOT NULL,
        nivel INTEGER DEFAULT 1,
        durabilidade INTEGER DEFAULT 50,
        max_durabilidade INTEGER DEFAULT 50,
        encantamento VARCHAR(50),
        encantamento_nivel INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, guild_id, ferramenta_tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_inventario (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        item_tipo VARCHAR(100) NOT NULL,
        quantidade INTEGER DEFAULT 0,
        raridade VARCHAR(20),
        UNIQUE(user_id, guild_id, item_tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_mercado (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        item_tipo VARCHAR(100) NOT NULL,
        preco_atual BIGINT,
        variacao FLOAT DEFAULT 1.0,
        ultima_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guild_id, item_tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_contratos (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        contrato_tipo VARCHAR(50) NOT NULL,
        item_pedido VARCHAR(100) NOT NULL,
        quantidade_pedida INTEGER NOT NULL,
        quantidade_entregue INTEGER DEFAULT 0,
        recompensa BIGINT,
        prazo TIMESTAMP,
        status VARCHAR(20) DEFAULT 'ativo',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_eventos (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        evento_tipo VARCHAR(50) NOT NULL,
        ativo BOOLEAN DEFAULT TRUE,
        inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        fim TIMESTAMP,
        dados JSONB
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_guildas (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL UNIQUE,
        descricao TEXT,
        lider_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        nivel INTEGER DEFAULT 1,
        exp BIGINT DEFAULT 0,
        membros INTEGER DEFAULT 1,
        max_membros INTEGER DEFAULT 10,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_guilda_membros (
        id SERIAL PRIMARY KEY,
        guilda_id INTEGER REFERENCES fazenda_guildas(id),
        user_id VARCHAR(255) NOT NULL,
        cargo VARCHAR(50) DEFAULT 'membro',
        contribuicao BIGINT DEFAULT 0,
        joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(guilda_id, user_id)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_trocas (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        item_oferecido VARCHAR(100) NOT NULL,
        quantidade_oferecida INTEGER NOT NULL,
        item_desejado VARCHAR(100) NOT NULL,
        quantidade_desejada INTEGER NOT NULL,
        status VARCHAR(20) DEFAULT 'aberta',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_competicoes (
        id SERIAL PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        tipo VARCHAR(50) NOT NULL,
        participantes JSONB DEFAULT '[]',
        premio BIGINT,
        inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        fim TIMESTAMP,
        vencedor_id VARCHAR(255),
        status VARCHAR(20) DEFAULT 'ativa'
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_exploracao (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        tipo VARCHAR(50) NOT NULL,
        profundidade INTEGER DEFAULT 1,
        ultima_exploracao TIMESTAMP,
        UNIQUE(user_id, guild_id, tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_receitas_desbloqueadas (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        receita_tipo VARCHAR(100) NOT NULL,
        UNIQUE(user_id, guild_id, receita_tipo)
      )
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS fazenda_hibridos_desbloqueados (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        guild_id VARCHAR(255) NOT NULL,
        hibrido_tipo VARCHAR(100) NOT NULL,
        UNIQUE(user_id, guild_id, hibrido_tipo)
      )
    `);

    console.log('Banco de dados da fazenda inicializado!');
  } catch (error) {
    console.error('Erro ao inicializar banco de dados da fazenda:', error);
  } finally {
    client.release();
  }
}

async function getFazenda(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazendas WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      `INSERT INTO fazendas (user_id, guild_id) VALUES ($1, $2)`,
      [userId, guildId]
    );
    return getFazenda(userId, guildId);
  }
  
  return result.rows[0];
}

async function updateFazenda(userId, guildId, updates) {
  const keys = Object.keys(updates);
  const values = Object.values(updates);
  const setClause = keys.map((k, i) => `${k} = $${i + 3}`).join(', ');
  
  await pool.query(
    `UPDATE fazendas SET ${setClause} WHERE user_id = $1 AND guild_id = $2`,
    [userId, guildId, ...values]
  );
}

async function getPlantacoes(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazenda_plantacoes WHERE user_id = $1 AND guild_id = $2 ORDER BY slot',
    [userId, guildId]
  );
  return result.rows;
}

async function plantar(userId, guildId, slot, plantaTipo, fertilizante = null, estufa = false, tempoCrescimento) {
  const prontoEm = new Date(Date.now() + tempoCrescimento * 60 * 1000);
  
  await pool.query(
    `INSERT INTO fazenda_plantacoes (user_id, guild_id, slot, planta_tipo, fertilizante, esta_estufa, pronto_em)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     ON CONFLICT (user_id, guild_id, slot) DO UPDATE SET
     planta_tipo = $4, fertilizante = $5, esta_estufa = $6, pronto_em = $7,
     plantado_em = CURRENT_TIMESTAMP, agua = 0, raridade = 'COMUM', mutacao = NULL`,
    [userId, guildId, slot, plantaTipo, fertilizante, estufa, prontoEm]
  );
}

async function regar(userId, guildId, slot, quantidade) {
  await pool.query(
    `UPDATE fazenda_plantacoes SET agua = agua + $4, regado_em = CURRENT_TIMESTAMP
     WHERE user_id = $1 AND guild_id = $2 AND slot = $3`,
    [userId, guildId, slot, quantidade]
  );
}

async function colher(userId, guildId, slot) {
  const result = await pool.query(
    'DELETE FROM fazenda_plantacoes WHERE user_id = $1 AND guild_id = $2 AND slot = $3 RETURNING *',
    [userId, guildId, slot]
  );
  return result.rows[0];
}

async function getAnimais(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazenda_animais WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function adicionarAnimal(userId, guildId, animalTipo, nome, construcaoId) {
  await pool.query(
    `INSERT INTO fazenda_animais (user_id, guild_id, animal_tipo, nome, construcao_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [userId, guildId, animalTipo, nome, construcaoId]
  );
}

async function atualizarAnimal(animalId, updates) {
  const keys = Object.keys(updates);
  const values = Object.values(updates);
  const setClause = keys.map((k, i) => `${k} = $${i + 2}`).join(', ');
  
  await pool.query(
    `UPDATE fazenda_animais SET ${setClause} WHERE id = $1`,
    [animalId, ...values]
  );
}

async function getConstrucoes(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazenda_construcoes WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function construir(userId, guildId, construcaoTipo) {
  await pool.query(
    `INSERT INTO fazenda_construcoes (user_id, guild_id, construcao_tipo)
     VALUES ($1, $2, $3)
     ON CONFLICT (user_id, guild_id, construcao_tipo) DO NOTHING`,
    [userId, guildId, construcaoTipo]
  );
}

async function upgradarConstrucao(userId, guildId, construcaoTipo) {
  await pool.query(
    `UPDATE fazenda_construcoes SET nivel = nivel + 1
     WHERE user_id = $1 AND guild_id = $2 AND construcao_tipo = $3`,
    [userId, guildId, construcaoTipo]
  );
}

async function getFerramentas(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazenda_ferramentas WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function adicionarFerramenta(userId, guildId, ferramentaTipo, durabilidade) {
  await pool.query(
    `INSERT INTO fazenda_ferramentas (user_id, guild_id, ferramenta_tipo, durabilidade, max_durabilidade)
     VALUES ($1, $2, $3, $4, $4)
     ON CONFLICT (user_id, guild_id, ferramenta_tipo) DO NOTHING`,
    [userId, guildId, ferramentaTipo, durabilidade]
  );
}

async function atualizarFerramenta(userId, guildId, ferramentaTipo, updates) {
  const keys = Object.keys(updates);
  const values = Object.values(updates);
  const setClause = keys.map((k, i) => `${k} = $${i + 4}`).join(', ');
  
  await pool.query(
    `UPDATE fazenda_ferramentas SET ${setClause}
     WHERE user_id = $1 AND guild_id = $2 AND ferramenta_tipo = $3`,
    [userId, guildId, ferramentaTipo, ...values]
  );
}

async function getInventarioFazenda(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM fazenda_inventario WHERE user_id = $1 AND guild_id = $2 AND quantidade > 0',
    [userId, guildId]
  );
  return result.rows;
}

async function adicionarItemFazenda(userId, guildId, itemTipo, quantidade, raridade = null) {
  await pool.query(
    `INSERT INTO fazenda_inventario (user_id, guild_id, item_tipo, quantidade, raridade)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (user_id, guild_id, item_tipo) DO UPDATE SET
     quantidade = fazenda_inventario.quantidade + $4`,
    [userId, guildId, itemTipo, quantidade, raridade]
  );
}

async function removerItemFazenda(userId, guildId, itemTipo, quantidade) {
  await pool.query(
    `UPDATE fazenda_inventario SET quantidade = quantidade - $4
     WHERE user_id = $1 AND guild_id = $2 AND item_tipo = $3`,
    [userId, guildId, itemTipo, quantidade]
  );
}

async function getContratos(userId, guildId) {
  const result = await pool.query(
    `SELECT * FROM fazenda_contratos WHERE user_id = $1 AND guild_id = $2 AND status = 'ativo'`,
    [userId, guildId]
  );
  return result.rows;
}

async function criarContrato(userId, guildId, contratoTipo, itemPedido, quantidade, recompensa, prazoMinutos) {
  const prazo = new Date(Date.now() + prazoMinutos * 60 * 1000);
  await pool.query(
    `INSERT INTO fazenda_contratos (user_id, guild_id, contrato_tipo, item_pedido, quantidade_pedida, recompensa, prazo)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [userId, guildId, contratoTipo, itemPedido, quantidade, recompensa, prazo]
  );
}

async function getEventosAtivos(guildId) {
  const result = await pool.query(
    `SELECT * FROM fazenda_eventos WHERE guild_id = $1 AND ativo = true AND fim > CURRENT_TIMESTAMP`,
    [guildId]
  );
  return result.rows;
}

async function criarEvento(guildId, eventoTipo, duracaoMinutos, dados = {}) {
  const fim = new Date(Date.now() + duracaoMinutos * 60 * 1000);
  await pool.query(
    `INSERT INTO fazenda_eventos (guild_id, evento_tipo, fim, dados)
     VALUES ($1, $2, $3, $4)`,
    [guildId, eventoTipo, fim, JSON.stringify(dados)]
  );
}

async function getExploracao(userId, guildId, tipo) {
  const result = await pool.query(
    'SELECT * FROM fazenda_exploracao WHERE user_id = $1 AND guild_id = $2 AND tipo = $3',
    [userId, guildId, tipo]
  );
  
  if (result.rows.length === 0) {
    await pool.query(
      `INSERT INTO fazenda_exploracao (user_id, guild_id, tipo) VALUES ($1, $2, $3)`,
      [userId, guildId, tipo]
    );
    return { profundidade: 1, ultima_exploracao: null };
  }
  
  return result.rows[0];
}

async function atualizarExploracao(userId, guildId, tipo, profundidade) {
  await pool.query(
    `UPDATE fazenda_exploracao SET profundidade = $4, ultima_exploracao = CURRENT_TIMESTAMP
     WHERE user_id = $1 AND guild_id = $2 AND tipo = $3`,
    [userId, guildId, tipo, profundidade]
  );
}

module.exports = {
  initFazendaDatabase,
  getFazenda,
  updateFazenda,
  getPlantacoes,
  plantar,
  regar,
  colher,
  getAnimais,
  adicionarAnimal,
  atualizarAnimal,
  getConstrucoes,
  construir,
  upgradarConstrucao,
  getFerramentas,
  adicionarFerramenta,
  atualizarFerramenta,
  getInventarioFazenda,
  adicionarItemFazenda,
  removerItemFazenda,
  getContratos,
  criarContrato,
  getEventosAtivos,
  criarEvento,
  getExploracao,
  atualizarExploracao
};
