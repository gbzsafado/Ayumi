const ESTACOES = {
  PRIMAVERA: { nome: 'Primavera', emoji: '🌸', bonus_crescimento: 1.2, chance_chuva: 0.3 },
  VERAO: { nome: 'Verão', emoji: '☀️', bonus_crescimento: 1.0, chance_chuva: 0.1 },
  OUTONO: { nome: 'Outono', emoji: '🍂', bonus_crescimento: 0.9, chance_chuva: 0.4 },
  INVERNO: { nome: 'Inverno', emoji: '❄️', bonus_crescimento: 0.5, chance_chuva: 0.2 }
};

const CLIMAS = {
  ENSOLARADO: { nome: 'Ensolarado', emoji: '☀️', bonus: 1.1, agua: -2 },
  NUBLADO: { nome: 'Nublado', emoji: '☁️', bonus: 1.0, agua: 0 },
  CHUVOSO: { nome: 'Chuvoso', emoji: '🌧️', bonus: 0.9, agua: 3 },
  TEMPESTADE: { nome: 'Tempestade', emoji: '⛈️', bonus: 0.7, agua: 5, chance_dano: 0.1 },
  SECA: { nome: 'Seca', emoji: '🏜️', bonus: 0.6, agua: -5 },
  NEVANDO: { nome: 'Nevando', emoji: '🌨️', bonus: 0.3, agua: 1 }
};

const RARIDADES = {
  COMUM: { nome: 'Comum', cor: '⬜', multiplicador: 1.0, chance: 0.50 },
  INCOMUM: { nome: 'Incomum', cor: '🟩', multiplicador: 1.5, chance: 0.25 },
  RARO: { nome: 'Raro', cor: '🟦', multiplicador: 2.5, chance: 0.15 },
  EPICO: { nome: 'Épico', cor: '🟪', multiplicador: 4.0, chance: 0.08 },
  LENDARIO: { nome: 'Lendário', cor: '🟨', multiplicador: 8.0, chance: 0.02 }
};

const PLANTAS = {
  trigo: { nome: 'Trigo', emoji: '🌾', tempo: 30, preco_semente: 10, preco_venda: 25, agua_necessaria: 2, estacao: ['PRIMAVERA', 'VERAO'], raridade_base: 'COMUM' },
  cenoura: { nome: 'Cenoura', emoji: '🥕', tempo: 45, preco_semente: 15, preco_venda: 40, agua_necessaria: 3, estacao: ['PRIMAVERA', 'OUTONO'], raridade_base: 'COMUM' },
  tomate: { nome: 'Tomate', emoji: '🍅', tempo: 60, preco_semente: 25, preco_venda: 65, agua_necessaria: 4, estacao: ['VERAO'], raridade_base: 'COMUM' },
  milho: { nome: 'Milho', emoji: '🌽', tempo: 90, preco_semente: 30, preco_venda: 85, agua_necessaria: 3, estacao: ['VERAO', 'OUTONO'], raridade_base: 'COMUM' },
  batata: { nome: 'Batata', emoji: '🥔', tempo: 75, preco_semente: 20, preco_venda: 55, agua_necessaria: 2, estacao: ['PRIMAVERA', 'OUTONO'], raridade_base: 'COMUM' },
  morango: { nome: 'Morango', emoji: '🍓', tempo: 50, preco_semente: 35, preco_venda: 90, agua_necessaria: 4, estacao: ['PRIMAVERA'], raridade_base: 'INCOMUM' },
  abobora: { nome: 'Abóbora', emoji: '🎃', tempo: 120, preco_semente: 50, preco_venda: 150, agua_necessaria: 3, estacao: ['OUTONO'], raridade_base: 'INCOMUM' },
  melancia: { nome: 'Melancia', emoji: '🍉', tempo: 150, preco_semente: 80, preco_venda: 220, agua_necessaria: 5, estacao: ['VERAO'], raridade_base: 'INCOMUM' },
  uva: { nome: 'Uva', emoji: '🍇', tempo: 180, preco_semente: 100, preco_venda: 300, agua_necessaria: 4, estacao: ['OUTONO'], raridade_base: 'RARO' },
  maca: { nome: 'Maçã', emoji: '🍎', tempo: 240, preco_semente: 150, preco_venda: 400, agua_necessaria: 3, estacao: ['OUTONO'], raridade_base: 'RARO' },
  rosa_mistica: { nome: 'Rosa Mística', emoji: '🌹', tempo: 300, preco_semente: 500, preco_venda: 1500, agua_necessaria: 6, estacao: ['PRIMAVERA'], raridade_base: 'EPICO' },
  flor_lunar: { nome: 'Flor Lunar', emoji: '🌙', tempo: 480, preco_semente: 1000, preco_venda: 3500, agua_necessaria: 4, estacao: ['INVERNO'], raridade_base: 'EPICO', requer_lua_cheia: true },
  arvore_dourada: { nome: 'Árvore Dourada', emoji: '🌳', tempo: 720, preco_semente: 5000, preco_venda: 15000, agua_necessaria: 8, estacao: ['PRIMAVERA', 'VERAO'], raridade_base: 'LENDARIO' },
  cristal_vegetal: { nome: 'Cristal Vegetal', emoji: '💎', tempo: 1440, preco_semente: 10000, preco_venda: 50000, agua_necessaria: 10, estacao: ['INVERNO'], raridade_base: 'LENDARIO' }
};

const FERTILIZANTES = {
  basico: { nome: 'Fertilizante Básico', emoji: '🧪', preco: 50, bonus_crescimento: 1.2, bonus_raridade: 0 },
  qualidade: { nome: 'Fertilizante de Qualidade', emoji: '⚗️', preco: 150, bonus_crescimento: 1.0, bonus_raridade: 0.1 },
  velocidade: { nome: 'Fertilizante Veloz', emoji: '⚡', preco: 200, bonus_crescimento: 1.5, bonus_raridade: 0 },
  premium: { nome: 'Fertilizante Premium', emoji: '✨', preco: 500, bonus_crescimento: 1.3, bonus_raridade: 0.15 },
  divino: { nome: 'Fertilizante Divino', emoji: '👼', preco: 2000, bonus_crescimento: 2.0, bonus_raridade: 0.25 }
};

const ANIMAIS = {
  galinha: { nome: 'Galinha', emoji: '🐔', preco: 500, produto: 'ovo', emoji_produto: '🥚', tempo_producao: 60, preco_produto: 30, alimentacao: 'racao_galinha', felicidade_decay: 2 },
  vaca: { nome: 'Vaca', emoji: '🐄', preco: 2000, produto: 'leite', emoji_produto: '🥛', tempo_producao: 120, preco_produto: 80, alimentacao: 'feno', felicidade_decay: 3 },
  ovelha: { nome: 'Ovelha', emoji: '🐑', preco: 1500, produto: 'la', emoji_produto: '🧶', tempo_producao: 180, preco_produto: 120, alimentacao: 'feno', felicidade_decay: 2 },
  porco: { nome: 'Porco', emoji: '🐷', preco: 1800, produto: 'trufa', emoji_produto: '🍄', tempo_producao: 240, preco_produto: 200, alimentacao: 'racao_porco', felicidade_decay: 4 },
  cabra: { nome: 'Cabra', emoji: '🐐', preco: 2500, produto: 'leite_cabra', emoji_produto: '🧀', tempo_producao: 150, preco_produto: 150, alimentacao: 'feno', felicidade_decay: 3 },
  abelha: { nome: 'Abelha', emoji: '🐝', preco: 3000, produto: 'mel', emoji_produto: '🍯', tempo_producao: 300, preco_produto: 250, alimentacao: 'flores', felicidade_decay: 1 },
  coelho: { nome: 'Coelho', emoji: '🐰', preco: 800, produto: 'pelo_coelho', emoji_produto: '🧣', tempo_producao: 200, preco_produto: 100, alimentacao: 'cenoura', felicidade_decay: 2 },
  pato: { nome: 'Pato', emoji: '🦆', preco: 600, produto: 'pena', emoji_produto: '🪶', tempo_producao: 90, preco_produto: 45, alimentacao: 'racao_galinha', felicidade_decay: 2 },
  cavalo: { nome: 'Cavalo', emoji: '🐴', preco: 10000, produto: null, emoji_produto: null, tempo_producao: 0, preco_produto: 0, alimentacao: 'feno', felicidade_decay: 5, bonus: 'velocidade_colheita' },
  dinossauro: { nome: 'Dinossauro', emoji: '🦖', preco: 100000, produto: 'ovo_dino', emoji_produto: '🥚', tempo_producao: 720, preco_produto: 5000, alimentacao: 'carne', felicidade_decay: 8 }
};

const DOENCAS_ANIMAIS = {
  gripe: { nome: 'Gripe', emoji: '🤧', reducao_producao: 0.5, cura: 'remedio_basico', custo_cura: 100 },
  infeccao: { nome: 'Infecção', emoji: '🦠', reducao_producao: 0.3, cura: 'antibiotico', custo_cura: 300 },
  febre: { nome: 'Febre', emoji: '🤒', reducao_producao: 0.6, cura: 'remedio_basico', custo_cura: 150 },
  parasitas: { nome: 'Parasitas', emoji: '🐛', reducao_producao: 0.4, cura: 'antiparasitario', custo_cura: 250 },
  depressao: { nome: 'Depressão', emoji: '😢', reducao_producao: 0.7, cura: 'carinho', custo_cura: 0 }
};

const CONSTRUCOES = {
  celeiro: { nome: 'Celeiro', emoji: '🏠', preco_base: 5000, capacidade_animais: 4, upgrade_multiplicador: 2, max_nivel: 5 },
  galinheiro: { nome: 'Galinheiro', emoji: '🏡', preco_base: 2000, capacidade_animais: 6, upgrade_multiplicador: 1.5, max_nivel: 5 },
  estufa: { nome: 'Estufa', emoji: '🏗️', preco_base: 10000, bonus: 'ignora_estacao', slots_planta: 6, upgrade_multiplicador: 2, max_nivel: 3 },
  silo: { nome: 'Silo', emoji: '🏭', preco_base: 8000, capacidade_armazenamento: 500, upgrade_multiplicador: 2, max_nivel: 5 },
  moinho: { nome: 'Moinho', emoji: '⚙️', preco_base: 15000, receitas: ['farinha', 'acucar', 'oleo'], upgrade_multiplicador: 1.5, max_nivel: 3 },
  queijaria: { nome: 'Queijaria', emoji: '🧀', preco_base: 20000, receitas: ['queijo', 'manteiga', 'iogurte'], upgrade_multiplicador: 1.5, max_nivel: 3 },
  oficina: { nome: 'Oficina', emoji: '🔧', preco_base: 25000, bonus: 'reparar_ferramentas', upgrade_multiplicador: 2, max_nivel: 3 },
  cozinha: { nome: 'Cozinha', emoji: '👨‍🍳', preco_base: 12000, receitas: 'culinaria', upgrade_multiplicador: 1.5, max_nivel: 5 },
  destilaria: { nome: 'Destilaria', emoji: '🍷', preco_base: 30000, receitas: ['vinho', 'cerveja', 'whisky'], upgrade_multiplicador: 2, max_nivel: 3 },
  secador: { nome: 'Secador', emoji: '🌡️', preco_base: 8000, receitas: ['frutas_secas', 'ervas_secas'], upgrade_multiplicador: 1.5, max_nivel: 3 },
  laboratorio: { nome: 'Laboratório', emoji: '🔬', preco_base: 50000, receitas: 'pocoes', upgrade_multiplicador: 2, max_nivel: 3 },
  trator: { nome: 'Trator', emoji: '🚜', preco_base: 100000, bonus: 'colheita_automatica', upgrade_multiplicador: 3, max_nivel: 3 },
  casa: { nome: 'Casa do Fazendeiro', emoji: '🏘️', preco_base: 50000, bonus: 'energia_extra', upgrade_multiplicador: 2, max_nivel: 5 },
  mercado: { nome: 'Mercado', emoji: '🏪', preco_base: 40000, bonus: 'venda_direta', upgrade_multiplicador: 1.5, max_nivel: 3 },
  banco: { nome: 'Banco', emoji: '🏦', preco_base: 75000, bonus: 'juros_diarios', upgrade_multiplicador: 2, max_nivel: 3 }
};

const FERRAMENTAS = {
  enxada: { nome: 'Enxada', emoji: '⛏️', preco_base: 100, durabilidade_base: 50, bonus: 'plantar', upgrade_multiplicador: 1.5 },
  regador: { nome: 'Regador', emoji: '🚿', preco_base: 80, durabilidade_base: 100, bonus: 'regar', upgrade_multiplicador: 1.3 },
  foice: { nome: 'Foice', emoji: '🔪', preco_base: 150, durabilidade_base: 40, bonus: 'colher', upgrade_multiplicador: 1.5 },
  machado: { nome: 'Machado', emoji: '🪓', preco_base: 200, durabilidade_base: 60, bonus: 'cortar_arvore', upgrade_multiplicador: 1.6 },
  picareta: { nome: 'Picareta', emoji: '⛏️', preco_base: 250, durabilidade_base: 80, bonus: 'minerar', upgrade_multiplicador: 1.7 },
  vara_pesca: { nome: 'Vara de Pesca', emoji: '🎣', preco_base: 120, durabilidade_base: 70, bonus: 'pescar', upgrade_multiplicador: 1.4 },
  tesoura: { nome: 'Tesoura', emoji: '✂️', preco_base: 180, durabilidade_base: 90, bonus: 'tosquiar', upgrade_multiplicador: 1.3 },
  balde: { nome: 'Balde', emoji: '🪣', preco_base: 60, durabilidade_base: 150, bonus: 'ordenhar', upgrade_multiplicador: 1.2 }
};

const NIVEIS_FERRAMENTA = {
  1: { nome: 'Básica', material: null, cor: '⬜' },
  2: { nome: 'Cobre', material: 'cobre', cor: '🟧', custo: 500 },
  3: { nome: 'Ferro', material: 'ferro', cor: '⬛', custo: 1500 },
  4: { nome: 'Ouro', material: 'ouro', cor: '🟨', custo: 5000 },
  5: { nome: 'Diamante', material: 'diamante', cor: '💎', custo: 15000 },
  6: { nome: 'Mística', material: 'essencia_mistica', cor: '🟪', custo: 50000 }
};

const ENCANTAMENTOS = {
  eficiencia: { nome: 'Eficiência', emoji: '⚡', bonus: 'velocidade', max_nivel: 5, custo_base: 1000 },
  durabilidade: { nome: 'Durabilidade', emoji: '🛡️', bonus: 'durabilidade', max_nivel: 5, custo_base: 800 },
  fortuna: { nome: 'Fortuna', emoji: '🍀', bonus: 'drop_extra', max_nivel: 3, custo_base: 2000 },
  toque_suave: { nome: 'Toque Suave', emoji: '🤲', bonus: 'qualidade', max_nivel: 3, custo_base: 1500 },
  autorreparacao: { nome: 'Autorreparação', emoji: '🔄', bonus: 'reparar', max_nivel: 2, custo_base: 5000 }
};

const MINERIOS = {
  pedra: { nome: 'Pedra', emoji: '🪨', preco: 5, chance: 0.40, profundidade_min: 1 },
  carvao: { nome: 'Carvão', emoji: '�ite', preco: 15, chance: 0.25, profundidade_min: 1 },
  cobre: { nome: 'Cobre', emoji: '🟧', preco: 50, chance: 0.15, profundidade_min: 5 },
  ferro: { nome: 'Ferro', emoji: '⬛', preco: 100, chance: 0.10, profundidade_min: 10 },
  ouro: { nome: 'Ouro', emoji: '🟡', preco: 300, chance: 0.05, profundidade_min: 20 },
  diamante: { nome: 'Diamante', emoji: '💎', preco: 1000, chance: 0.02, profundidade_min: 30 },
  esmeralda: { nome: 'Esmeralda', emoji: '💚', preco: 800, chance: 0.03, profundidade_min: 25 },
  rubi: { nome: 'Rubi', emoji: '❤️', preco: 1200, chance: 0.015, profundidade_min: 35 },
  cristal_magico: { nome: 'Cristal Mágico', emoji: '🔮', preco: 5000, chance: 0.005, profundidade_min: 50 }
};

const PLANTAS_SELVAGENS = {
  erva_curativa: { nome: 'Erva Curativa', emoji: '🌿', preco: 50, chance: 0.20, regiao: 'floresta' },
  cogumelo: { nome: 'Cogumelo', emoji: '🍄', preco: 30, chance: 0.25, regiao: 'floresta' },
  flor_silvestre: { nome: 'Flor Silvestre', emoji: '🌸', preco: 40, chance: 0.20, regiao: 'campo' },
  raiz_antiga: { nome: 'Raiz Antiga', emoji: '🪵', preco: 100, chance: 0.10, regiao: 'floresta' },
  orquidea_rara: { nome: 'Orquídea Rara', emoji: '🌺', preco: 500, chance: 0.03, regiao: 'floresta' },
  trebol_4folhas: { nome: 'Trevo de 4 Folhas', emoji: '🍀', preco: 1000, chance: 0.01, regiao: 'campo' },
  fungo_luminoso: { nome: 'Fungo Luminoso', emoji: '✨', preco: 800, chance: 0.02, regiao: 'caverna' }
};

const RECEITAS_COZINHA = {
  pao: { nome: 'Pão', emoji: '🍞', ingredientes: { farinha: 2 }, preco: 50, exp: 10 },
  salada: { nome: 'Salada', emoji: '🥗', ingredientes: { tomate: 2, cenoura: 1 }, preco: 80, exp: 15 },
  sopa: { nome: 'Sopa', emoji: '🍲', ingredientes: { batata: 2, cenoura: 1, tomate: 1 }, preco: 120, exp: 25 },
  bolo: { nome: 'Bolo', emoji: '🎂', ingredientes: { farinha: 3, ovo: 2, leite: 1 }, preco: 200, exp: 40 },
  pizza: { nome: 'Pizza', emoji: '🍕', ingredientes: { farinha: 2, tomate: 3, queijo: 2 }, preco: 350, exp: 60 },
  torta_fruta: { nome: 'Torta de Frutas', emoji: '🥧', ingredientes: { farinha: 2, morango: 3, acucar: 1 }, preco: 400, exp: 70 },
  queijo: { nome: 'Queijo', emoji: '🧀', ingredientes: { leite: 5 }, preco: 150, exp: 30, requer: 'queijaria' },
  vinho: { nome: 'Vinho', emoji: '🍷', ingredientes: { uva: 10 }, preco: 800, exp: 100, requer: 'destilaria' },
  geleia: { nome: 'Geleia', emoji: '🫙', ingredientes: { morango: 5, acucar: 2 }, preco: 180, exp: 35 },
  mel_processado: { nome: 'Mel Processado', emoji: '🍯', ingredientes: { mel: 3 }, preco: 400, exp: 50 }
};

const POCOES = {
  cura_menor: { nome: 'Poção de Cura Menor', emoji: '❤️', ingredientes: { erva_curativa: 3 }, efeito: 'cura_50', preco: 100 },
  cura_maior: { nome: 'Poção de Cura Maior', emoji: '💖', ingredientes: { erva_curativa: 5, flor_silvestre: 2 }, efeito: 'cura_100', preco: 300 },
  velocidade: { nome: 'Poção de Velocidade', emoji: '💨', ingredientes: { cogumelo: 3, raiz_antiga: 1 }, efeito: 'velocidade_2x', preco: 250 },
  forca: { nome: 'Poção de Força', emoji: '💪', ingredientes: { raiz_antiga: 3, cogumelo: 2 }, efeito: 'ataque_1.5x', preco: 350 },
  sorte: { nome: 'Poção de Sorte', emoji: '🍀', ingredientes: { trebol_4folhas: 1, orquidea_rara: 1 }, efeito: 'drop_2x', preco: 2000 },
  crescimento: { nome: 'Poção de Crescimento', emoji: '🌱', ingredientes: { erva_curativa: 5, fungo_luminoso: 1 }, efeito: 'crescimento_2x', preco: 1500 }
};

const EVENTOS = {
  praga: { nome: 'Praga de Insetos', emoji: '🦗', chance: 0.05, efeito: 'dano_plantas', duracao: 60 },
  seca: { nome: 'Seca Severa', emoji: '🏜️', chance: 0.03, efeito: 'agua_zero', duracao: 120 },
  bencao: { nome: 'Bênção da Natureza', emoji: '✨', chance: 0.02, efeito: 'crescimento_3x', duracao: 60 },
  lua_cheia: { nome: 'Lua Cheia', emoji: '🌕', chance: 0.10, efeito: 'plantas_especiais', duracao: 30 },
  feira_colheita: { nome: 'Feira da Colheita', emoji: '🎪', chance: 0.05, efeito: 'precos_2x', duracao: 120 },
  npc_viajante: { nome: 'Viajante Misterioso', emoji: '🧙', chance: 0.01, efeito: 'itens_raros', duracao: 30 },
  tempestade_magica: { nome: 'Tempestade Mágica', emoji: '⚡', chance: 0.02, efeito: 'mutacao_chance', duracao: 60 },
  invasao_animais: { nome: 'Invasão de Animais', emoji: '🐗', chance: 0.04, efeito: 'dano_fazenda', duracao: 30 }
};

const NPCS = {
  comerciante: { nome: 'Comerciante', emoji: '🧑‍💼', tipo: 'comprador', multiplicador: 1.0 },
  chef: { nome: 'Chef Gourmet', emoji: '👨‍🍳', tipo: 'comprador', multiplicador: 1.3, prefere: ['receitas'] },
  alquimista: { nome: 'Alquimista', emoji: '🧙‍♂️', tipo: 'comprador', multiplicador: 1.5, prefere: ['pocoes', 'ervas'] },
  colecionador: { nome: 'Colecionador', emoji: '🎩', tipo: 'comprador', multiplicador: 2.0, prefere: ['raros'] },
  viajante: { nome: 'Viajante Misterioso', emoji: '🧳', tipo: 'vendedor_raro', items: ['sementes_lendarias', 'ferramentas_encantadas'] },
  ferreiro: { nome: 'Ferreiro', emoji: '⚒️', tipo: 'servico', servico: 'upgrade_ferramentas' }
};

const CONTRATOS = {
  entrega_rapida: { nome: 'Entrega Rápida', prazo: 60, recompensa_base: 500, penalidade: 0.5 },
  grande_pedido: { nome: 'Grande Pedido', prazo: 180, recompensa_base: 2000, penalidade: 0.3 },
  qualidade_premium: { nome: 'Qualidade Premium', prazo: 120, recompensa_base: 1500, penalidade: 0.4, requer_raridade: 'RARO' },
  exportacao: { nome: 'Exportação', prazo: 300, recompensa_base: 5000, penalidade: 0.2 }
};

const MUTACOES = {
  gigante: { nome: 'Gigante', emoji: '🦣', bonus_valor: 2.0, chance: 0.05 },
  brilhante: { nome: 'Brilhante', emoji: '✨', bonus_valor: 1.5, chance: 0.08 },
  arco_iris: { nome: 'Arco-Íris', emoji: '🌈', bonus_valor: 3.0, chance: 0.02 },
  cristalizada: { nome: 'Cristalizada', emoji: '💎', bonus_valor: 5.0, chance: 0.01 },
  dourada: { nome: 'Dourada', emoji: '🥇', bonus_valor: 4.0, chance: 0.015 }
};

const CROSSBREEDING = {
  'tomate+morango': { resultado: 'tomate_doce', chance: 0.15 },
  'trigo+milho': { resultado: 'graos_hibridos', chance: 0.20 },
  'rosa_mistica+flor_lunar': { resultado: 'flor_cosmica', chance: 0.05 },
  'uva+maca': { resultado: 'fruta_hibrida', chance: 0.10 },
  'abobora+melancia': { resultado: 'mega_fruta', chance: 0.08 }
};

const PLANTAS_HIBRIDAS = {
  tomate_doce: { nome: 'Tomate Doce', emoji: '🍅', tempo: 80, preco_venda: 150 },
  graos_hibridos: { nome: 'Grãos Híbridos', emoji: '🌾', tempo: 60, preco_venda: 100 },
  flor_cosmica: { nome: 'Flor Cósmica', emoji: '🌌', tempo: 600, preco_venda: 10000 },
  fruta_hibrida: { nome: 'Fruta Híbrida', emoji: '🍏', tempo: 200, preco_venda: 600 },
  mega_fruta: { nome: 'Mega Fruta', emoji: '🍈', tempo: 180, preco_venda: 500 }
};

const ALIMENTACAO_ANIMAIS = {
  racao_galinha: { nome: 'Ração de Galinha', emoji: '🌰', preco: 20, duracao: 60 },
  feno: { nome: 'Feno', emoji: '🌾', preco: 30, duracao: 90 },
  racao_porco: { nome: 'Ração de Porco', emoji: '🥜', preco: 40, duracao: 120 },
  flores: { nome: 'Flores', emoji: '🌸', preco: 50, duracao: 180 },
  cenoura: { nome: 'Cenoura', emoji: '🥕', preco: 25, duracao: 60 },
  carne: { nome: 'Carne', emoji: '🥩', preco: 200, duracao: 240 }
};

const COMPETICOES = {
  melhor_colheita: { nome: 'Melhor Colheita', emoji: '🏆', premio: 10000, tipo: 'quantidade' },
  raridade_maxima: { nome: 'Raridade Máxima', emoji: '👑', premio: 25000, tipo: 'raridade' },
  velocidade: { nome: 'Colheita Rápida', emoji: '⚡', premio: 5000, tipo: 'tempo' },
  culinaria: { nome: 'Chef do Ano', emoji: '🍽️', premio: 15000, tipo: 'receitas' },
  criador: { nome: 'Melhor Criador', emoji: '🐄', premio: 20000, tipo: 'animais' }
};

module.exports = {
  ESTACOES, CLIMAS, RARIDADES, PLANTAS, FERTILIZANTES, ANIMAIS, DOENCAS_ANIMAIS,
  CONSTRUCOES, FERRAMENTAS, NIVEIS_FERRAMENTA, ENCANTAMENTOS, MINERIOS,
  PLANTAS_SELVAGENS, RECEITAS_COZINHA, POCOES, EVENTOS, NPCS, CONTRATOS,
  MUTACOES, CROSSBREEDING, PLANTAS_HIBRIDAS, ALIMENTACAO_ANIMAIS, COMPETICOES
};
