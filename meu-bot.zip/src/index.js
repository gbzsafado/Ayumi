const { Client, GatewayIntentBits, Collection, Events, REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { initDatabase, rotateShopStock } = require('./database');
const express = require('express');
const app = express();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
  ]
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

const slashCommands = [];

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  if (command.data && command.execute) {
    client.commands.set(command.data.name, command);
    slashCommands.push(command.data.toJSON());
  }
}

const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
  const filePath = path.join(eventsPath, file);
  const event = require(filePath);
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, client);
    } catch (error) {
      console.error(error);
      const errorMsg = { content: 'Ocorreu um erro ao executar esse comando!', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMsg);
      } else {
        await interaction.reply(errorMsg);
      }
    }
  }
});

const token = process.env.DISCORD_BOT_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;

if (!token) {
  console.error('ERRO: Token do Discord não encontrado!');
  console.log('Por favor, configure a variável de ambiente DISCORD_BOT_TOKEN');
  process.exit(1);
}

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(token);
  try {
    console.log('Registrando slash commands...');
    await rest.put(
      Routes.applicationCommands(clientId),
      { body: slashCommands }
    );
    console.log(`✅ ${slashCommands.length} slash commands registrados!`);
  } catch (error) {
    console.error('Erro ao registrar slash commands:', error);
  }
}

initDatabase().then(async () => {
  if (clientId) {
    await registerCommands();
  } else {
    console.log('⚠️ DISCORD_CLIENT_ID não configurado - slash commands não serão registrados');
  }
  
  client.login(token);

  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', bot: client.user?.tag || 'connecting' });
  });

  app.listen(5000, '0.0.0.0', () => {
    console.log('✅ Servidor HTTP rodando na porta 5000');
  });

  setInterval(async () => {
    try {
      const guilds = client.guilds.cache.map(g => g.id);
      for (const guildId of guilds) {
        await rotateShopStock(guildId);
      }
      console.log('✅ Estoque da loja rotacionado!');
    } catch (error) {
      console.error('Erro ao rotacionar estoque:', error);
    }
  }, 30 * 60 * 1000);
});
