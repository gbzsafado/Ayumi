const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, getGuardian, updateGuardianStats, updateGuardianLastTrain, updateGuardianAfinidade } = require('../database');
const { GUARDIAN_TYPES } = require('./guardiao');

const MSGS = ['🏋️ Flexões!', '🎯 Pontaria!', '🏃 Corrida!', '⚔️ Treino!', '🧘 Meditação!', '🤸 Acrobacias!'];

module.exports = {
  data: new SlashCommandBuilder().setName('treinar-guardiao').setDescription('Treine seu guardião (cooldown 3min)!'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const user = await getUser(userId, guildId);
    const guardian = await getGuardian(userId, guildId);
    
    if (!guardian) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Sem Guardião!')], ephemeral: true });
    
    const COOLDOWN = 3 * 60 * 1000;
    const now = new Date();
    const lastTrain = guardian.last_train ? new Date(guardian.last_train) : null;
    
    if (lastTrain && now - lastTrain < COOLDOWN) {
      const remaining = Math.ceil((COOLDOWN - (now - lastTrain)) / 60000);
      return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FFA500').setTitle('⏰ Descansando').setDescription(`Próx. treino em ${remaining}m`)], ephemeral: true });
    }
    
    const baseXP = 15 + Math.floor(Math.random() * 20);
    const bonusXP = Math.random() < 0.3 ? Math.floor(Math.random() * 15) + 5 : 0;
    const totalXP = baseXP + bonusXP;
    
    let newXP = guardian.xp + totalXP;
    let newLevel = guardian.level;
    let evolved = false;
    
    const xpNeeded = guardian.level * 50;
    if (newXP >= xpNeeded) {
      newXP -= xpNeeded;
      newLevel++;
      if (newLevel === 10 && guardian.evolution_stage === 1) evolved = true;
      if (newLevel === 20 && guardian.evolution_stage === 2) evolved = true;
    }
    
    const newStage = newLevel >= 20 ? 3 : (newLevel >= 10 ? 2 : 1);
    
    await updateGuardianStats(userId, guildId, {
      xp: newXP,
      level: newLevel,
      attack: guardian.attack + (evolved ? 5 : 0),
      defense: guardian.defense + (evolved ? 3 : 0),
      evolution_stage: newStage,
      last_train: now
    });
    
    await updateGuardianAfinidade(userId, guildId, 1);
    
    const updated = await getGuardian(userId, guildId);
    const type = GUARDIAN_TYPES[guardian.guardian_type];
    const evo = type.evolutions[newStage - 1];
    const emoji = type.evolutionEmojis[newStage - 1];
    
    let desc = `${MSGS[Math.floor(Math.random() * MSGS.length)]}\n⭐ +${baseXP}`;
    if (bonusXP > 0) desc += ` (+${bonusXP} bônus!)`;
    desc += `\n❤️ Afinidade +1%`;
    
    if (evolved) desc += `\n\n🎊 **EVOLUÇÃO!**\n${emoji} ${evo}`;
    
    return interaction.reply({ embeds: [new EmbedBuilder().setColor(evolved ? '#FFD700' : '#9B59B6').setTitle(`Treinamento`).setDescription(desc).addFields({ name: '📊 Status', value: `Nv.${newLevel} | Afinidade: ${updated.afinidade}%` })] });
  }
};
