const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, getGuardian, updateMoedas, updateRPGStats, updateGuardianAfinidade } = require('../database');
const { GUARDIAN_TYPES } = require('./guardiao');

const INIMIGOS = [
  { name: 'Goblin', emoji: '👹', health: 60, attack: 15, defense: 5, tier: 1, xp: 15 },
  { name: 'Lobo', emoji: '🐺', health: 70, attack: 18, defense: 6, tier: 1, xp: 18 },
  { name: 'Esqueleto', emoji: '💀', health: 75, attack: 16, defense: 12, tier: 1, xp: 16 },
  { name: 'Orc', emoji: '👺', health: 90, attack: 22, defense: 12, tier: 2, xp: 25 }
];

function calcDamage(att, def) {
  const base = Math.max(5, 8 + att * 0.25 - def * 0.15);
  return Math.floor(base * (Math.random() * 0.15 + 0.9));
}

function bar(c, m) {
  const p = Math.max(0, (c / m) * 100);
  const f = Math.floor(p / 10);
  const b = '█'.repeat(f) + '░'.repeat(10 - f);
  if (p > 50) return `🟩 ${b}`;
  if (p > 25) return `🟨 ${b}`;
  return `🟥 ${b}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('batalha-dupla')
    .setDescription('Lute em dupla com seu guardião contra 2 inimigos!'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const user = await getUser(userId, guildId);
    if (!user.rpg_class) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Use `/registrar`!')], ephemeral: true });
    
    const guardian = await getGuardian(userId, guildId);
    if (!guardian) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Sem Guardião!')], ephemeral: true });
    if (user.rpg_health <= 0) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Sem vida!')], ephemeral: true });
    
    const level = Math.floor((user.rpg_exp || 0) / 100) + 1;
    const mult = 1 + (level - 1) * 0.12;
    
    // Seleciona apenas 2 inimigos aleatórios
    const enemies = [];
    for (let i = 0; i < 2; i++) {
      const baseEnemy = INIMIGOS[Math.floor(Math.random() * INIMIGOS.length)];
      enemies.push({
        ...JSON.parse(JSON.stringify(baseEnemy)),
        health: Math.floor(baseEnemy.health * mult),
        max_health: Math.floor(baseEnemy.health * mult),
        attack: Math.floor(baseEnemy.attack * mult),
        defense: Math.floor(baseEnemy.defense * mult),
        id: i
      });
    }
    
    user.rpg_health = Number(user.rpg_health) || 100;
    user.rpg_max_health = Number(user.rpg_max_health) || 100;
    user.rpg_attack = Number(user.rpg_attack) || 50;
    user.rpg_defense = Number(user.rpg_defense) || 30;
    
    guardian.health = Number(guardian.health) || 50;
    guardian.max_health = Number(guardian.max_health) || 50;
    guardian.attack = Number(guardian.attack) || 30;
    
    let turn = 1;
    let phase = 'player';
    let log = ['Batalha começou!'];
    
    const showBattle = async () => {
      const type = GUARDIAN_TYPES[guardian.guardian_type];
      const stage = guardian.evolution_stage;
      let phaseText = '';
      if (phase === 'player') phaseText = '👤 Seu Turno!';
      else if (phase === 'guardian') phaseText = guardian.health > 0 ? '🛡️ Turno do Guardião!' : '💀 Guardião caído!';
      else phaseText = '👹 Turno dos Inimigos...';
      
      const guardianStatus = guardian.health > 0 ? `${bar(guardian.health, guardian.max_health)}\n❤️ ${guardian.health}/${guardian.max_health}` : '💀 Caído!';
      
      const embed = new EmbedBuilder()
        .setColor('#9B59B6')
        .setTitle(`⚔️ BATALHA EM DUPLA - TURNO ${turn}`)
        .setDescription(phaseText)
        .addFields(
          { name: `👤 ${user.character_name} (Nv.${level})`, value: `${bar(user.rpg_health, user.rpg_max_health)}\n❤️ ${user.rpg_health}/${user.rpg_max_health}`, inline: true },
          { name: `${type.evolutionEmojis[stage - 1]} ${guardian.guardian_name}`, value: guardianStatus, inline: true },
          { name: 'vs', value: '⚔️', inline: true },
          { name: '👹 Inimigos', value: enemies.map(e => `${e.emoji} ${e.name}\n${bar(e.health, e.max_health)} ❤️ ${e.health}/${e.max_health}`).join('\n\n'), inline: false },
          { name: '📜 Log', value: log.slice(-4).join('\n') || 'Começou!', inline: false }
        )
        .setTimestamp();
      
      return embed;
    };
    
    const msg = await interaction.reply({ embeds: [await showBattle()], fetchReply: true });
    const collector = msg.createMessageComponentCollector({ time: 600000 });
    
    const playerTurn = async () => {
      // Derrota: jogador morre
      if (user.rpg_health <= 0) {
        await updateRPGStats(user.user_id, user.guild_id, { health: 0 });
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('💀 Derrota').setDescription(`Você foi derrotado!\n${log.slice(-3).join('\n')}`)], components: [] });
      }
      
      // Vitória: todos inimigos morrem
      if (enemies.every(e => e.health <= 0)) {
        const xp = enemies.reduce((s, e) => s + e.xp, 0);
        const coins = Math.floor(Math.random() * 100) + 150;
        await updateMoedas(user.user_id, user.guild_id, coins);
        await updateRPGStats(user.user_id, user.guild_id, { health: user.rpg_health, exp: (user.rpg_exp || 0) + xp });
        await updateGuardianAfinidade(userId, guildId, 2);
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#00FF00').setTitle('🎉 Vitória!').setDescription(`+${xp} XP\n+${coins} 🪙\n+2% Afinidade`)], components: [] });
      }
      
      const atkBtn = new ButtonBuilder().setCustomId('atk').setLabel('⚔️ Atacar').setStyle(ButtonStyle.Danger);
      const habBtn = new ButtonBuilder().setCustomId('hab').setLabel('⚡ Habilidade').setStyle(ButtonStyle.Success);
      const defBtn = new ButtonBuilder().setCustomId('def').setLabel('🛡️ Defender').setStyle(ButtonStyle.Primary);
      await msg.edit({ embeds: [await showBattle()], components: [new ActionRowBuilder().addComponents(atkBtn, habBtn, defBtn)] });
    };
    
    const guardianTurn = async () => {
      if (user.rpg_health <= 0) {
        await updateRPGStats(user.user_id, user.guild_id, { health: 0 });
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('💀 Derrota').setDescription(`Você foi derrotado!\n${log.slice(-3).join('\n')}`)], components: [] });
      }
      
      if (enemies.every(e => e.health <= 0)) {
        const xp = enemies.reduce((s, e) => s + e.xp, 0);
        const coins = Math.floor(Math.random() * 100) + 150;
        await updateMoedas(user.user_id, user.guild_id, coins);
        await updateRPGStats(user.user_id, user.guild_id, { health: user.rpg_health, exp: (user.rpg_exp || 0) + xp });
        await updateGuardianAfinidade(userId, guildId, 2);
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#00FF00').setTitle('🎉 Vitória!').setDescription(`+${xp} XP\n+${coins} 🪙\n+2% Afinidade`)], components: [] });
      }
      
      // Se guardião está vivo, ataca
      if (guardian.health > 0) {
        const alive = enemies.filter(e => e.health > 0);
        if (alive.length > 0) {
          const target = alive[Math.floor(Math.random() * alive.length)];
          const dmg = calcDamage(guardian.attack, target.defense);
          target.health = Math.max(0, target.health - dmg);
          log.push(`${guardian.guardian_name} atacou ${target.emoji} ${target.name}! -${dmg}`);
        }
      } else {
        log.push(`${guardian.guardian_name} está caído e não pode atacar!`);
      }
      
      await msg.edit({ embeds: [await showBattle()], components: [] });
      setTimeout(enemyTurn, 1500);
    };
    
    const enemyTurn = async () => {
      if (user.rpg_health <= 0) {
        await updateRPGStats(user.user_id, user.guild_id, { health: 0 });
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('💀 Derrota').setDescription(`Você foi derrotado!\n${log.slice(-3).join('\n')}`)], components: [] });
      }
      
      if (enemies.every(e => e.health <= 0)) {
        const xp = enemies.reduce((s, e) => s + e.xp, 0);
        const coins = Math.floor(Math.random() * 100) + 150;
        await updateMoedas(user.user_id, user.guild_id, coins);
        await updateRPGStats(user.user_id, user.guild_id, { health: user.rpg_health, exp: (user.rpg_exp || 0) + xp });
        await updateGuardianAfinidade(userId, guildId, 2);
        return msg.edit({ embeds: [new EmbedBuilder().setColor('#00FF00').setTitle('🎉 Vitória!').setDescription(`+${xp} XP\n+${coins} 🪙\n+2% Afinidade`)], components: [] });
      }
      
      const alive = enemies.filter(e => e.health > 0);
      for (const enemy of alive) {
        const targets = [];
        if (user.rpg_health > 0) targets.push('user');
        if (guardian.health > 0) targets.push('guardian');
        
        if (targets.length === 0) break;
        
        const alvo = targets[Math.floor(Math.random() * targets.length)];
        const dmg = alvo === 'user' ? calcDamage(enemy.attack, user.rpg_defense) : calcDamage(enemy.attack, guardian.defense || 10);
        
        if (alvo === 'user') {
          user.rpg_health = Math.max(0, user.rpg_health - dmg);
          log.push(`${enemy.emoji} ${enemy.name} atacou você! -${dmg}`);
        } else {
          guardian.health = Math.max(0, guardian.health - dmg);
          log.push(`${enemy.emoji} ${enemy.name} atacou guardião! -${dmg}`);
        }
      }
      
      turn++;
      phase = 'player';
      await msg.edit({ embeds: [await showBattle()], components: [] });
      setTimeout(playerTurn, 1500);
    };
    
    collector.on('collect', async (i) => {
      if (i.user.id !== userId || phase !== 'player') return;
      await i.deferUpdate();
      
      const alive = enemies.filter(e => e.health > 0);
      if (alive.length === 0) return;
      
      if (i.customId === 'atk') {
        const target = alive[Math.floor(Math.random() * alive.length)];
        const dmg = calcDamage(user.rpg_attack, target.defense);
        target.health = Math.max(0, target.health - dmg);
        log.push(`⚔️ Você atacou ${target.emoji} ${target.name}! -${dmg}`);
      } else if (i.customId === 'hab') {
        const target = alive[Math.floor(Math.random() * alive.length)];
        const dmg = Math.floor(calcDamage(user.rpg_attack, target.defense) * 1.3);
        target.health = Math.max(0, target.health - dmg);
        log.push(`⚡ Habilidade em ${target.emoji} ${target.name}! -${dmg}`);
      } else if (i.customId === 'def') {
        log.push(`🛡️ Você se defendeu! (-50% próximo turno)`);
      }
      
      phase = 'guardian';
      await msg.edit({ embeds: [await showBattle()], components: [] });
      setTimeout(guardianTurn, 1500);
    });
    
    await playerTurn();
  }
};
