const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../database');

const MAPS = {
  floresta_sombria: {
    name: 'Floresta Sombria',
    emoji: '🌲',
    description: 'Uma floresta densa e misteriosa, lar de criaturas selvagens.',
    minLevel: 1,
    maxLevel: 5,
    color: '#228B22'
  },
  deserto_infernal: {
    name: 'Deserto Infernal',
    emoji: '🏜️',
    description: 'Um deserto escaldante cheio de perigos mortais.',
    minLevel: 5,
    maxLevel: 12,
    color: '#FFD700'
  }
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('viajar')
    .setDescription('Viaje para um mapa específico')
    .addStringOption(option =>
      option.setName('destino')
        .setDescription('Para onde você quer ir?')
        .setRequired(true)
        .addChoices(
          { name: '🌲 Floresta Sombria (Nível 1-5)', value: 'floresta_sombria' },
          { name: '🏜️ Deserto Infernal (Nível 5-12)', value: 'deserto_infernal' }
        )
    ),
  async prefixExecute(message, args, client) {
    return message.reply('🗺️ Use o comando `/viajar` para viajar entre mapas! (Requer seleção de destino)');
  },
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    
    if (!user.rpg_class) {
      return interaction.reply({ content: 'Use `/registrar` primeiro para criar seu personagem!', ephemeral: true });
    }

    const destino = interaction.options.getString('destino');
    const map = MAPS[destino];
    const playerLevel = Math.floor((user.rpg_exp || 0) / 100) + 1;
    const currentMap = user.current_map || 'floresta_sombria';

    if (!map) {
      return interaction.reply({ content: 'Mapa inválido!', ephemeral: true });
    }

    if (currentMap === destino) {
      return interaction.reply({ 
        content: `📍 Você já está em **${map.name}**!`, 
        ephemeral: true 
      });
    }

    if (playerLevel < map.minLevel) {
      const blockedEmbed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🔒 Acesso Bloqueado')
        .setDescription(`Você não pode acessar **${map.name}** ainda!\n\n**Seu Nível:** ${playerLevel}\n**Nível Mínimo:** ${map.minLevel}\n\n*Continue lutando para subir de nível!*`)
        .setTimestamp();

      return interaction.reply({ embeds: [blockedEmbed], ephemeral: true });
    }

    await require('../database').pool.query(
      'UPDATE users SET current_map = $1 WHERE user_id = $2 AND guild_id = $3',
      [destino, user.user_id, user.guild_id]
    );

    const travelEmbed = new EmbedBuilder()
      .setColor(map.color)
      .setTitle(`${map.emoji} Viagem Concluída!`)
      .setDescription(`**${user.character_name}** viajou para **${map.name}**!\n\n${map.description}\n\n*Use \`/lutar\` para enfrentar os inimigos deste mapa!*`)
      .addFields(
        { name: '📍 Origem', value: MAPS[currentMap]?.name || 'Aldeia', inline: true },
        { name: '🎯 Destino', value: map.name, inline: true },
        { name: '⚔️ Nível Recomendado', value: `${map.minLevel}-${map.maxLevel}`, inline: true }
      )
      .setFooter({ text: 'Boa sorte, aventureiro!' })
      .setTimestamp();

    await interaction.reply({ embeds: [travelEmbed] });
  }
};
