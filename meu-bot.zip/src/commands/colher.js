const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFazenda, updateFazenda, getPlantacoes, colher, adicionarItemFazenda, getEventosAtivos } = require('../fazenda/database');
const { PLANTAS, RARIDADES, MUTACOES } = require('../fazenda/data');

function calcularRaridade(planta, agua, fertilizante, eventos) {
  let chances = { ...RARIDADES };
  
  const plantaData = PLANTAS[planta.planta_tipo];
  if (plantaData.raridade_base !== 'COMUM') {
    const baseIdx = Object.keys(RARIDADES).indexOf(plantaData.raridade_base);
    Object.keys(chances).forEach((r, idx) => {
      if (idx < baseIdx) chances[r].chance = 0;
    });
  }

  if (agua >= plantaData.agua_necessaria) {
    chances.INCOMUM.chance += 0.05;
    chances.RARO.chance += 0.02;
  }

  if (fertilizante === 'qualidade') {
    chances.INCOMUM.chance += 0.10;
    chances.RARO.chance += 0.05;
  } else if (fertilizante === 'premium') {
    chances.INCOMUM.chance += 0.15;
    chances.RARO.chance += 0.08;
    chances.EPICO.chance += 0.02;
  }

  const temBencao = eventos.some(e => e.evento_tipo === 'bencao');
  if (temBencao) {
    Object.keys(chances).forEach(r => {
      chances[r].chance *= 1.5;
    });
  }

  const rand = Math.random();
  let acumulado = 0;
  
  for (const [key, value] of Object.entries(chances).reverse()) {
    acumulado += value.chance;
    if (rand < acumulado) return key;
  }
  
  return 'COMUM';
}

function calcularMutacao(planta, eventos) {
  const temTempestadeMagica = eventos.some(e => e.evento_tipo === 'tempestade_magica');
  const multiplicador = temTempestadeMagica ? 3 : 1;

  for (const [key, mutacao] of Object.entries(MUTACOES)) {
    if (Math.random() < mutacao.chance * multiplicador) {
      return { tipo: key, ...mutacao };
    }
  }
  return null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('colher')
    .setDescription('Colha suas plantações prontas')
    .addIntegerOption(option =>
      option.setName('slot')
        .setDescription('Slot para colher (1-12) ou 0 para colher todas prontas')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(12)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const slotInput = interaction.options.getInteger('slot');

    const fazenda = await getFazenda(userId, guildId);
    const plantacoes = await getPlantacoes(userId, guildId);
    const eventos = await getEventosAtivos(guildId);
    const agora = new Date();

    const temFeira = eventos.some(e => e.evento_tipo === 'feira_colheita');
    const multiplicadorVenda = temFeira ? 2 : 1;

    let plantasColhidas = [];
    let expTotal = 0;
    let valorTotal = 0;

    const colherPlanta = async (planta) => {
      const pronto = new Date(planta.pronto_em);
      if (agora < pronto) return null;

      const plantaData = PLANTAS[planta.planta_tipo];
      if (!plantaData) return null;

      const raridade = calcularRaridade(planta, planta.agua, planta.fertilizante, eventos);
      const mutacao = calcularMutacao(planta, eventos);
      const raridadeData = RARIDADES[raridade];

      let quantidade = 1;
      if (planta.agua >= plantaData.agua_necessaria * 2) quantidade = 2;
      if (mutacao?.tipo === 'gigante') quantidade *= 2;

      let valor = plantaData.preco_venda * raridadeData.multiplicador * quantidade * multiplicadorVenda;
      if (mutacao) valor *= mutacao.bonus_valor;

      await colher(userId, guildId, planta.slot);
      await adicionarItemFazenda(userId, guildId, planta.planta_tipo, quantidade, raridade);

      const exp = Math.floor(plantaData.tempo / 10) * (Object.keys(RARIDADES).indexOf(raridade) + 1);
      
      return {
        planta: plantaData,
        slot: planta.slot,
        raridade,
        raridadeData,
        mutacao,
        quantidade,
        valor: Math.floor(valor),
        exp
      };
    };

    if (slotInput === 0) {
      for (const planta of plantacoes) {
        if (fazenda.energia < 3) break;
        
        const resultado = await colherPlanta(planta);
        if (resultado) {
          plantasColhidas.push(resultado);
          expTotal += resultado.exp;
          valorTotal += resultado.valor;
          fazenda.energia -= 3;
        }
      }
    } else {
      const slot = slotInput - 1;
      const planta = plantacoes.find(p => p.slot === slot);
      
      if (!planta) {
        return interaction.reply({ content: `❌ Não há planta no slot ${slotInput}!`, ephemeral: true });
      }

      const pronto = new Date(planta.pronto_em);
      if (agora < pronto) {
        const minRestantes = Math.ceil((pronto - agora) / 60000);
        return interaction.reply({ content: `❌ Esta planta ainda não está pronta! Faltam ${minRestantes} minutos.`, ephemeral: true });
      }

      if (fazenda.energia < 3) {
        return interaction.reply({ content: '❌ Energia insuficiente! Você precisa de ⚡ 3 energia.', ephemeral: true });
      }

      const resultado = await colherPlanta(planta);
      if (resultado) {
        plantasColhidas.push(resultado);
        expTotal = resultado.exp;
        valorTotal = resultado.valor;
        fazenda.energia -= 3;
      }
    }

    if (plantasColhidas.length === 0) {
      return interaction.reply({ content: '❌ Nenhuma planta estava pronta para colher!', ephemeral: true });
    }

    const novoExp = fazenda.exp + expTotal;
    let novoNivel = fazenda.nivel;
    while (novoExp >= novoNivel * 1000) {
      novoNivel++;
    }

    await updateFazenda(userId, guildId, {
      moedas_fazenda: fazenda.moedas_fazenda + valorTotal,
      exp: novoExp,
      nivel: novoNivel,
      energia: fazenda.energia
    });

    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle('🌾 Colheita Realizada!')
      .setDescription(`
Você colheu **${plantasColhidas.length}** planta(s)!

${plantasColhidas.map(p => {
  let texto = `${p.raridadeData.cor} ${p.planta.emoji} **${p.planta.nome}** x${p.quantidade}`;
  texto += ` (${p.raridadeData.nome})`;
  if (p.mutacao) texto += ` ${p.mutacao.emoji} **MUTAÇÃO: ${p.mutacao.nome}!**`;
  texto += ` - 🪙 ${p.valor}`;
  return texto;
}).join('\n')}

💰 **Total ganho:** 🪙 ${valorTotal.toLocaleString()}${temFeira ? ' (2x Feira!)' : ''}
⭐ **EXP ganho:** +${expTotal}
${novoNivel > fazenda.nivel ? `\n🎉 **LEVEL UP! Nível ${novoNivel}!**` : ''}
      `)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
