const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fofocanews')
    .setDescription('Compartilhe uma fofoca sobre alguém! ☕')
    .addUserOption(option =>
      option.setName('alvo')
        .setDescription('Sobre quem é a fofoca?')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('fofoca')
        .setDescription('Qual é a fofoca?')
        .setRequired(true)
    ),
  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');
    const fofoca = interaction.options.getString('fofoca');

    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle('☕ Fofocanews!')
      .setDescription(`**${alvo.username}** ${fofoca}`)
      .setFooter({ text: `Reportagem de ${interaction.user.username}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
