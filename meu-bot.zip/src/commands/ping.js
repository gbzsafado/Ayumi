const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Mostra a latência do bot'),
  async execute(interaction, client) {
    const sent = await interaction.reply({ content: 'Calculando...', fetchReply: true });
    const latency = sent.createdTimestamp - interaction.createdTimestamp;
    const apiLatency = Math.round(client.ws.ping);
    
    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('🏓 Pong!')
      .addFields(
        { name: 'Latência', value: `${latency}ms`, inline: true },
        { name: 'API', value: `${apiLatency}ms`, inline: true }
      )
      .setTimestamp();
    
    await interaction.editReply({ content: '', embeds: [embed] });
  },
};
