const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

async function getWaifuGif(action) {
  try {
    const response = await axios.get(`https://api.waifu.pics/sfw/${action}`);
    return response.data.url;
  } catch (error) {
    return null;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('abraço')
    .setDescription('Abrace alguém! 🤗')
    .addUserOption(option =>
      option.setName('alvo')
        .setDescription('Quem você quer abraçar?')
        .setRequired(true)
    ),
  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');
    
    if (alvo.id === interaction.user.id) {
      return interaction.reply({ content: '😢 Você se abraçou sozinho(a)...', ephemeral: true });
    }
    
    if (alvo.bot) {
      return interaction.reply({ content: '🤖 Bem, ok... o bot aprecia o carinho!', ephemeral: true });
    }

    const gif = await getWaifuGif('hug');
    if (!gif) {
      return interaction.reply({ content: '❌ Erro ao buscar GIF, tente novamente!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#00CCFF')
      .setTitle(`🤗 ${interaction.user.username} abraçou ${alvo.username}!`)
      .setImage(gif)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
