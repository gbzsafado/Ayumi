const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateMoedas, updateRPGStats, updateInventory, getInventory } = require('../database');

const DROPS = {
  essencia_monstro: { emoji: '💜', name: 'Essência de Monstro', baseChance: 60 },
  fragmento_osso: { emoji: '🦴', name: 'Fragmento de Osso', baseChance: 40 },
  presas: { emoji: '🦷', name: 'Presas', baseChance: 35 },
  fragmento_sombrio: { emoji: '🖤', name: 'Fragmento Sombrio', baseChance: 25 },
  erva_curativa: { emoji: '🌿', name: 'Erva Curativa', baseChance: 50 },
  po_magico: { emoji: '✨', name: 'Pó Mágico', baseChance: 30 }
};

const RAID_ENEMIES = [
  { name: 'Goblin Invasor', emoji: '👹', health: 60, attack: 15, defense: 5, tier: 1 },
  { name: 'Orc Guerreiro', emoji: '👺', health: 80, attack: 20, defense: 10, tier: 2 },
  { name: 'Bandido', emoji: '🥷', health: 70, attack: 18, defense: 8, tier: 1 },
  { name: 'Lobo Selvagem', emoji: '🐺', health: 55, attack: 22, defense: 5, tier: 1 },
  { name: 'Esqueleto Antigo', emoji: '💀', health: 65, attack: 17, defense: 12, tier: 2 },
  { name: 'Morcego Gigante', emoji: '🦇', health: 45, attack: 25, defense: 4, tier: 1 },
  { name: 'Troll', emoji: '👊', health: 100, attack: 22, defense: 15, tier: 3 }
];

function getRandomRaidEnemies(count = 5) {
  const enemies = [];
  for (let i = 0; i < count; i++) {
    const enemy = JSON.parse(JSON.stringify(RAID_ENEMIES[Math.floor(Math.random() * RAID_ENEMIES.length)]));
    enemies.push(enemy);
  }
  return enemies;
}

function calculateDamage(attacker, defender) {
  const attack = attacker.attack || attacker.rpg_attack || 50;
  const defense = defender.defense || defender.rpg_defense || 10;
  const baseDamage = 10 + (attack * 0.5) - (defense * 0.2);
  const variance = Math.random() * 0.3 + 0.85;
  return Math.max(5, Math.floor(baseDamage * variance));
}

function calculateDrops(tier, hasLucky = false) {
  const drops = [];
  const luckyBonus = hasLucky ? 25 : 0;
  const tierBonus = (tier - 1) * 5;
  
  for (const [dropId, drop] of Object.entries(DROPS)) {
    const chance = Math.min(95, drop.baseChance + tierBonus + luckyBonus);
    if (Math.random() * 100 < chance) {
      const quantity = Math.floor(Math.random() * tier) + 1;
      drops.push({ id: dropId, ...drop, quantity });
    }
  }
  return drops;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aldeia')
    .setDescription('Defenda sua aldeia de invasores!'),
  async prefixExecute(message, args, client) {
    return message.reply('⚔️ Use o comando `/aldeia` para participar da raid! (Requer botões interativos)');
  },
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    
    if (!user.rpg_class) {
      return interaction.reply({ content: 'Use `/registrar` primeiro para criar seu personagem!', ephemeral: true });
    }

    if (user.rpg_health < 30) {
      return interaction.reply({ content: '❌ Você precisa de pelo menos 30 HP para participar de uma raid! Use `/descansar` primeiro.', ephemeral: true });
    }

    const now = new Date();
    const lastRaid = user.last_raid ? new Date(user.last_raid) : null;
    const cooldown = 30 * 60 * 1000;

    if (lastRaid && (now - lastRaid) < cooldown) {
      const remaining = Math.ceil((cooldown - (now - lastRaid)) / 60000);
      return interaction.reply({ content: `⏰ Você precisa descansar! Próxima raid disponível em **${remaining} minutos**.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#FF4500')
      .setTitle('🏘️ Aldeia - Centro')
      .setDescription(`Bem-vindo à aldeia, **${user.character_name}**!\n\n🚨 **ALERTA DE INVASÃO!**\nInimigos estão se aproximando da aldeia!\nDefenda sua terra derrotando 5 invasores!\n\n**Recompensas:**\n🪙 50-150 Moedas por inimigo\n⭐ 20-50 XP por inimigo\n📦 Drops de materiais`)
      .setFooter({ text: 'Clique no botão para iniciar a defesa!' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('start_raid')
        .setLabel('⚔️ Defender Aldeia')
        .setStyle(ButtonStyle.Danger)
    );

    const response = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
    
    const filter = (i) => i.user.id === interaction.user.id;
    const collector = response.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (btnInteraction) => {
      if (btnInteraction.customId !== 'start_raid') return;
      
      collector.stop();
      await btnInteraction.deferUpdate();

      const enemies = getRandomRaidEnemies(5);
      let currentEnemy = 0;
      let playerHealth = user.rpg_health;
      let totalCoins = 0;
      let totalXP = 0;
      let allDrops = [];
      let victories = 0;
      let battleLog = [];

      const inventory = await getInventory(user.user_id, user.guild_id);
      const hasLucky = inventory.some(i => i.item_id === 'buff_lucky' && i.quantity > 0);
      const hasDamageBuff = inventory.some(i => i.item_id === 'buff_damage' && i.quantity > 0);
      const damageMultiplier = hasDamageBuff ? 1.25 : 1;

      const processAction = async (action = 'attack') => {
        if (currentEnemy >= enemies.length || playerHealth <= 0) {
          if (hasLucky) {
            await updateInventory(user.user_id, user.guild_id, 'buff_lucky', -1);
          }
          if (hasDamageBuff) {
            await updateInventory(user.user_id, user.guild_id, 'buff_damage', -1);
          }

          await updateMoedas(user.user_id, user.guild_id, totalCoins);
          const newExp = (user.rpg_exp || 0) + totalXP;
          const newLevel = Math.floor(newExp / 100) + 1;
          await updateRPGStats(user.user_id, user.guild_id, { 
            health: Math.max(1, playerHealth), 
            exp: newExp,
            level: newLevel
          });

          await require('../database').pool.query(
            'UPDATE users SET last_raid = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
            [user.user_id, user.guild_id]
          );

          for (const drop of allDrops) {
            await updateInventory(user.user_id, user.guild_id, drop.id, drop.quantity);
          }

          let dropsText = 'Nenhum';
          if (allDrops.length > 0) {
            const dropMap = {};
            for (const d of allDrops) {
              if (!dropMap[d.id]) dropMap[d.id] = { ...d, quantity: 0 };
              dropMap[d.id].quantity += d.quantity;
            }
            dropsText = Object.values(dropMap).map(d => `${d.emoji} ${d.name} x${d.quantity}`).join('\n');
          }

          const resultColor = victories === 5 ? '#00FF00' : victories >= 3 ? '#FFFF00' : '#FF0000';
          let resultTitle = '';
          if (victories === 5) {
            resultTitle = '🎉 PARABÉNS! Você defendeu sua aldeia!';
          } else if (victories >= 3) {
            resultTitle = '⚔️ Defesa Parcial';
          } else {
            resultTitle = '💀 Derrota';
          }

          const resultEmbed = new EmbedBuilder()
            .setColor(resultColor)
            .setTitle(`${resultTitle}`)
            .setDescription(`**Raid Finalizada!**\n\n${battleLog.slice(-5).join('\n')}`)
            .addFields(
              { name: '⚔️ Inimigos Derrotados', value: `${victories}/5`, inline: true },
              { name: '❤️ HP Restante', value: `${Math.max(0, playerHealth)}`, inline: true },
              { name: '🪙 Moedas Ganhas', value: `${totalCoins}`, inline: true },
              { name: '⭐ XP Ganho', value: `${totalXP}`, inline: true },
              { name: '📦 Drops', value: dropsText, inline: false }
            )
            .setTimestamp();

          await interaction.editReply({ embeds: [resultEmbed], components: [] });
          return;
        }

        const enemy = enemies[currentEnemy];
        
        if (action === 'attack') {
          const playerDamage = Math.floor(calculateDamage(user, enemy) * damageMultiplier);
          enemy.health -= playerDamage;
          battleLog.push(`⚔️ Você atacou ${enemy.emoji} ${enemy.name}! -${playerDamage} HP`);
        } else if (action === 'defend') {
          const reduction = Math.floor(calculateDamage(enemy, user) * 0.4);
          battleLog.push(`🛡️ Você se defendeu! Próximo dano reduzido em ${reduction} HP`);
          enemy.nextAttackReduction = reduction;
        } else if (action === 'ability') {
          const abilityDamage = Math.floor(calculateDamage(user, enemy) * 1.8);
          enemy.health -= abilityDamage;
          battleLog.push(`✨ Você usou uma habilidade especial! -${abilityDamage} HP`);
        }

        if (enemy.health <= 0) {
          const coinReward = Math.floor(Math.random() * 100) + 50;
          const xpReward = Math.floor(Math.random() * 30) + 20;
          totalCoins += coinReward;
          totalXP += xpReward;
          victories++;

          const drops = calculateDrops(enemy.tier, hasLucky);
          allDrops.push(...drops);

          battleLog.push(`✅ ${enemy.emoji} ${enemy.name} derrotado! +${coinReward} 🪙 +${xpReward} XP`);
          currentEnemy++;
        } else {
          let enemyDamage = calculateDamage(enemy, user);
          if (enemy.nextAttackReduction) {
            enemyDamage -= enemy.nextAttackReduction;
            enemy.nextAttackReduction = 0;
          }
          enemyDamage = Math.max(1, enemyDamage);
          playerHealth -= enemyDamage;
          battleLog.push(`💥 ${enemy.emoji} ${enemy.name} contra-atacou! -${enemyDamage} HP`);

          if (playerHealth <= 0) {
            battleLog.push(`💀 Você foi derrotado...`);
          }
        }

        const progressBar = '█'.repeat(victories) + '░'.repeat(5 - victories);
        
        const battleEmbed = new EmbedBuilder()
          .setColor('#FF6B6B')
          .setTitle('⚔️ RAID EM ANDAMENTO')
          .setDescription(`**Inimigo ${currentEnemy + 1}/5**\n\n${battleLog.slice(-4).join('\n')}`)
          .addFields(
            { name: `${user.character_name}`, value: `❤️ ${playerHealth}/${user.rpg_max_health}`, inline: true },
            { name: 'vs', value: '⚔️', inline: true },
            { name: `${enemy.emoji} ${enemy.name}`, value: `❤️ ${Math.max(0, enemy.health)}`, inline: true },
            { name: '📊 Progresso', value: `[${progressBar}] ${victories}/5`, inline: false }
          )
          .setTimestamp();

        if (currentEnemy < enemies.length && playerHealth > 0 && enemy.health > 0) {
          const battleRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('action_attack')
              .setLabel('⚔️ Atacar')
              .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
              .setCustomId('action_defend')
              .setLabel('🛡️ Defender')
              .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
              .setCustomId('action_ability')
              .setLabel('✨ Habilidade')
              .setStyle(ButtonStyle.Success)
          );
          await interaction.editReply({ embeds: [battleEmbed], components: [battleRow] });
        } else if (currentEnemy < enemies.length && playerHealth > 0 && enemy.health <= 0) {
          const nextRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('action_next')
              .setLabel('➡️ Próximo Inimigo')
              .setStyle(ButtonStyle.Success)
          );
          await interaction.editReply({ embeds: [battleEmbed], components: [nextRow] });
        } else {
          await interaction.editReply({ embeds: [battleEmbed], components: [] });
          await processAction('next');
        }
      };

      const raidFilter = (i) => i.user.id === interaction.user.id && (i.customId.startsWith('action_'));
      const raidCollector = response.createMessageComponentCollector({ filter: raidFilter, time: 180000 });

      let isProcessing = false;
      raidCollector.on('collect', async (raidBtn) => {
        if (isProcessing) return;
        isProcessing = true;
        await raidBtn.deferUpdate();
        
        if (raidBtn.customId === 'action_attack') {
          await processAction('attack');
        } else if (raidBtn.customId === 'action_defend') {
          await processAction('defend');
        } else if (raidBtn.customId === 'action_ability') {
          await processAction('ability');
        } else if (raidBtn.customId === 'action_next') {
          await processAction('next');
        }
        
        isProcessing = false;
      });

      raidCollector.on('end', async (collected, reason) => {
        if (reason === 'time' && currentEnemy < 5 && playerHealth > 0) {
          await updateRPGStats(user.user_id, user.guild_id, { health: playerHealth });
          const timeoutEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('⏰ Raid Abandonada')
            .setDescription('Você fugiu da batalha por inatividade.');
          await interaction.editReply({ embeds: [timeoutEmbed], components: [] }).catch(() => {});
        }
      });
    });
  }
};
