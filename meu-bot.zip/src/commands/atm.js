const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('atm')
    .setDescription('Mostra seu saldo de cristais')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('Usuário para ver o saldo')
        .setRequired(false)),
  async execute(interaction, client) {
    const user = interaction.options.getUser('usuario') || interaction.user;
    const userData = await getUser(user.id, interaction.guild.id);
    
    const embed = new EmbedBuilder()
      .setColor(0xBA55D3)
      .setTitle('💎 Caixa Eletrônico')
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '👤 Usuário', value: `<@${user.id}>`, inline: true },
        { name: '💰 Cristais', value: `\`${userData.cristais.toLocaleString('pt-BR')}\``, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Solicitado por ${interaction.user.tag}` });

    await interaction.reply({ embeds: [embed] });
  },
};
