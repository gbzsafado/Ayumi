const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFazenda, updateFazenda, getPlantacoes, regar, getFerramentas, atualizarFerramenta } = require('../fazenda/database');
const { PLANTAS, CLIMAS } = require('../fazenda/data');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('regar')
    .setDescription('Regue suas plantações')
    .addIntegerOption(option =>
      option.setName('slot')
        .setDescription('Slot para regar (1-12) ou 0 para regar todas')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(12)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const slotInput = interaction.options.getInteger('slot');

    const fazenda = await getFazenda(userId, guildId);
    const plantacoes = await getPlantacoes(userId, guildId);
    const ferramentas = await getFerramentas(userId, guildId);
    const regador = ferramentas.find(f => f.ferramenta_tipo === 'regador');

    if (plantacoes.length === 0) {
      return interaction.reply({ content: '❌ Você não tem nenhuma planta para regar!', ephemeral: true });
    }

    const clima = CLIMAS[fazenda.clima];
    let aguaBase = 1;
    
    if (regador) {
      aguaBase = regador.nivel;
      if (regador.durabilidade <= 0) {
        return interaction.reply({ content: '❌ Seu regador está quebrado! Use `/reparar regador` na oficina.', ephemeral: true });
      }
    }

    aguaBase += clima.agua > 0 ? 1 : 0;

    let plantasRegadas = [];
    let energiaGasta = 0;

    if (slotInput === 0) {
      for (const planta of plantacoes) {
        if (fazenda.energia - energiaGasta < 2) break;
        
        const plantaData = PLANTAS[planta.planta_tipo];
        if (planta.agua < plantaData.agua_necessaria) {
          await regar(userId, guildId, planta.slot, aguaBase);
          plantasRegadas.push(planta);
          energiaGasta += 2;
        }
      }
    } else {
      const slot = slotInput - 1;
      const planta = plantacoes.find(p => p.slot === slot);
      
      if (!planta) {
        return interaction.reply({ content: `❌ Não há planta no slot ${slotInput}!`, ephemeral: true });
      }

      if (fazenda.energia < 2) {
        return interaction.reply({ content: '❌ Energia insuficiente! Você precisa de ⚡ 2 energia.', ephemeral: true });
      }

      await regar(userId, guildId, slot, aguaBase);
      plantasRegadas.push(planta);
      energiaGasta = 2;
    }

    if (plantasRegadas.length === 0) {
      return interaction.reply({ content: '❌ Nenhuma planta precisava de água ou você não tem energia suficiente!', ephemeral: true });
    }

    await updateFazenda(userId, guildId, { energia: fazenda.energia - energiaGasta });

    if (regador) {
      await atualizarFerramenta(userId, guildId, 'regador', { 
        durabilidade: regador.durabilidade - plantasRegadas.length 
      });
    }

    const embed = new EmbedBuilder()
      .setColor('#3498DB')
      .setTitle('💧 Plantas Regadas!')
      .setDescription(`
Você regou **${plantasRegadas.length}** planta(s)!

${plantasRegadas.map(p => {
  const pData = PLANTAS[p.planta_tipo];
  return `${pData.emoji} ${pData.nome} (Slot ${p.slot + 1}) - +${aguaBase} 💧`;
}).join('\n')}

${clima.emoji} **Clima atual:** ${clima.nome} ${clima.agua > 0 ? '(bônus de água!)' : ''}
⚡ **Energia restante:** ${fazenda.energia - energiaGasta}
${regador ? `🚿 **Durabilidade do regador:** ${regador.durabilidade - plantasRegadas.length}/${regador.max_durabilidade}` : ''}
      `)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
