const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, updateInventory, updateRPGStats } = require('../database');

const MATERIALS = {
  madeira: { emoji: '🪵', name: 'Madeira', chance: 100, min: 1, max: 10 },
  ferro: { emoji: '⚙️', name: 'Ferro', chance: 60, min: 1, max: 3 },
  cobre: { emoji: '🟠', name: 'Cobre', chance: 45, min: 1, max: 2 },
  diamante: { emoji: '💎', name: 'Diamante', chance: 15, min: 1, max: 1 }
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minerar')
    .setDescription('Minere materiais para crafting'),
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    
    if (!user.rpg_class) {
      return interaction.reply({ content: 'Use `/registrar` primeiro!', ephemeral: true });
    }

    const now = Date.now();
    const lastMine = user.last_mine ? new Date(user.last_mine).getTime() : 0;
    const cooldownMs = 5 * 60 * 1000;
    
    if (now - lastMine < cooldownMs) {
      const timeLeft = Math.ceil((cooldownMs - (now - lastMine)) / 1000);
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      return interaction.reply({ content: `⏳ Você está cansado! Volte em **${minutes}m ${seconds}s**`, ephemeral: true });
    }

    const mined = {};
    let description = '⛏️ **Materiais Coletados:**\n';

    for (const [key, material] of Object.entries(MATERIALS)) {
      if (Math.random() * 100 < material.chance) {
        const amount = Math.floor(Math.random() * (material.max - material.min + 1)) + material.min;
        mined[key] = amount;
        await updateInventory(interaction.user.id, interaction.guildId, key, amount);
        description += `${material.emoji} ${material.name}: **+${amount}**\n`;
      }
    }

    if (Object.keys(mined).length === 0) {
      return interaction.reply({ content: '❌ Você não achou nada desta vez!', ephemeral: true });
    }

    await updateRPGStats(user.user_id, user.guild_id, { last_mine: new Date() });

    const embed = new EmbedBuilder()
      .setColor('#8B4513')
      .setTitle('⛏️ Mineração Concluída!')
      .setDescription(description)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
