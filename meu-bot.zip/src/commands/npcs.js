const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { getUser, updateMoedas, updateRPGStats, updateInventory, getInventory } = require('../database');

const SAGE_MISSIONS = [
  { id: 'missao_1', name: 'Caçador Iniciante', description: 'Derrote 3 inimigos em batalha', reward_coins: 100, reward_xp: 50, emoji: '⚔️' },
  { id: 'missao_2', name: 'Protetor da Floresta', description: 'Complete 2 raids na aldeia', reward_coins: 200, reward_xp: 100, emoji: '🛡️' },
  { id: 'missao_3', name: 'Colecionador de Recursos', description: 'Colete 10 materiais minerando', reward_coins: 150, reward_xp: 75, emoji: '⛏️' },
  { id: 'missao_4', name: 'Mestre Artesão', description: 'Crie 3 itens no crafting', reward_coins: 180, reward_xp: 80, emoji: '🔨' },
  { id: 'missao_5', name: 'Explorador de Terras', description: 'Viaje para 2 mapas diferentes', reward_coins: 250, reward_xp: 120, emoji: '🗺️' }
];

const WEAPONS = [
  { id: 'espada_ferro', name: 'Espada de Ferro', bonus: 5, price: 200, emoji: '🗡️', description: '+5 de Ataque' },
  { id: 'espada_aco', name: 'Espada de Aço', bonus: 12, price: 500, emoji: '⚔️', description: '+12 de Ataque' },
  { id: 'machado_guerra', name: 'Machado de Guerra', bonus: 18, price: 800, emoji: '🪓', description: '+18 de Ataque' },
  { id: 'espada_real', name: 'Espada Real', bonus: 25, price: 1500, emoji: '👑', description: '+25 de Ataque' },
  { id: 'lamina_sombria', name: 'Lâmina Sombria', bonus: 35, price: 3000, emoji: '🖤', description: '+35 de Ataque' }
];

const AYUMI_GIFTS = [
  { id: 'essencia_monstro', emoji: '💜', name: 'Essência de Monstro', quantity: [1, 5], rarity: 'comum' },
  { id: 'fragmento_osso', emoji: '🦴', name: 'Fragmento de Osso', quantity: [1, 3], rarity: 'comum' },
  { id: 'presas', emoji: '🦷', name: 'Presas', quantity: [1, 3], rarity: 'comum' },
  { id: 'erva_curativa', emoji: '🌿', name: 'Erva Curativa', quantity: [2, 6], rarity: 'comum' },
  { id: 'po_magico', emoji: '✨', name: 'Pó Mágico', quantity: [1, 4], rarity: 'incomum' },
  { id: 'fragmento_sombrio', emoji: '🖤', name: 'Fragmento Sombrio', quantity: [1, 2], rarity: 'incomum' },
  { id: 'escama_dragao', emoji: '🐲', name: 'Escama de Dragão', quantity: [1, 2], rarity: 'raro' },
  { id: 'coracao_monstro', emoji: '❤️‍🔥', name: 'Coração de Monstro', quantity: [1, 1], rarity: 'raro' },
  { id: 'ferro', emoji: '🔩', name: 'Ferro', quantity: [5, 15], rarity: 'comum' },
  { id: 'ouro', emoji: '🪙', name: 'Ouro', quantity: [2, 8], rarity: 'incomum' },
  { id: 'diamante', emoji: '💎', name: 'Diamante', quantity: [1, 3], rarity: 'raro' },
  { id: 'pocao_cura', emoji: '❤️', name: 'Poção de Cura', quantity: [1, 2], rarity: 'incomum' },
  { id: 'buff_damage', emoji: '⚔️', name: 'Poção de Dano', quantity: [1, 1], rarity: 'raro' },
  { id: 'buff_lucky', emoji: '🍀', name: 'Poção da Sorte', quantity: [1, 1], rarity: 'lendário' }
];

function getRandomGift() {
  const roll = Math.random() * 100;
  let gifts;
  
  if (roll < 3) {
    gifts = AYUMI_GIFTS.filter(g => g.rarity === 'lendário');
  } else if (roll < 15) {
    gifts = AYUMI_GIFTS.filter(g => g.rarity === 'raro');
  } else if (roll < 40) {
    gifts = AYUMI_GIFTS.filter(g => g.rarity === 'incomum');
  } else {
    gifts = AYUMI_GIFTS.filter(g => g.rarity === 'comum');
  }
  
  const gift = gifts[Math.floor(Math.random() * gifts.length)];
  const quantity = Math.floor(Math.random() * (gift.quantity[1] - gift.quantity[0] + 1)) + gift.quantity[0];
  
  return { ...gift, quantity };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('npcs')
    .setDescription('Interaja com os NPCs da aldeia'),
  async prefixExecute(message, args, client) {
    return message.reply('🏘️ Use o comando `/npcs` para interagir com os NPCs! (Requer botões interativos)');
  },
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    
    if (!user.rpg_class) {
      return interaction.reply({ content: 'Use `/registrar` primeiro para criar seu personagem!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#8B4513')
      .setTitle('🏘️ NPCs da Aldeia')
      .setDescription(`Olá, **${user.character_name}**!\n\nEscolha um NPC para interagir:`)
      .addFields(
        { name: '🧙 Velho Sábio', value: 'Te dá missões especiais com recompensas', inline: true },
        { name: '🔨 Ferreiro Seu Zé', value: 'Vende armas que melhoram seu ataque', inline: true },
        { name: '🌸 Ayumi', value: 'Te dá presentes aleatórios (12h cooldown)', inline: true }
      )
      .setFooter({ text: 'Clique no botão do NPC desejado!' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('npc_sage')
        .setLabel('🧙 Velho Sábio')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('npc_blacksmith')
        .setLabel('🔨 Seu Zé')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('npc_ayumi')
        .setLabel('🌸 Ayumi')
        .setStyle(ButtonStyle.Secondary)
    );

    const response = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });
    
    const filter = (i) => i.user.id === interaction.user.id;
    const collector = response.createMessageComponentCollector({ filter, time: 120000 });

    collector.on('collect', async (btnInteraction) => {
      if (btnInteraction.customId === 'npc_blacksmith') {
        const currentWeapon = user.equipped_weapon || 'Nenhuma';
        const currentBonus = user.weapon_bonus || 0;

        const blacksmithEmbed = new EmbedBuilder()
          .setColor('#CD853F')
          .setTitle('🔨 Ferreiro Seu Zé')
          .setDescription(`*"Ora ora, se não é ${user.character_name}! Bem-vindo à minha forja, amigo!"*\n\n*"Tenho as melhores armas da região! Feitas com amor e dedicação, hehe!"*\n\n💰 **Suas Moedas:** ${user.moedas || 0}\n⚔️ **Arma Equipada:** ${currentWeapon} (+${currentBonus} ATK)\n\n**Armas à Venda:**`);

        let weaponsText = '';
        WEAPONS.forEach(w => {
          weaponsText += `\n${w.emoji} **${w.name}** - 🪙 ${w.price}\n   ${w.description}\n`;
        });
        blacksmithEmbed.addFields({ name: '🗡️ Catálogo', value: weaponsText || 'Nenhuma arma disponível' });

        const weaponSelect = new StringSelectMenuBuilder()
          .setCustomId('blacksmith_buy')
          .setPlaceholder('Escolha uma arma para comprar...')
          .addOptions(WEAPONS.map(w => ({
            label: `${w.name} - ${w.price} moedas`,
            description: w.description,
            value: w.id,
            emoji: w.emoji
          })));

        const weaponRow = new ActionRowBuilder().addComponents(weaponSelect);
        const backRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('back_to_npcs')
            .setLabel('⬅️ Voltar')
            .setStyle(ButtonStyle.Secondary)
        );

        await btnInteraction.update({ embeds: [blacksmithEmbed], components: [weaponRow, backRow] });
      }
      else if (btnInteraction.customId === 'npc_ayumi') {
        const now = new Date();
        const lastGift = user.last_ayumi_gift ? new Date(user.last_ayumi_gift) : null;
        const cooldown = 12 * 60 * 60 * 1000;

        if (lastGift && (now - lastGift) < cooldown) {
          const remaining = Math.ceil((cooldown - (now - lastGift)) / 3600000);
          const ayumiWaitEmbed = new EmbedBuilder()
            .setColor('#FFB6C1')
            .setTitle('🌸 Ayumi')
            .setDescription(`*"Oi oi, ${user.character_name}! Você já pegou seu presente hoje!"*\n\n*"Volta daqui a **${remaining} horas**, tá? Vou preparar algo especial pra você!"* 💕`)
            .setFooter({ text: 'Ayumi te dá presentes a cada 12 horas!' });

          const backRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('back_to_npcs')
              .setLabel('⬅️ Voltar')
              .setStyle(ButtonStyle.Secondary)
          );

          await btnInteraction.update({ embeds: [ayumiWaitEmbed], components: [backRow] });
        } else {
          const gift = getRandomGift();
          
          await updateInventory(user.user_id, user.guild_id, gift.id, gift.quantity);
          await require('../database').pool.query(
            'UPDATE users SET last_ayumi_gift = CURRENT_TIMESTAMP WHERE user_id = $1 AND guild_id = $2',
            [user.user_id, user.guild_id]
          );

          const rarityColors = {
            'comum': '#A0A0A0',
            'incomum': '#00FF00',
            'raro': '#0080FF',
            'lendário': '#FFD700'
          };

          const rarityText = {
            'comum': '⚪ Comum',
            'incomum': '🟢 Incomum',
            'raro': '🔵 Raro',
            'lendário': '🟡 Lendário'
          };

          const ayumiGiftEmbed = new EmbedBuilder()
            .setColor(rarityColors[gift.rarity])
            .setTitle('🌸 Ayumi')
            .setDescription(`*"${user.character_name}! Olha o que eu encontrei pra você!"*\n\n🎁 **PRESENTE RECEBIDO!**`)
            .addFields(
              { name: 'Item', value: `${gift.emoji} ${gift.name}`, inline: true },
              { name: 'Quantidade', value: `x${gift.quantity}`, inline: true },
              { name: 'Raridade', value: rarityText[gift.rarity], inline: true }
            )
            .setFooter({ text: 'Volte em 12 horas para mais presentes!' })
            .setTimestamp();

          const backRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('back_to_npcs')
              .setLabel('⬅️ Voltar')
              .setStyle(ButtonStyle.Secondary)
          );

          await btnInteraction.update({ embeds: [ayumiGiftEmbed], components: [backRow] });
        }
      }
      else if (btnInteraction.customId === 'back_to_npcs') {
        const embed = new EmbedBuilder()
          .setColor('#8B4513')
          .setTitle('🏘️ NPCs da Aldeia')
          .setDescription(`Olá, **${user.character_name}**!\n\nEscolha um NPC para interagir:`)
          .addFields(
            { name: '🧙 Velho Sábio', value: 'Te dá missões especiais com recompensas', inline: true },
            { name: '🔨 Ferreiro Seu Zé', value: 'Vende armas que melhoram seu ataque', inline: true },
            { name: '🌸 Ayumi', value: 'Te dá presentes aleatórios (12h cooldown)', inline: true }
          )
          .setFooter({ text: 'Clique no botão do NPC desejado!' })
          .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('npc_sage')
            .setLabel('🧙 Velho Sábio')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('npc_blacksmith')
            .setLabel('🔨 Seu Zé')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('npc_ayumi')
            .setLabel('🌸 Ayumi')
            .setStyle(ButtonStyle.Secondary)
        );

        await btnInteraction.update({ embeds: [embed], components: [row] });
      }
      else if (btnInteraction.customId === 'sage_mission_select') {
        const missionId = btnInteraction.values[0];
        const mission = SAGE_MISSIONS.find(m => m.id === missionId);

        if (mission) {
          // Salvar missão ativa
          await updateRPGStats(user.user_id, user.guild_id, { active_mission: missionId });

          const acceptEmbed = new EmbedBuilder()
            .setColor('#9932CC')
            .setTitle('📜 Missão Aceita!')
            .setDescription(`*"Excelente escolha, jovem!"*\n\n${mission.emoji} **${mission.name}**\n\n📝 **Objetivo:** ${mission.description}\n\n**Recompensas:**\n🪙 ${mission.reward_coins} Moedas\n⭐ ${mission.reward_xp} XP\n\n*"Complete o objetivo e volte para receber sua recompensa!"*`)
            .setFooter({ text: 'Boa sorte, aventureiro!' })
            .setTimestamp();

          const backRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('back_to_npcs')
              .setLabel('⬅️ Voltar')
              .setStyle(ButtonStyle.Secondary)
          );

          await btnInteraction.update({ embeds: [acceptEmbed], components: [backRow] });
        }
      }
      else if (btnInteraction.customId === 'npc_sage') {
        try {
          await btnInteraction.deferUpdate();
        } catch (err) {
          console.error('Erro ao defer:', err);
        }

        const currentUser = await getUser(interaction.user.id, interaction.guildId);
        const activeMission = currentUser.active_mission;

        // Se tem missão ativa, mostrar opção de reportar conclusão
        if (activeMission) {
          const mission = SAGE_MISSIONS.find(m => m.id === activeMission);
          if (mission) {
            const completionEmbed = new EmbedBuilder()
              .setColor('#9932CC')
              .setTitle('🧙 Velho Sábio')
              .setDescription(`*"Voltou, jovem? Como correu?"*\n\n${mission.emoji} **${mission.name}**\n📝 ${mission.description}\n\n**Recompensas Pendentes:**\n🪙 ${mission.reward_coins} Moedas\n⭐ ${mission.reward_xp} XP`)
              .setFooter({ text: 'Você completou a missão?' });

            const completeBtn = new ButtonBuilder()
              .setCustomId('mission_complete')
              .setLabel('✅ Reportar Conclusão')
              .setStyle(ButtonStyle.Success);

            const cancelBtn = new ButtonBuilder()
              .setCustomId('back_to_npcs')
              .setLabel('⬅️ Voltar')
              .setStyle(ButtonStyle.Secondary);

            const row = new ActionRowBuilder().addComponents(completeBtn, cancelBtn);
            await interaction.editReply({ embeds: [completionEmbed], components: [row] });
            return;
          }
        }

        // Mostrar missões normalmente
        const sageEmbed = new EmbedBuilder()
          .setColor('#9932CC')
          .setTitle('🧙 Velho Sábio')
          .setDescription(`*"Ah, jovem aventureiro... Você busca sabedoria e desafios?"*\n\n**Missões Disponíveis:**`)
          .setFooter({ text: 'Escolha uma missão no menu abaixo!' });

        let missionsText = '';
        SAGE_MISSIONS.forEach((m, i) => {
          missionsText += `\n${m.emoji} **${m.name}**\n   📝 ${m.description}\n   🪙 ${m.reward_coins} moedas | ⭐ ${m.reward_xp} XP\n`;
        });
        sageEmbed.setDescription(`*"Ah, jovem aventureiro... Você busca sabedoria e desafios?"*\n\n**Missões Disponíveis:**${missionsText}`);

        const missionSelect = new StringSelectMenuBuilder()
          .setCustomId('sage_mission_select')
          .setPlaceholder('Escolha uma missão...')
          .addOptions(SAGE_MISSIONS.map(m => ({
            label: m.name,
            description: `${m.reward_coins} moedas, ${m.reward_xp} XP`,
            value: m.id,
            emoji: m.emoji
          })));

        const missionRow = new ActionRowBuilder().addComponents(missionSelect);
        const backRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('back_to_npcs')
            .setLabel('⬅️ Voltar')
            .setStyle(ButtonStyle.Secondary)
        );

        await interaction.editReply({ embeds: [sageEmbed], components: [missionRow, backRow] });
      }
      else if (btnInteraction.customId === 'mission_complete') {
        try {
          await btnInteraction.deferUpdate();
        } catch (err) {
          console.error('Erro ao defer:', err);
        }

        const currentUser = await getUser(interaction.user.id, interaction.guildId);
        const activeMission = currentUser.active_mission;

        if (activeMission) {
          const mission = SAGE_MISSIONS.find(m => m.id === activeMission);
          
          if (mission) {
            // Dar recompensa
            await updateMoedas(currentUser.user_id, currentUser.guild_id, mission.reward_coins);
            await updateRPGStats(currentUser.user_id, currentUser.guild_id, { 
              exp: Number(currentUser.rpg_exp || 0) + mission.reward_xp,
              active_mission: null 
            });

            const rewardEmbed = new EmbedBuilder()
              .setColor('#00FF00')
              .setTitle('✅ Missão Completa!')
              .setDescription(`*"Excelente trabalho, jovem! Você se superou!"*\n\n${mission.emoji} **${mission.name}** ✓\n\n**Recompensas Recebidas:**\n🪙 +${mission.reward_coins} Moedas\n⭐ +${mission.reward_xp} XP`)
              .setFooter({ text: 'Volte para mais desafios!' })
              .setTimestamp();

            const backRow = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId('back_to_npcs')
                .setLabel('⬅️ Voltar')
                .setStyle(ButtonStyle.Secondary)
            );

            await interaction.editReply({ embeds: [rewardEmbed], components: [backRow] });
          }
        }
      }
      else if (btnInteraction.customId === 'blacksmith_buy') {
        const weaponId = btnInteraction.values[0];
        const weapon = WEAPONS.find(w => w.id === weaponId);
        const currentUser = await getUser(interaction.user.id, interaction.guildId);

        if (!weapon) return;

        if ((currentUser.moedas || 0) < weapon.price) {
          const noMoneyEmbed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🔨 Ferreiro Seu Zé')
            .setDescription(`*"Ah, amigo... Você não tem moedas suficientes!"*\n\n💰 Você tem: ${currentUser.moedas || 0} moedas\n💰 Preço: ${weapon.price} moedas\n\n*"Volte quando tiver mais, tá? Vou guardar essa belezura pra você!"*`)
            .setFooter({ text: 'Ganhe moedas derrotando inimigos e completando raids!' });

          const backRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId('back_to_npcs')
              .setLabel('⬅️ Voltar')
              .setStyle(ButtonStyle.Secondary)
          );

          await btnInteraction.update({ embeds: [noMoneyEmbed], components: [backRow] });
          return;
        }

        await updateMoedas(user.user_id, user.guild_id, -weapon.price);
        await require('../database').pool.query(
          'UPDATE users SET equipped_weapon = $1, weapon_bonus = $2 WHERE user_id = $3 AND guild_id = $4',
          [weapon.name, weapon.bonus, user.user_id, user.guild_id]
        );

        const boughtEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('🔨 Ferreiro Seu Zé')
          .setDescription(`*"MARAVILHA! Essa arma ficou perfeita pra você!"*\n\n${weapon.emoji} **${weapon.name}** equipada!\n\n**Bônus:** +${weapon.bonus} de Ataque\n**Preço:** ${weapon.price} moedas\n\n*"Cuide bem dela, hein! Fiz com muito carinho!"* 😊`)
          .setFooter({ text: 'Arma equipada com sucesso!' })
          .setTimestamp();

        const backRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('back_to_npcs')
            .setLabel('⬅️ Voltar')
            .setStyle(ButtonStyle.Secondary)
        );

        await btnInteraction.update({ embeds: [boughtEmbed], components: [backRow] });
      }
    });
  }
};
