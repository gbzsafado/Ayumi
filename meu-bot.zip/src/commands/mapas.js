const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser } = require('../database');

const MAPS = {
  floresta_sombria: {
    name: 'Floresta Sombria',
    emoji: '🌲',
    description: 'Uma floresta densa e misteriosa, lar de criaturas selvagens. Perfeita para iniciantes.',
    minLevel: 1,
    maxLevel: 5,
    color: '#228B22',
    enemies: [
      { name: 'Lobo', emoji: '🐺', chance: 30 },
      { name: 'Aranha Gigante', emoji: '🕷️', chance: 25 },
      { name: 'Urso', emoji: '🐻', chance: 30 },
      { name: 'Curupira', emoji: '🧝', chance: 15, rare: true }
    ],
    drops: ['erva_curativa', 'presas', 'essencia_monstro']
  },
  deserto_infernal: {
    name: 'Deserto Infernal',
    emoji: '🏜️',
    description: 'Um deserto escaldante cheio de perigos mortais. Apenas aventureiros experientes devem se aventurar.',
    minLevel: 5,
    maxLevel: 12,
    color: '#FFD700',
    enemies: [
      { name: 'Escorpião da Cauda Rosa', emoji: '🦂', chance: 25 },
      { name: 'Escorpião Infernal', emoji: '🔥', chance: 20 },
      { name: 'Bandido do Deserto', emoji: '🥷', chance: 25 },
      { name: 'Serpente de Areia', emoji: '🐍', chance: 15 },
      { name: 'Múmia', emoji: '🧟', chance: 15, rare: true }
    ],
    drops: ['fragmento_osso', 'po_magico', 'fragmento_sombrio', 'coracao_monstro']
  }
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mapas')
    .setDescription('Veja todos os mapas disponíveis para explorar'),
  async prefixExecute(message, args, client) {
    return message.reply('🗺️ Use o comando `/mapas` para ver todos os mapas! (Requer botões interativos)');
  },
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    const playerLevel = Math.floor((user.rpg_exp || 0) / 100) + 1;
    const currentMap = user.current_map || 'floresta_sombria';

    const embed = new EmbedBuilder()
      .setColor('#4169E1')
      .setTitle('🗺️ Mapas do Mundo')
      .setDescription(`**${user.character_name || 'Aventureiro'}** (Nível ${playerLevel})\n📍 **Localização Atual:** ${MAPS[currentMap]?.emoji || '🏘️'} ${MAPS[currentMap]?.name || 'Aldeia'}\n\n*Use \`/viajar\` para ir a outro mapa!*`)
      .setFooter({ text: 'Explore novos territórios e enfrente desafios maiores!' })
      .setTimestamp();

    for (const [mapId, map] of Object.entries(MAPS)) {
      const isCurrentMap = mapId === currentMap;
      const canAccess = playerLevel >= map.minLevel;
      const statusEmoji = isCurrentMap ? '📍' : canAccess ? '✅' : '🔒';
      
      let enemyList = map.enemies.map(e => {
        const rareTag = e.rare ? ' ⭐' : '';
        return `${e.emoji} ${e.name} (${e.chance}%)${rareTag}`;
      }).join('\n');

      let fieldValue = `${map.description}\n\n`;
      fieldValue += `**Nível Recomendado:** ${map.minLevel}-${map.maxLevel}\n`;
      fieldValue += `**Status:** ${isCurrentMap ? 'Você está aqui!' : canAccess ? 'Acessível' : `Requer nível ${map.minLevel}`}\n\n`;
      fieldValue += `**Inimigos:**\n${enemyList}`;

      embed.addFields({
        name: `${statusEmoji} ${map.emoji} ${map.name}`,
        value: fieldValue,
        inline: false
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('map_floresta')
        .setLabel('🌲 Ir para Floresta')
        .setStyle(currentMap === 'floresta_sombria' ? ButtonStyle.Secondary : ButtonStyle.Primary)
        .setDisabled(currentMap === 'floresta_sombria'),
      new ButtonBuilder()
        .setCustomId('map_deserto')
        .setLabel('🏜️ Ir para Deserto')
        .setStyle(currentMap === 'deserto_infernal' ? ButtonStyle.Secondary : ButtonStyle.Primary)
        .setDisabled(currentMap === 'deserto_infernal' || playerLevel < 5)
    );

    const response = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = (i) => i.user.id === interaction.user.id;
    const collector = response.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async (btnInteraction) => {
      let targetMap = null;
      
      if (btnInteraction.customId === 'map_floresta') {
        targetMap = 'floresta_sombria';
      } else if (btnInteraction.customId === 'map_deserto') {
        if (playerLevel < 5) {
          await btnInteraction.reply({ content: '🔒 Você precisa ser nível 5 para acessar o Deserto Infernal!', ephemeral: true });
          return;
        }
        targetMap = 'deserto_infernal';
      }

      if (targetMap) {
        await require('../database').pool.query(
          'UPDATE users SET current_map = $1 WHERE user_id = $2 AND guild_id = $3',
          [targetMap, user.user_id, user.guild_id]
        );

        const map = MAPS[targetMap];
        const travelEmbed = new EmbedBuilder()
          .setColor(map.color)
          .setTitle(`${map.emoji} Viagem Concluída!`)
          .setDescription(`**${user.character_name}** viajou para **${map.name}**!\n\n${map.description}\n\n*Use \`/lutar\` para enfrentar os inimigos deste mapa!*`)
          .setFooter({ text: `Nível recomendado: ${map.minLevel}-${map.maxLevel}` })
          .setTimestamp();

        await btnInteraction.update({ embeds: [travelEmbed], components: [] });
        collector.stop();
      }
    });
  }
};
