const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getUser, registerCharacter } = require('../database');

const CLASSES = {
  guerreiro: {
    name: '⚔️ Guerreiro',
    emoji: '⚔️',
    description: 'Dano médio, Resistência alta, Mobilidade baixa, Vida média',
    attack: 65,
    defense: 80,
    mobility: 35,
    health: 110,
    color: '#CD7F32'
  },
  mago: {
    name: '🔮 Mago',
    emoji: '🔮',
    description: 'Dano alto, Resistência baixa, Mobilidade média, Vida baixa',
    attack: 90,
    defense: 25,
    mobility: 50,
    health: 70,
    color: '#4169E1'
  },
  assassino: {
    name: '🗡️ Assassino',
    emoji: '🗡️',
    description: 'Dano alto, Resistência baixa, Mobilidade alta, Vida baixa',
    attack: 85,
    defense: 30,
    mobility: 85,
    health: 75,
    color: '#2F4F4F'
  },
  tanque: {
    name: '🛡️ Tanque',
    emoji: '🛡️',
    description: 'Dano baixo, Resistência muito alta, Mobilidade baixa, Vida muito alta',
    attack: 35,
    defense: 95,
    mobility: 20,
    health: 160,
    color: '#FFD700'
  },
  arqueiro: {
    name: '🏹 Arqueiro',
    emoji: '🏹',
    description: 'Dano alto, Resistência média, Mobilidade alta, Vida média',
    attack: 80,
    defense: 55,
    mobility: 75,
    health: 110,
    color: '#FF8C00'
  }
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('registrar')
    .setDescription('Registre seu personagem RPG e escolha uma classe'),
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);

    if (user.rpg_class) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('❌ Erro')
            .setDescription(`Você já tem um personagem: **${user.character_name}** (${user.rpg_class})`)
        ],
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor('#9370DB')
      .setTitle('🎮 Bem-vindo ao RPG!')
      .setDescription('Escolha sua classe e comece sua jornada.\n\nCada classe tem atributos únicos que afetam seu gameplay.')
      .addFields(
        { name: '⚔️ Guerreiro', value: 'Dano médio, Resistência alta, Mobilidade baixa', inline: false },
        { name: '🔮 Mago', value: 'Dano alto, Resistência baixa, Mobilidade média', inline: false },
        { name: '🗡️ Assassino', value: 'Dano alto, Resistência baixa, Mobilidade alta', inline: false },
        { name: '🛡️ Tanque', value: 'Dano baixo, Resistência muito alta, Mobilidade baixa', inline: false },
        { name: '🏹 Arqueiro', value: 'Dano alto, Resistência média, Mobilidade alta', inline: false }
      )
      .setFooter({ text: 'Escolha sua classe abaixo' });

    const select = new StringSelectMenuBuilder()
      .setCustomId('class_select')
      .setPlaceholder('Selecione sua classe...')
      .addOptions(
        Object.entries(CLASSES).map(([key, classData]) => ({
          label: classData.name,
          description: classData.description,
          value: key,
          emoji: classData.emoji
        }))
      );

    const row = new ActionRowBuilder().addComponents(select);
    const response = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const filter = (i) => i.user.id === interaction.user.id && i.customId === 'class_select';
    const collector = response.createMessageComponentCollector({ filter, time: 60000, max: 1 });

    collector.on('collect', async (selectInteraction) => {
      const selectedClass = selectInteraction.values[0];
      const classData = CLASSES[selectedClass];
      const characterName = interaction.user.username;

      await registerCharacter(interaction.user.id, interaction.guildId, characterName, selectedClass);

      const successEmbed = new EmbedBuilder()
        .setColor(classData.color)
        .setTitle('✅ Personagem Criado!')
        .setDescription(`Bem-vindo, **${characterName}**!`)
        .addFields(
          { name: '🎭 Classe', value: classData.name, inline: true },
          { name: '❤️ Saúde', value: `${classData.health} HP`, inline: true },
          { name: '⚔️ Ataque', value: `${classData.attack}`, inline: true },
          { name: '🛡️ Defesa', value: `${classData.defense}`, inline: true },
          { name: '💨 Velocidade', value: `${classData.mobility}`, inline: true },
          { name: '📊 Nível', value: '1', inline: true }
        )
        .setFooter({ text: 'Use /perfil para ver seus stats' })
        .setTimestamp();

      await selectInteraction.update({ embeds: [successEmbed], components: [] });
    });

    collector.on('end', (collected) => {
      if (collected.size === 0) {
        interaction.editReply({ components: [] }).catch(() => {});
      }
    });
  }
};
