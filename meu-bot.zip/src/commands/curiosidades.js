const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const FACTS = [
  '🐢 As tartarugas podem reter a respiração por até 7 horas!',
  '🍯 O mel nunca estraga. Arqueólogos encontraram mel de 3000 anos atrás ainda comível!',
  '🧠 Seu cérebro usa 20% da energia do seu corpo, mas é apenas 2% da massa!',
  '👅 Você não consegue dar um tapa na boca enquanto está gritando. Tente! 😄',
  '🦑 O polvo tem 3 corações!',
  '⚡ Um raio é 5 vezes mais quente que a superfície do sol!',
  '🐝 As abelhas dançam para se comunicar onde está o alimento!',
  '👁️ Seus olhos se movem 100.000 vezes por dia!',
  '💔 Quebrar ossos dói, mas eles se reparam sozinhos (nunca 100% igual)!',
  '🌍 Uma pessoa típica caminha cerca de 216 quilômetros por ano!',
  '🐶 Os cães ouvem frequências até 65.000 Hz, humanos até 20.000 Hz!',
  '❄️ Os flocos de neve sempre têm 6 lados!',
  '🌙 A lua está se afastando da Terra 3,8 cm por ano!',
  '🐙 Os tentáculos do polvo têm uma mente própria!',
  '🎨 Picasso foi nomeado oficial de polícia!',
  '☕ A cafeína leva 10 minutos para entrar na corrente sanguínea!',
  '🦣 Os mamutes ainda existem em fósseis, alguns com 40.000 anos!',
  '🏃 Correr faz bem e é gratuito, mas ainda assim ninguém quer correr!',
  '🧬 99,9% de seu DNA é igual ao de um chimpanzé!',
  '🌺 As flores têm cores diferentes para atrair diferentes tipos de insetos!',
  '🎯 Você jamais pode usar todo o seu cérebro... todo dia você usa 100%!',
  '📱 O primeiro celular foi chamado de "Brick" e pesava 1 kg!',
  '🐢 As tartarugas podem viver até 200 anos!',
  '🌈 Um arco-íris é na verdade um círculo completo, mas só vemos meia lua!',
  '💎 Os diamantes podem não ser para sempre, mas duram bilhões de anos!',
  '🦕 Os dinossauros foram extintos há 66 milhões de anos!',
  '🌊 O oceano contém 97% de toda a água do planeta!',
  '🍌 As bananas são radioativas e levam 30 dias para desaparecer a radioatividade!',
  '🦅 As águias podem ver um coelho a 3 km de distância!',
  '🐘 Os elefantes nunca esquecem, mesmo depois de 40 anos!',
  '🌲 Uma árvore pode absorver até 48 libras de CO2 por ano!',
  '❤️ Seu coração bate cerca de 100.000 vezes por dia!',
  '🧴 Sua pele se regenera a cada 28 dias!',
  '👃 Seu olfato é 10.000 vezes mais sensível que seu paladar!',
  '💪 Os músculos dos olhos são os mais rápidos do corpo!',
  '🎪 Palhaços profissionais preferem trabalhar descalços para melhor equilíbrio!',
  '🏖️ O vidro é feito de areia fundida!',
  '⏰ Um ano em Vênus tem 243 dias terrestres!',
  '🧊 A Antártida contém 80% de toda a água doce do planeta!',
  '🐙 O polvo é o animal mais inteligente do oceano!',
  '🦀 Os caranguejos têm olhos nas pontas de seus olhinhos!',
  '🐠 Os peixes bebem água através de suas guelras!',
  '🌻 Os girassóis seguem o movimento do sol durante o dia!',
  '🦗 Os grilos ouvem com as pernas!',
  '🦋 As borboletas não conseguem voar se tiverem frio!',
  '🐌 Os caracóis podem dormir por até 3 anos!',
  '🦘 Os cangurus podem pular até 9 metros!',
  '🐧 Os pinguins podem nadar a 36 km/h!',
  '🦁 Um leão dorme até 20 horas por dia!',
  '🐪 Os camelos podem beber 40 litros de água em 10 minutos!',
  '🦒 A língua da girafa tem 45 cm de comprimento!',
];

async function getFact() {
  return FACTS[Math.floor(Math.random() * FACTS.length)];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('curiosidades')
    .setDescription('Aprenda uma curiosidade interessante! 🔍'),
  async execute(interaction) {
    const fact = await getFact();

    const embed = new EmbedBuilder()
      .setColor('#FF1493')
      .setTitle('🔍 Curiosidade do Dia!')
      .setDescription(fact)
      .setFooter({ text: 'Conhecimento é poder! 💡' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
