const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateCristais } = require('../database');

const suits = ['♠️', '♥️', '♣️', '♦️'];
const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

function getCardValue(rank) {
  if (rank === 'A') return 11;
  if (['J', 'Q', 'K'].includes(rank)) return 10;
  return parseInt(rank);
}

function getCardString(card) {
  return `${card.rank}${card.suit}`;
}

function calculateHand(cards) {
  let total = 0;
  let aces = 0;
  
  for (const card of cards) {
    const value = getCardValue(card.rank);
    if (card.rank === 'A') aces++;
    total += value;
  }
  
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  
  return total;
}

function createDeck() {
  const deck = [];
  for (const suit of suits) {
    for (const rank of ranks) {
      deck.push({ suit, rank });
    }
  }
  return deck.sort(() => Math.random() - 0.5);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Jogo de 21 valendo cristais')
    .addIntegerOption(option =>
      option.setName('aposta')
        .setDescription('Valor da aposta')
        .setRequired(true)
        .setMinValue(1)),
  async execute(interaction, client) {
    const amount = interaction.options.getInteger('aposta');
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const userData = await getUser(userId, guildId);
    const userCristais = Number(userData.cristais);
    
    if (userCristais < amount) {
      const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('❌ Saldo Insuficiente!')
        .setDescription(`Você não tem cristais suficientes para essa aposta.`)
        .addFields(
          { name: '💰 Seu Saldo', value: `\`${userCristais.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💸 Valor Apostado', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    const deck = createDeck();
    const playerHand = [deck.pop(), deck.pop()];
    const dealerHand = [deck.pop(), deck.pop()];
    
    let gameOver = false;
    
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('hit')
          .setLabel('Bater (Hit)')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('stand')
          .setLabel('Parar (Stand)')
          .setStyle(ButtonStyle.Success)
      );
    
    const updateGameDisplay = (showDealerCard = false) => {
      const playerValue = calculateHand(playerHand);
      const dealerValue = calculateHand(dealerHand);
      
      const playerCards = playerHand.map(getCardString).join(' ');
      const dealerCards = showDealerCard 
        ? dealerHand.map(getCardString).join(' ')
        : `${getCardString(dealerHand[0])} 🔒`;
      
      return new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('♠️ BLACKJACK ♠️')
        .addFields(
          { name: '🤖 Dealer', value: `${dealerCards}\nTotal: ${showDealerCard ? dealerValue : '?'}`, inline: false },
          { name: '👤 Você', value: `${playerCards}\nTotal: ${playerValue}`, inline: false },
          { name: '💎 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` cristais`, inline: true }
        )
        .setTimestamp();
    };
    
    const response = await interaction.reply({ 
      embeds: [updateGameDisplay()],
      components: [row],
      fetchReply: true
    });
    
    const collector = response.createMessageComponentCollector({
      filter: (i) => i.user.id === userId,
      time: 60000
    });
    
    collector.on('collect', async (btnInteraction) => {
      if (gameOver) return;
      
      if (btnInteraction.customId === 'hit') {
        playerHand.push(deck.pop());
        const playerValue = calculateHand(playerHand);
        
        if (playerValue > 21) {
          gameOver = true;
          
          await updateCristais(userId, guildId, -amount);
          const newBalance = userCristais - amount;
          
          const finalEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('☠️ VOCÊ ESTOUROU! ☠️')
            .setDescription(`Sua mão totalizou ${playerValue} - Você perdeu!`)
            .addFields(
              { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '💸 Perdido', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
            )
            .setTimestamp();
          
          await btnInteraction.update({ embeds: [finalEmbed], components: [] });
          collector.stop();
        } else {
          await btnInteraction.update({ embeds: [updateGameDisplay()] });
        }
      } else if (btnInteraction.customId === 'stand') {
        gameOver = true;
        
        let dealerValue = calculateHand(dealerHand);
        const playerValue = calculateHand(playerHand);
        
        while (dealerValue < 17) {
          dealerHand.push(deck.pop());
          dealerValue = calculateHand(dealerHand);
        }
        
        const dealerBusted = dealerValue > 21;
        
        let result = '';
        let won = false;
        let color = 0xFFB6C1;
        let emoji = '🤝';
        
        if (dealerBusted) {
          result = `Dealer estourou! Você ganhou!`;
          won = true;
          color = 0x00FF00;
          emoji = '🎉';
        } else if (playerValue > dealerValue) {
          result = `${playerValue} vs ${dealerValue} - Você ganhou!`;
          won = true;
          color = 0x00FF00;
          emoji = '🎉';
        } else if (dealerValue > playerValue) {
          result = `${playerValue} vs ${dealerValue} - Dealer venceu!`;
          color = 0xFF0000;
          emoji = '☠️';
        } else {
          result = `${playerValue} vs ${dealerValue} - Empate!`;
          color = 0xFFB6C1;
          emoji = '🤝';
        }
        
        if (won) {
          const winnings = amount * 2;
          await updateCristais(userId, guildId, winnings);
          const newBalance = userCristais + winnings;
          
          const finalEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} ${result}`)
            .addFields(
              { name: '🤖 Dealer', value: `${dealerHand.map(getCardString).join(' ')}\nTotal: ${dealerValue}`, inline: false },
              { name: '👤 Você', value: `${playerHand.map(getCardString).join(' ')}\nTotal: ${playerValue}`, inline: false },
              { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '🏆 Ganho', value: `\`${winnings.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
            )
            .setTimestamp();
          
          await btnInteraction.update({ embeds: [finalEmbed], components: [] });
        } else if (result.includes('Empate')) {
          const finalEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} ${result}`)
            .addFields(
              { name: '🤖 Dealer', value: `${dealerHand.map(getCardString).join(' ')}\nTotal: ${dealerValue}`, inline: false },
              { name: '👤 Você', value: `${playerHand.map(getCardString).join(' ')}\nTotal: ${playerValue}`, inline: false },
              { name: '💎 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎 (Devolvida)`, inline: true }
            )
            .setTimestamp();
          
          await btnInteraction.update({ embeds: [finalEmbed], components: [] });
        } else {
          await updateCristais(userId, guildId, -amount);
          const newBalance = userCristais - amount;
          
          const finalEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} ${result}`)
            .addFields(
              { name: '🤖 Dealer', value: `${dealerHand.map(getCardString).join(' ')}\nTotal: ${dealerValue}`, inline: false },
              { name: '👤 Você', value: `${playerHand.map(getCardString).join(' ')}\nTotal: ${playerValue}`, inline: false },
              { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '💸 Perdido', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
              { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
            )
            .setTimestamp();
          
          await btnInteraction.update({ embeds: [finalEmbed], components: [] });
        }
        
        collector.stop();
      }
    });
    
    collector.on('end', async () => {
      if (!gameOver) {
        await interaction.editReply({ components: [] }).catch(() => {});
      }
    });
  },
};
