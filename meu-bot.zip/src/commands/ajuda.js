const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ajuda')
    .setDescription('Mostra todos os comandos disponíveis'),
  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('📚 Comandos da Ayumi')
      .setDescription('Bem-vindo! Sou a **Ayumi**, um bot para entreter o servidor! 🎉\nUse `/comando` para executar ou `ay comando` com prefixo.')
      .addFields(
        { name: '📌 Geral', value: '`/ping` `/info` `/botinfo` `/servidor` `/avatar`', inline: false },
        { name: '💰 Economia', value: '`/daily` `/trabalhar` `/crime` `/pagar` `/atm` `/bolsa` `/ranking`', inline: false },
        { name: '🎮 Jogos', value: '`/blackjack` `/coinflip` `/mines`', inline: false },
        { name: '⚔️ RPG', value: '`/registrar` `/status` `/lutar` `/minerar` `/habilidade` `/aldeia` `/descansar` `/mapas` `/viajar`', inline: false },
        { name: '🎉 Diversão', value: '`/tapa` `/beijo` `/abraço` `/cafuné` `/fofocanews` `/curiosidades`', inline: false },
        { name: '🔧 Utilidades', value: '`/limpar`', inline: false },
        { name: '🤖 IA', value: '`/ia`', inline: false }
      )
      .setTimestamp()
      .setFooter({ text: 'Prefixo: ay | Slash Commands: /' });

    await interaction.reply({ embeds: [embed] });
  },
};
