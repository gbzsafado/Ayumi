const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { setCristais, getUser } = require('../database');

const OWNER_ID = '1275126713592053780';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setcristal')
    .setDescription('Define a quantidade de cristais de um usuário (apenas para o dono)')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('Usuário para definir cristais')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('quantidade')
        .setDescription('Quantidade de cristais')
        .setRequired(true)
        .setMinValue(0)),
  async execute(interaction, client) {
    if (interaction.user.id !== OWNER_ID) {
      return interaction.reply({ content: '❌ Você não tem permissão para usar este comando!', ephemeral: true });
    }

    const targetUser = interaction.options.getUser('usuario');
    const amount = interaction.options.getInteger('quantidade');

    try {
      await setCristais(targetUser.id, interaction.guildId, amount);

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('💎 Cristais Definidos')
        .setDescription(`Cristais de ${targetUser} foram ajustados para \`${amount}\` 💎`)
        .addFields(
          { name: 'Usuário', value: targetUser.tag, inline: true },
          { name: 'Novo Saldo', value: `\`${amount.toLocaleString('pt-BR')}\``, inline: true },
          { name: 'Modificado por', value: interaction.user.tag, inline: true }
        )
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Erro ao setar cristais:', error);
      return interaction.reply({ content: '❌ Ocorreu um erro ao definir os cristais!', ephemeral: true });
    }
  },
};
