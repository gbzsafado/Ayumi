const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, getGuardian, createGuardian } = require('../database');

const GUARDIAN_TYPES = {
  slime: { emoji: '🟢', name: 'Slime', evolutions: ['Slime', 'Slime Guerreiro', 'Slime Rei'], evolutionEmojis: ['🟢', '⚔️🟢', '👑🟢'], damages: [10, 20, 30], ability: 'Bônus de Dano', abilityValues: [10, 20, 30] },
  fada: { emoji: '🧚', name: 'Fada', evolutions: ['Fada', 'Fada Madrinha', 'Fada Rainha'], evolutionEmojis: ['🧚', '✨🧚', '👑🧚'], damages: [20, 40, 60], ability: 'Cura', abilityValues: [20, 40, 60] },
  golem: { emoji: '🪨', name: 'Mini Golem', evolutions: ['Mini Golem', 'Golem', 'Golem Titânico'], evolutionEmojis: ['🪨', '🗿', '🏔️'], damages: [20, 40, 60], ability: 'Escudo', abilityValues: [20, 40, 60] },
  goblin: { emoji: '👺', name: 'Goblin', evolutions: ['Goblin', 'Máquina Goblin', 'Goblin Gigante'], evolutionEmojis: ['👺', '🤖👺', '💪👺'], damages: [10, 25, 40], ability: 'Agilidade', abilityValues: [10, 25, 40] }
};

module.exports = {
  GUARDIAN_TYPES,
  data: new SlashCommandBuilder()
    .setName('guardiao')
    .setDescription('Veja ou adote um Guardião Mirim!')
    .addStringOption(o => o.setName('acao').setDescription('O que deseja fazer?').addChoices({ name: '👀 Ver', value: 'ver' }, { name: '🥚 Adotar', value: 'adotar' })),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const acao = interaction.options.getString('acao') || 'ver';
    const user = await getUser(userId, guildId);
    const guardian = await getGuardian(userId, guildId);
    
    if (!user.rpg_class) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Use `/registrar`!')], ephemeral: true });
    
    if (acao === 'ver') {
      if (!guardian) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FFA500').setTitle('🥚 Sem Guardião').setDescription('Use `/guardiao acao:Adotar` para escolher!')] });
      const type = GUARDIAN_TYPES[guardian.guardian_type];
      const stage = guardian.evolution_stage;
      return interaction.reply({ embeds: [new EmbedBuilder().setColor('#9B59B6').setTitle(`${type.evolutionEmojis[stage - 1]} ${guardian.guardian_name}`).setDescription(`❤️ ${guardian.health}/${guardian.max_health}\n⚔️ ${guardian.attack} 🛡️ ${guardian.defense}\nNv.${guardian.level} | Afinidade: ${guardian.afinidade || 0}%`)] });
    }
    
    if (acao === 'adotar') {
      if (guardian) return interaction.reply({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Já tem Guardião!')], ephemeral: true });
      
      const menu = new StringSelectMenuBuilder()
        .setCustomId('select_guardian_type')
        .setPlaceholder('🥚 Escolha seu Guardião...')
        .addOptions([
          { label: 'Slime', description: 'Dano +10%/20%/30%', value: 'slime', emoji: '🟢' },
          { label: 'Fada', description: 'Cura +20%/40%/60%', value: 'fada', emoji: '🧚' },
          { label: 'Golem', description: 'Escudo -20%/40%/60%', value: 'golem', emoji: '🪨' },
          { label: 'Goblin', description: 'Agilidade +10%/25%/40%', value: 'goblin', emoji: '👺' }
        ]);
      
      const row = new ActionRowBuilder().addComponents(menu);
      const res = await interaction.reply({ components: [row], fetchReply: true });
      
      const collector = res.createMessageComponentCollector({ time: 60000 });
      
      collector.on('collect', async (i) => {
        if (i.user.id !== userId) return i.reply({ content: '❌ Não é sua escolha!', ephemeral: true });
        
        if (i.customId === 'select_guardian_type') {
          const selectedType = i.values[0];
          const inf = GUARDIAN_TYPES[selectedType];
          
          const evolutionsText = inf.evolutions.map((evo, idx) => {
            return `${inf.evolutionEmojis[idx]} **${evo}** - ${inf.ability} +${inf.damages[idx]}%`;
          }).join('\n');
          
          const confirmBtn = new ButtonBuilder()
            .setCustomId(`confirm_${selectedType}`)
            .setLabel('✅ Adotar')
            .setStyle(ButtonStyle.Success);
          const cancelBtn = new ButtonBuilder()
            .setCustomId('cancel_guardian')
            .setLabel('❌ Cancelar')
            .setStyle(ButtonStyle.Danger);
          
          const btnRow = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);
          
          await i.update({
            embeds: [new EmbedBuilder()
              .setColor('#9B59B6')
              .setTitle(`${inf.emoji} ${inf.name}`)
              .setDescription(`**${inf.ability}**\n\n**Evoluções:**\n${evolutionsText}\n\nDeseja adotar?`)],
            components: [btnRow]
          });
          
          const btnCollector = res.createMessageComponentCollector({ time: 30000, dispose: true });
          
          btnCollector.on('collect', async (btnI) => {
            if (btnI.user.id !== userId) return btnI.reply({ content: '❌ Não é sua escolha!', ephemeral: true });
            
            if (btnI.customId === `confirm_${selectedType}`) {
              await createGuardian(userId, guildId, selectedType, inf.name);
              await btnI.update({
                embeds: [new EmbedBuilder()
                  .setColor('#00FF00')
                  .setTitle('🎉 Adotado!')
                  .setDescription(`Seu novo guardião é **${inf.emoji} ${inf.name}**!\n\nUse /guardiao-info para ver detalhes!`)],
                components: []
              });
              btnCollector.stop();
              collector.stop();
            } else if (btnI.customId === 'cancel_guardian') {
              await btnI.update({ embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Cancelado')], components: [] });
              btnCollector.stop();
              collector.stop();
            }
          });
        }
      });
    }
  }
};
