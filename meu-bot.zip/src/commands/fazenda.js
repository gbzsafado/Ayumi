const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getFazenda, updateFazenda, getPlantacoes, getAnimais, getConstrucoes, getFerramentas, getInventarioFazenda } = require('../fazenda/database');
const { ESTACOES, CLIMAS, PLANTAS, CONSTRUCOES } = require('../fazenda/data');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fazenda')
    .setDescription('Veja sua fazenda e status geral'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;

    const fazenda = await getFazenda(userId, guildId);
    const plantacoes = await getPlantacoes(userId, guildId);
    const animais = await getAnimais(userId, guildId);
    const construcoes = await getConstrucoes(userId, guildId);

    const estacao = ESTACOES[fazenda.estacao];
    const clima = CLIMAS[fazenda.clima];
    const expProximoNivel = fazenda.nivel * 1000;
    const progresso = Math.floor((fazenda.exp / expProximoNivel) * 10);
    const barraExp = '█'.repeat(progresso) + '░'.repeat(10 - progresso);

    let plantasStatus = '';
    for (let i = 0; i < fazenda.slots_plantio; i++) {
      const planta = plantacoes.find(p => p.slot === i);
      if (planta) {
        const agora = new Date();
        const pronto = new Date(planta.pronto_em);
        if (agora >= pronto) {
          const plantaData = PLANTAS[planta.planta_tipo];
          plantasStatus += `${plantaData?.emoji || '🌱'} `;
        } else {
          const tempoRestante = Math.ceil((pronto - agora) / 60000);
          plantasStatus += `🌱(${tempoRestante}m) `;
        }
      } else {
        plantasStatus += '⬜ ';
      }
    }

    const embed = new EmbedBuilder()
      .setColor('#2ECC71')
      .setTitle(`🌾 ${fazenda.nome}`)
      .setDescription(`
${estacao.emoji} **Estação:** ${estacao.nome}
${clima.emoji} **Clima:** ${clima.nome}

**Nível:** ${fazenda.nivel} | EXP: [${barraExp}] ${fazenda.exp}/${expProximoNivel}
**Energia:** ⚡ ${fazenda.energia}/${fazenda.max_energia}
**Moedas:** 🪙 ${fazenda.moedas_fazenda.toLocaleString()}

**Plantações (${plantacoes.length}/${fazenda.slots_plantio}):**
${plantasStatus || 'Nenhuma planta'}

**Animais:** 🐾 ${animais.length}
**Construções:** 🏗️ ${construcoes.length}
      `)
      .setFooter({ text: `Use /plantar, /regar, /colher para gerenciar suas plantações` })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder().setCustomId('fazenda_plantas').setLabel('🌱 Plantas').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('fazenda_animais').setLabel('🐄 Animais').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('fazenda_construcoes').setLabel('🏗️ Construções').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('fazenda_inventario').setLabel('📦 Inventário').setStyle(ButtonStyle.Secondary)
      );

    const response = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const collector = response.createMessageComponentCollector({ time: 120000 });

    collector.on('collect', async i => {
      if (i.user.id !== userId) {
        return i.reply({ content: 'Esta não é sua fazenda!', ephemeral: true });
      }

      if (i.customId === 'fazenda_plantas') {
        const plantasEmbed = new EmbedBuilder()
          .setColor('#27AE60')
          .setTitle('🌱 Suas Plantações')
          .setDescription(plantacoes.length > 0 
            ? plantacoes.map(p => {
                const planta = PLANTAS[p.planta_tipo];
                const agora = new Date();
                const pronto = new Date(p.pronto_em);
                const status = agora >= pronto ? '✅ Pronta!' : `⏳ ${Math.ceil((pronto - agora) / 60000)}min`;
                return `**Slot ${p.slot + 1}:** ${planta?.emoji || '🌱'} ${planta?.nome || p.planta_tipo} - ${status}\n💧 Água: ${p.agua} | ${p.fertilizante ? `🧪 ${p.fertilizante}` : ''}`;
              }).join('\n\n')
            : 'Nenhuma planta. Use `/plantar` para começar!');

        await i.update({ embeds: [plantasEmbed], components: [row] });
      }

      if (i.customId === 'fazenda_animais') {
        const animaisEmbed = new EmbedBuilder()
          .setColor('#3498DB')
          .setTitle('🐄 Seus Animais')
          .setDescription(animais.length > 0
            ? animais.map(a => {
                return `**${a.nome || a.animal_tipo}** - ❤️ ${a.saude}% | 😊 ${a.felicidade}%${a.doenca ? ` | 🤒 ${a.doenca}` : ''}`;
              }).join('\n')
            : 'Nenhum animal. Use `/comprar-animal` para adquirir!');

        await i.update({ embeds: [animaisEmbed], components: [row] });
      }

      if (i.customId === 'fazenda_construcoes') {
        const construcoesEmbed = new EmbedBuilder()
          .setColor('#9B59B6')
          .setTitle('🏗️ Suas Construções')
          .setDescription(construcoes.length > 0
            ? construcoes.map(c => {
                const data = CONSTRUCOES[c.construcao_tipo];
                return `${data?.emoji || '🏠'} **${data?.nome || c.construcao_tipo}** - Nível ${c.nivel}/${data?.max_nivel || 5}`;
              }).join('\n')
            : 'Nenhuma construção. Use `/construir` para começar!');

        await i.update({ embeds: [construcoesEmbed], components: [row] });
      }

      if (i.customId === 'fazenda_inventario') {
        const inventario = await getInventarioFazenda(userId, guildId);
        const inventarioEmbed = new EmbedBuilder()
          .setColor('#E67E22')
          .setTitle('📦 Seu Inventário')
          .setDescription(inventario.length > 0
            ? inventario.slice(0, 20).map(item => `• **${item.item_tipo}**: ${item.quantidade}x${item.raridade ? ` (${item.raridade})` : ''}`).join('\n')
            : 'Inventário vazio.');

        await i.update({ embeds: [inventarioEmbed], components: [row] });
      }
    });
  }
};
