const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFazenda, updateFazenda, getPlantacoes, plantar, getInventarioFazenda, removerItemFazenda, getConstrucoes } = require('../fazenda/database');
const { PLANTAS, ESTACOES, FERTILIZANTES, RARIDADES } = require('../fazenda/data');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('plantar')
    .setDescription('Plante uma semente na sua fazenda')
    .addStringOption(option =>
      option.setName('planta')
        .setDescription('Tipo de planta para plantar')
        .setRequired(true)
        .addChoices(
          { name: '🌾 Trigo (10🪙)', value: 'trigo' },
          { name: '🥕 Cenoura (15🪙)', value: 'cenoura' },
          { name: '🍅 Tomate (25🪙)', value: 'tomate' },
          { name: '🌽 Milho (30🪙)', value: 'milho' },
          { name: '🥔 Batata (20🪙)', value: 'batata' },
          { name: '🍓 Morango (35🪙)', value: 'morango' },
          { name: '🎃 Abóbora (50🪙)', value: 'abobora' },
          { name: '🍉 Melancia (80🪙)', value: 'melancia' },
          { name: '🍇 Uva (100🪙)', value: 'uva' },
          { name: '🍎 Maçã (150🪙)', value: 'maca' },
          { name: '🌹 Rosa Mística (500🪙)', value: 'rosa_mistica' },
          { name: '🌙 Flor Lunar (1000🪙)', value: 'flor_lunar' }
        ))
    .addIntegerOption(option =>
      option.setName('slot')
        .setDescription('Slot para plantar (1-12)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(12))
    .addStringOption(option =>
      option.setName('fertilizante')
        .setDescription('Fertilizante para usar')
        .addChoices(
          { name: '🧪 Básico (+20% velocidade)', value: 'basico' },
          { name: '⚗️ Qualidade (+10% raridade)', value: 'qualidade' },
          { name: '⚡ Veloz (+50% velocidade)', value: 'velocidade' },
          { name: '✨ Premium (+30% vel, +15% rar)', value: 'premium' }
        )),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const plantaTipo = interaction.options.getString('planta');
    const slot = interaction.options.getInteger('slot') - 1;
    const fertilizanteTipo = interaction.options.getString('fertilizante');

    const fazenda = await getFazenda(userId, guildId);
    const planta = PLANTAS[plantaTipo];

    if (!planta) {
      return interaction.reply({ content: '❌ Planta inválida!', ephemeral: true });
    }

    if (slot >= fazenda.slots_plantio) {
      return interaction.reply({ content: `❌ Você só tem ${fazenda.slots_plantio} slots de plantio. Construa uma **Estufa** para mais slots!`, ephemeral: true });
    }

    const plantacoes = await getPlantacoes(userId, guildId);
    const slotOcupado = plantacoes.find(p => p.slot === slot);
    if (slotOcupado) {
      return interaction.reply({ content: `❌ O slot ${slot + 1} já está ocupado! Use \`/colher\` primeiro.`, ephemeral: true });
    }

    const estacao = ESTACOES[fazenda.estacao];
    const construcoes = await getConstrucoes(userId, guildId);
    const temEstufa = construcoes.some(c => c.construcao_tipo === 'estufa');
    
    if (!planta.estacao.includes(fazenda.estacao) && !temEstufa) {
      return interaction.reply({ 
        content: `❌ ${planta.emoji} ${planta.nome} só cresce em: ${planta.estacao.map(e => ESTACOES[e].emoji + ESTACOES[e].nome).join(', ')}.\nEstação atual: ${estacao.emoji} ${estacao.nome}`, 
        ephemeral: true 
      });
    }

    let custoTotal = planta.preco_semente;
    let fertilizante = null;
    
    if (fertilizanteTipo) {
      fertilizante = FERTILIZANTES[fertilizanteTipo];
      const inventario = await getInventarioFazenda(userId, guildId);
      const temFertilizante = inventario.find(i => i.item_tipo === `fertilizante_${fertilizanteTipo}` && i.quantidade > 0);
      
      if (!temFertilizante) {
        custoTotal += fertilizante.preco;
      } else {
        await removerItemFazenda(userId, guildId, `fertilizante_${fertilizanteTipo}`, 1);
      }
    }

    if (fazenda.moedas_fazenda < custoTotal) {
      return interaction.reply({ content: `❌ Moedas insuficientes! Você tem 🪙 ${fazenda.moedas_fazenda} e precisa de 🪙 ${custoTotal}`, ephemeral: true });
    }

    if (fazenda.energia < 5) {
      return interaction.reply({ content: `❌ Energia insuficiente! Você precisa de ⚡ 5 energia para plantar.`, ephemeral: true });
    }

    let tempoCrescimento = planta.tempo;
    tempoCrescimento = Math.floor(tempoCrescimento * estacao.bonus_crescimento);
    if (fertilizante) {
      tempoCrescimento = Math.floor(tempoCrescimento / fertilizante.bonus_crescimento);
    }

    await updateFazenda(userId, guildId, {
      moedas_fazenda: fazenda.moedas_fazenda - custoTotal,
      energia: fazenda.energia - 5
    });

    await plantar(userId, guildId, slot, plantaTipo, fertilizanteTipo, temEstufa && slot >= 6, tempoCrescimento);

    const embed = new EmbedBuilder()
      .setColor('#27AE60')
      .setTitle('🌱 Semente Plantada!')
      .setDescription(`
${planta.emoji} **${planta.nome}** plantada no slot ${slot + 1}!

⏳ **Tempo de crescimento:** ${tempoCrescimento} minutos
${fertilizante ? `🧪 **Fertilizante:** ${fertilizante.nome}` : ''}
💰 **Custo:** 🪙 ${custoTotal}
⚡ **Energia restante:** ${fazenda.energia - 5}

💡 Use \`/regar ${slot + 1}\` para acelerar o crescimento!
      `)
      .setFooter({ text: `Estação: ${estacao.emoji} ${estacao.nome}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
