const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { execute: dbExecute } = require('../database');

const OWNER_ID = '1275126713592053780';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reportarbug')
    .setDescription('Reporte um bug encontrado no bot')
    .addStringOption(option =>
      option.setName('titulo')
        .setDescription('Título do bug')
        .setRequired(true)
        .setMaxLength(100)
    )
    .addStringOption(option =>
      option.setName('descricao')
        .setDescription('Descrição detalhada do bug')
        .setRequired(true)
        .setMaxLength(500)
    ),

  async execute(interaction, client) {
    const titulo = interaction.options.getString('titulo');
    const descricao = interaction.options.getString('descricao');
    const userId = interaction.user.id;
    const username = interaction.user.username;
    const timestamp = new Date();

    try {
      // Salva o bug no banco de dados
      await dbExecute(
        `INSERT INTO bug_reports (user_id, username, titulo, descricao, timestamp, guild_id)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, username, titulo, descricao, timestamp, interaction.guildId]
      );

      // Envia confirmação ao usuário
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('✅ Bug Reportado!')
          .setDescription('Obrigado por nos ajudar a melhorar o bot!\nO dono foi notificado.')
          .addFields({ name: 'Título', value: titulo }, { name: 'Descrição', value: descricao })
        ],
        ephemeral: true
      });

      // Envia DM ao dono com o bug
      try {
        const owner = await client.users.fetch(OWNER_ID);
        await owner.send({
          embeds: [new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('🐛 NOVO BUG REPORTADO!')
            .addFields(
              { name: '👤 Reportado por', value: `${username} (${userId})` },
              { name: '🖥️ Servidor', value: `${interaction.guild?.name || 'DM'}` },
              { name: '📋 Título', value: titulo },
              { name: '📝 Descrição', value: descricao },
              { name: '⏰ Data/Hora', value: timestamp.toLocaleString('pt-BR') }
            )
            .setTimestamp()
          ]
        });
      } catch (err) {
        console.log('Não foi possível enviar DM ao dono');
      }
    } catch (err) {
      console.error('Erro ao reportar bug:', err);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Erro')
          .setDescription('Erro ao reportar o bug. Tente novamente mais tarde.')
        ],
        ephemeral: true
      });
    }
  }
};
