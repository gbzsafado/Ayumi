const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateMoedas, updateRPGStats, updateInventory, getInventory, updateMissionProgress, checkMissionCompletion } = require('../database');

const DROPS = {
  essencia_monstro: { emoji: '💜', name: 'Essência de Monstro', baseChance: 60 },
  fragmento_osso: { emoji: '🦴', name: 'Fragmento de Osso', baseChance: 40 },
  presas: { emoji: '🦷', name: 'Presas', baseChance: 35 },
  fragmento_sombrio: { emoji: '🖤', name: 'Fragmento Sombrio', baseChance: 25 },
  escama_dragao: { emoji: '🐲', name: 'Escama de Dragão', baseChance: 15 },
  coracao_monstro: { emoji: '❤️‍🔥', name: 'Coração de Monstro', baseChance: 10 },
  erva_curativa: { emoji: '🌿', name: 'Erva Curativa', baseChance: 50 },
  po_magico: { emoji: '✨', name: 'Pó Mágico', baseChance: 30 }
};

const ENEMY_DROPS = {
  'Goblin': ['essencia_monstro', 'erva_curativa'],
  'Lobo': ['essencia_monstro', 'presas', 'erva_curativa'],
  'Esqueleto': ['essencia_monstro', 'fragmento_osso', 'po_magico'],
  'Orc': ['essencia_monstro', 'presas', 'coracao_monstro'],
  'Morcego Gigante': ['essencia_monstro', 'presas', 'po_magico'],
  'Cavaleiro Sombrio': ['essencia_monstro', 'fragmento_sombrio', 'coracao_monstro'],
  'Dragão Menor': ['essencia_monstro', 'escama_dragao', 'coracao_monstro', 'po_magico'],
  'Lich': ['essencia_monstro', 'fragmento_sombrio', 'po_magico', 'coracao_monstro'],
  'Aranha Gigante': ['essencia_monstro', 'presas', 'po_magico'],
  'Urso': ['essencia_monstro', 'presas', 'erva_curativa'],
  'Curupira': ['essencia_monstro', 'erva_curativa', 'po_magico', 'fragmento_sombrio'],
  'Escorpião da Cauda Rosa': ['essencia_monstro', 'presas', 'fragmento_osso'],
  'Escorpião Infernal': ['essencia_monstro', 'presas', 'fragmento_sombrio'],
  'Bandido do Deserto': ['essencia_monstro', 'fragmento_osso', 'coracao_monstro'],
  'Serpente de Areia': ['essencia_monstro', 'presas', 'po_magico'],
  'Múmia': ['essencia_monstro', 'fragmento_osso', 'fragmento_sombrio', 'coracao_monstro', 'escama_dragao']
};

function calculateDrops(enemyName, enemyTier, hasLucky = false) {
  const possibleDrops = ENEMY_DROPS[enemyName] || ['essencia_monstro'];
  const drops = [];
  const luckyBonus = hasLucky ? 25 : 0;
  const tierBonus = (enemyTier - 1) * 5;

  for (const dropId of possibleDrops) {
    const drop = DROPS[dropId];
    const chance = Math.min(95, drop.baseChance + tierBonus + luckyBonus);
    
    if (Math.random() * 100 < chance) {
      const quantity = Math.floor(Math.random() * enemyTier) + 1;
      drops.push({ id: dropId, ...drop, quantity });
    }
  }

  return drops;
}

const MAP_ENEMIES = {
  floresta_sombria: [
    { name: 'Lobo', emoji: '🐺', health: 70, attack: 22, defense: 6, mobility: 55, tier: 1, xp: 18, chance: 30 },
    { name: 'Aranha Gigante', emoji: '🕷️', health: 65, attack: 24, defense: 8, mobility: 60, tier: 1, xp: 20, chance: 25 },
    { name: 'Urso', emoji: '🐻', health: 100, attack: 26, defense: 15, mobility: 35, tier: 2, xp: 25, chance: 30 },
    { name: 'Curupira', emoji: '🧝', health: 120, attack: 30, defense: 20, mobility: 70, tier: 3, xp: 40, chance: 15, rare: true }
  ],
  deserto_infernal: [
    { name: 'Escorpião da Cauda Rosa', emoji: '🦂', health: 85, attack: 28, defense: 12, mobility: 50, tier: 2, xp: 28, chance: 25 },
    { name: 'Escorpião Infernal', emoji: '🔥', health: 100, attack: 32, defense: 15, mobility: 45, tier: 3, xp: 35, chance: 20 },
    { name: 'Bandido do Deserto', emoji: '🥷', health: 90, attack: 30, defense: 18, mobility: 60, tier: 2, xp: 30, chance: 25 },
    { name: 'Serpente de Areia', emoji: '🐍', health: 75, attack: 35, defense: 10, mobility: 75, tier: 2, xp: 32, chance: 15 },
    { name: 'Múmia', emoji: '🧟', health: 150, attack: 38, defense: 25, mobility: 30, tier: 4, xp: 55, chance: 15, rare: true }
  ]
};

const BASE_ENEMIES = [
  { name: 'Goblin', emoji: '👹', health: 80, attack: 20, defense: 8, mobility: 40, tier: 1, xp: 15 },
  { name: 'Lobo', emoji: '🐺', health: 70, attack: 22, defense: 6, mobility: 55, tier: 1, xp: 18 },
  { name: 'Esqueleto', emoji: '💀', health: 75, attack: 18, defense: 12, mobility: 45, tier: 1, xp: 16 },
  { name: 'Orc', emoji: '👺', health: 100, attack: 25, defense: 15, mobility: 35, tier: 2, xp: 25 },
  { name: 'Morcego Gigante', emoji: '🦇', health: 60, attack: 24, defense: 5, mobility: 70, tier: 2, xp: 22 },
  { name: 'Cavaleiro Sombrio', emoji: '🖤', health: 130, attack: 28, defense: 22, mobility: 30, tier: 3, xp: 35 },
  { name: 'Dragão Menor', emoji: '🐉', health: 180, attack: 35, defense: 25, mobility: 45, tier: 4, xp: 50 },
  { name: 'Lich', emoji: '👻', health: 150, attack: 40, defense: 18, mobility: 50, tier: 5, xp: 65 }
];

const SKILL_CHANCE = 0.45;

function calculateLevel(xp) {
  return Math.floor(xp / 100) + 1;
}

function getEnemyForLevel(playerLevel, currentMap = 'floresta_sombria') {
  const mapEnemies = MAP_ENEMIES[currentMap] || MAP_ENEMIES.floresta_sombria;
  
  const roll = Math.random() * 100;
  let cumulative = 0;
  let selectedEnemy = null;
  
  for (const enemy of mapEnemies) {
    cumulative += enemy.chance;
    if (roll < cumulative) {
      selectedEnemy = enemy;
      break;
    }
  }
  
  if (!selectedEnemy) {
    selectedEnemy = mapEnemies[0];
  }
  
  const baseEnemy = JSON.parse(JSON.stringify(selectedEnemy));
  const levelMultiplier = 1 + (playerLevel - 1) * 0.12;
  
  baseEnemy.health = Math.floor(baseEnemy.health * levelMultiplier);
  baseEnemy.attack = Math.floor(baseEnemy.attack * levelMultiplier);
  baseEnemy.defense = Math.floor(baseEnemy.defense * levelMultiplier);
  baseEnemy.mobility = Math.floor(baseEnemy.mobility * (1 + (playerLevel - 1) * 0.03));
  baseEnemy.xp = Math.floor(baseEnemy.xp * levelMultiplier);
  baseEnemy.level = playerLevel;
  baseEnemy.poison = 0;
  baseEnemy.max_health = baseEnemy.health;
  
  return baseEnemy;
}

function calculatePlayerDamage(player, enemy, playerLevel) {
  const baseAttack = Number(player.rpg_attack) || 50;
  const levelBonus = (playerLevel - 1) * 2;
  const attack = baseAttack + levelBonus;
  const defense = Number(enemy.defense) || 10;
  
  const baseDamage = 8 + (attack * 0.25) - (defense * 0.15);
  const variance = Math.random() * 0.15 + 0.9;
  return Math.max(5, Math.floor(baseDamage * variance));
}

function checkCriticalHit(playerLevel) {
  const critChance = 0.15; // 15% de chance de crítico
  if (Math.random() < critChance) {
    return true;
  }
  return false;
}

function calculateEnemyDamage(enemy, player, playerLevel, defenseMultiplier = 1) {
  const attack = Number(enemy.attack) || 20;
  const baseDefense = Number(player.rpg_defense) || 30;
  const levelBonus = (playerLevel - 1) * 2;
  const defense = baseDefense + levelBonus;
  
  const baseDamage = 10 + (attack * 0.5) - (defense * 0.2 * defenseMultiplier);
  const variance = Math.random() * 0.2 + 0.9;
  return Math.max(5, Math.floor(baseDamage * variance));
}

function getDamageEmoji(damage) {
  if (damage < 15) return '💤';
  if (damage < 25) return '💥';
  if (damage < 40) return '⚡';
  if (damage < 55) return '🔥';
  return '💣';
}

function createHealthBar(current, max) {
  const currentNum = Number(current) || 0;
  const maxNum = Number(max) || 100;
  const percentage = Math.max(0, (currentNum / maxNum) * 100);
  const filled = Math.floor(percentage / 10);
  const empty = 10 - filled;
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  if (percentage > 50) return `🟩 ${bar}`;
  if (percentage > 25) return `🟨 ${bar}`;
  return `🟥 ${bar}`;
}

function createXPBar(currentXP, level) {
  const xpInCurrentLevel = currentXP - ((level - 1) * 100);
  const xpNeeded = 100;
  const percentage = Math.min(100, (xpInCurrentLevel / xpNeeded) * 100);
  const filled = Math.floor(percentage / 10);
  const empty = 10 - filled;
  return `⭐ ${'▰'.repeat(filled)}${'▱'.repeat(empty)} ${xpInCurrentLevel}/${xpNeeded}`;
}

function createBattleEmbed(player, enemy, turn, battleLog, playerLevel, playerXP, skillActive = null) {
  const playerHealth = Number(player.rpg_health) || 0;
  const playerMaxHealth = Number(player.rpg_max_health) || 100;
  const enemyHealth = Number(enemy.health) || 0;
  const enemyMaxHealth = Number(enemy.max_health) || 100;
  
  const playerBar = createHealthBar(playerHealth, playerMaxHealth);
  const enemyBar = createHealthBar(enemyHealth, enemyMaxHealth);
  const xpBar = createXPBar(playerXP, playerLevel);
  const logText = battleLog.slice(-3).join('\n') || 'Batalha iniciada!';
  
  let skillText = '';
  if (skillActive) {
    skillText = `\n**⚡ Habilidade Ativa:** ${skillActive}`;
  }

  return new EmbedBuilder()
    .setColor('#FF6B6B')
    .setTitle('⚔️ BATALHA EM ANDAMENTO')
    .setDescription(`**Turno ${turn}**\n${xpBar}${skillText}`)
    .addFields(
      { name: `${player.character_name} (Nv.${playerLevel})`, value: `${playerBar}\n❤️ ${playerHealth}/${playerMaxHealth}`, inline: true },
      { name: `vs`, value: '⚔️', inline: true },
      { name: `${enemy.emoji} ${enemy.name} (Nv.${enemy.level})`, value: `${enemyBar}\n❤️ ${enemyHealth}/${enemyMaxHealth}`, inline: true },
      { name: '📜 Histórico', value: logText, inline: false }
    )
    .setFooter({ text: `ATK: ${player.rpg_attack} | DEF: ${player.rpg_defense} | Chance: 45%` })
    .setTimestamp();
}

function tryUseSkill(player, enemy, classType, battleLog) {
  if (Math.random() > SKILL_CHANCE) {
    battleLog.push('❌ Habilidade falhou!');
    return { used: false };
  }

  let result = { used: true, damage: 0, healing: 0, effect: '' };

  if (classType.toLowerCase() === 'guerreiro') {
    result.damage = Math.floor(calculatePlayerDamage(player, enemy, 1) * 0.5);
    result.effect = '⚔️ Golpe de Poder!';
    battleLog.push(`⚔️ ${player.character_name} usou Golpe de Poder! +${result.damage} dano!`);
  } 
  else if (classType.toLowerCase() === 'mago') {
    result.damage = Math.floor(calculatePlayerDamage(player, enemy, 1) * 1.2);
    result.effect = '🔥 Explosão Mágica!';
    battleLog.push(`🔥 ${player.character_name} lançou Explosão Mágica! ${result.damage} dano!`);
  }
  else if (classType.toLowerCase() === 'assassino') {
    result.damage = Math.floor(calculatePlayerDamage(player, enemy, 1) * 0.8);
    result.healing = Math.floor(Number(player.rpg_max_health) * 0.15);
    result.effect = '☠️ Veneno!';
    enemy.poison = Math.floor(Number(enemy.max_health) * 0.03);
    battleLog.push(`☠️ ${player.character_name} aplicou Veneno! (3% de dano/turno)`);
  }
  else if (classType.toLowerCase() === 'tanque') {
    result.effect = '🛡️ Defesa Absoluta!';
    result.defenseBoost = 0.6;
    battleLog.push(`🛡️ ${player.character_name} ativou Defesa Absoluta! (60% menos dano)`);
  }
  else if (classType.toLowerCase() === 'arqueiro') {
    result.damage = Math.floor(calculatePlayerDamage(player, enemy, 1) * 1.3);
    result.effect = '🏹 Chuva de Flechas!';
    battleLog.push(`🏹 ${player.character_name} lançou Chuva de Flechas! ${result.damage} dano!`);
  }

  return result;
}

async function startBattle(context, client) {
  const userId = context.user.id;
  const guildId = context.guildId;
  const user = await getUser(userId, guildId);

  if (!user.rpg_class) {
    return context.reply({
      embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Erro').setDescription('Use `/registrar` primeiro!')],
      ephemeral: true
    });
  }

  user.rpg_health = Number(user.rpg_health) || 0;
  user.rpg_max_health = Number(user.rpg_max_health) || 100;
  user.rpg_attack = Number(user.rpg_attack) || 50;
  user.rpg_defense = Number(user.rpg_defense) || 30;
  user.rpg_mobility = Number(user.rpg_mobility) || 50;
  
  let playerXP = Number(user.rpg_exp) || 0;
  let playerLevel = calculateLevel(playerXP);
  const currentMap = user.current_map || 'floresta_sombria';
  const weaponBonus = user.weapon_bonus || 0;
  user.rpg_attack = (Number(user.rpg_attack) || 50) + weaponBonus;

  if (user.rpg_health <= 0) {
    return context.reply({
      embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Derrotado!').setDescription('Recupere sua saúde com `/descansar`')],
      ephemeral: true
    });
  }

  const MAP_NAMES = {
    floresta_sombria: '🌲 Floresta Sombria',
    deserto_infernal: '🏜️ Deserto Infernal'
  };

  const enemy = getEnemyForLevel(playerLevel, currentMap);

  let turn = 1;
  let battleLog = [];
  let playerTurn = user.rpg_mobility >= enemy.mobility;
  let skillActive = null;
  let defenseBoost = 1;

  if (playerTurn) {
    battleLog.push(`${user.character_name} é mais rápido e ataca primeiro!`);
  } else {
    battleLog.push(`${enemy.name} é mais rápido e ataca primeiro!`);
  }

  const response = await context.reply({ embeds: [createBattleEmbed(user, enemy, turn, battleLog, playerLevel, playerXP)], fetchReply: true });

  const filter = (i) => i.user.id === userId;
  const collector = response.createMessageComponentCollector({ filter, time: 120000 });

  async function continueBattle() {
    const historyText = battleLog.slice(-6).join('\n') || 'Sem histórico';
      
      if (user.rpg_health <= 0) {
        await updateRPGStats(user.user_id, user.guild_id, { health: 0 });
        
        const inventory = await getInventory(user.user_id, user.guild_id);
        const luckyItem = inventory.find(i => i.item_id === 'buff_lucky' && i.quantity > 0);
        if (luckyItem) {
          await updateInventory(user.user_id, user.guild_id, 'buff_lucky', -1);
        }
        
        const defeatEmbed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('💀 Você foi derrotado!')
          .setDescription(`O **${enemy.emoji} ${enemy.name}** venceu a batalha!`)
          .addFields(
            { name: '📜 Histórico da Batalha', value: historyText, inline: false },
            { name: '💡 Dica', value: 'Use `/descansar` para recuperar sua saúde.', inline: false }
          )
          .setTimestamp();
        await context.editReply({ embeds: [defeatEmbed], components: [] });
        collector.stop();
        return;
      }

    if (enemy.health <= 0) {
        const xpGained = enemy.xp;
        const oldLevel = playerLevel;
        playerXP += xpGained;
        const newLevel = calculateLevel(playerXP);
        
        const baseReward = 80 + (playerLevel * 15);
        const reward = Math.floor(Math.random() * 40) + baseReward;
        
        // 20% chance de um ladrão aparecer e roubar as moedas
        const thiefChance = Math.random();
        const thiefAppeared = thiefChance < 0.2;
        let actualReward = reward;
        
        if (thiefAppeared) {
          actualReward = 0; // Ladrão rouba todas as moedas
        }
        
        await updateMoedas(user.user_id, user.guild_id, actualReward);
        
        const inventory = await getInventory(user.user_id, user.guild_id);
        const luckyItem = inventory.find(i => i.item_id === 'buff_lucky' && i.quantity > 0);
        const hasLucky = !!luckyItem;
        
        if (hasLucky) {
          await updateInventory(user.user_id, user.guild_id, 'buff_lucky', -1);
        }
        
        const drops = calculateDrops(enemy.name, enemy.tier, hasLucky);
        let dropsText = '';
        
        for (const drop of drops) {
          await updateInventory(user.user_id, user.guild_id, drop.id, drop.quantity);
          dropsText += `${drop.emoji} ${drop.name} x${drop.quantity}\n`;
        }
        
        if (drops.length === 0) {
          dropsText = '❌ Nenhum item dropou';
        }
        
        let levelUpText = '';
        let newStats = { health: user.rpg_health, exp: playerXP };
        
        if (newLevel > oldLevel) {
          const attackBonus = 3;
          const defenseBonus = 2;
          const healthBonus = 10;
          
          newStats.attack = user.rpg_attack + attackBonus;
          newStats.defense = user.rpg_defense + defenseBonus;
          newStats.max_health = user.rpg_max_health + healthBonus;
          newStats.health = user.rpg_max_health + healthBonus;
          newStats.level = newLevel;
          
          levelUpText = `\n\n🎊 **LEVEL UP!** Nv.${oldLevel} → Nv.${newLevel}\n+${attackBonus} ATK | +${defenseBonus} DEF | +${healthBonus} HP`;
        }
        
        await updateRPGStats(user.user_id, user.guild_id, newStats);
        
        // Rastrear missão "Caçador Iniciante" (missao_1 - 3 vitórias)
        const currentUser = await getUser(user.user_id, user.guild_id);
        if (currentUser.active_mission === 'missao_1') {
          const newProgress = await updateMissionProgress(user.user_id, user.guild_id, 'missao_1', 1);
          const isComplete = newProgress >= 3;

          if (isComplete) {
            try {
              await context.user.send({
                embeds: [new EmbedBuilder()
                  .setColor('#FFD700')
                  .setTitle('🎉 Missão Completa!')
                  .setDescription('⚔️ **Caçador Iniciante**\n\n✅ Você derroutou 3 inimigos em batalha!\n\n**Recompensas Pendentes:**\n🪙 +100 Moedas\n⭐ +50 XP\n\n*Volte ao Velho Sábio para confirmar!*')
                  .setTimestamp()
                ]
              });
            } catch (err) {
              console.log('Não foi possível enviar DM');
            }
          }
        }
        
        const xpBar = createXPBar(playerXP, newLevel);
        
        let coinField = thiefAppeared 
          ? `**💔 Um ladrão roubou suas moedas!** (Você teria ganho +${reward})`
          : `**+${actualReward}**`;
        
        const victoryEmbed = new EmbedBuilder()
          .setColor(newLevel > oldLevel ? '#FFD700' : '#00FF00')
          .setTitle(newLevel > oldLevel ? '🎊 VITÓRIA + LEVEL UP!' : '🎉 Vitória!')
          .setDescription(`Você derrotou **${enemy.emoji} ${enemy.name}** (Nv.${enemy.level})!${levelUpText}`)
          .addFields(
            { name: '⭐ XP Ganho', value: `**+${xpGained}** XP`, inline: true },
            { name: '🪙 Moedas', value: coinField, inline: true },
            { name: '❤️ Vida', value: `${user.rpg_health}/${user.rpg_max_health}`, inline: true },
            { name: '🎁 Drops', value: dropsText, inline: false },
            { name: '📊 Progresso', value: xpBar, inline: false },
            { name: '📜 Histórico', value: historyText, inline: false }
          )
          .setTimestamp();
        await context.editReply({ embeds: [victoryEmbed], components: [] });
        collector.stop();
        return;
      }

    const attackBtn = new ButtonBuilder().setCustomId('btn_attack').setLabel('⚔️ Atacar').setStyle(ButtonStyle.Danger);
    const skillBtn = new ButtonBuilder().setCustomId('btn_skill').setLabel('⚡ Habilidade').setStyle(ButtonStyle.Success);
    const defendBtn = new ButtonBuilder().setCustomId('btn_defend').setLabel('🛡️ Defender').setStyle(ButtonStyle.Primary);
    const potionBtn = new ButtonBuilder().setCustomId('btn_potion').setLabel('💊 Usar Poção').setStyle(ButtonStyle.Secondary);
    const row = new ActionRowBuilder().addComponents(attackBtn, skillBtn, defendBtn, potionBtn);

    if (playerTurn) {
      await context.editReply({ embeds: [createBattleEmbed(user, enemy, turn, battleLog, playerLevel, playerXP, skillActive)], components: [row] });
    } else {
      let damage = calculateEnemyDamage(enemy, user, playerLevel, defenseBoost);
      
      if (enemy.poison > 0) {
        battleLog.push(`🩸 ${enemy.name} sofre com o veneno! -${enemy.poison} HP`);
        enemy.health = Math.max(0, enemy.health - enemy.poison);
      }
      
      user.rpg_health = Math.max(0, user.rpg_health - damage);
      battleLog.push(`${enemy.name} atacou! ${getDamageEmoji(damage)} -${damage} HP`);
      
      defenseBoost = 1;
      skillActive = null;
      turn++;
      playerTurn = true;
      await context.editReply({ embeds: [createBattleEmbed(user, enemy, turn, battleLog, playerLevel, playerXP, skillActive)], components: [row] });
    }
  }

    collector.on('collect', async (btnInteraction) => {
      try {
        await btnInteraction.deferUpdate();
      } catch (err) {
        console.error('Erro ao defer update:', err);
        return;
      }

      if (!playerTurn) return;

      if (btnInteraction.customId === 'btn_attack') {
        let damage = calculatePlayerDamage(user, enemy, playerLevel);
        const isCritical = checkCriticalHit(playerLevel);
        
        if (isCritical) {
          damage = Math.floor(damage * 1.8);
          battleLog.push(`${user.character_name} atacou! 💥 **CRÍTICO!** -${damage} HP`);
        } else {
          battleLog.push(`${user.character_name} atacou! ${getDamageEmoji(damage)} -${damage} HP`);
        }
        
        enemy.health = Math.max(0, enemy.health - damage);
        skillActive = null;
        playerTurn = false;
      } 
      else if (btnInteraction.customId === 'btn_skill') {
        const skillResult = tryUseSkill(user, enemy, user.rpg_class, battleLog);
        
        if (skillResult.damage > 0) {
          enemy.health = Math.max(0, enemy.health - skillResult.damage);
        }
        if (skillResult.healing > 0) {
          user.rpg_health = Math.min(user.rpg_max_health, user.rpg_health + skillResult.healing);
        }
        if (skillResult.defenseBoost) {
          defenseBoost = skillResult.defenseBoost;
        }
        skillActive = skillResult.effect;
        playerTurn = false;
        turn++;
      }
      else if (btnInteraction.customId === 'btn_defend') {
        battleLog.push(`${user.character_name} se defendeu! 🛡️`);
        const reducedDamage = Math.max(3, Math.floor(calculateEnemyDamage(enemy, user, playerLevel) * 0.4));
        user.rpg_health = Math.max(0, user.rpg_health - reducedDamage);
        battleLog.push(`${enemy.name} atacou reduzido! -${reducedDamage} HP`);
        skillActive = null;
        playerTurn = false;
        turn++;
      }
      else if (btnInteraction.customId === 'btn_potion') {
        const inventory = await getInventory(user.user_id, user.guild_id);
        const potion = inventory.find(i => i.item_id === 'pocao_cura' && i.quantity > 0);
        
        if (!potion) {
          await btnInteraction.followUp({ content: '❌ Você não tem Poção de Cura!', ephemeral: true });
          return;
        }
        
        // Usar poção
        const healAmount = 50;
        const oldHealth = user.rpg_health;
        user.rpg_health = Math.min(user.rpg_max_health, user.rpg_health + healAmount);
        await updateInventory(user.user_id, user.guild_id, 'pocao_cura', -1);
        
        battleLog.push(`${user.character_name} usou Poção de Cura! ❤️ +${healAmount} HP (${oldHealth} → ${user.rpg_health})`);
        
        // 25% de chance do inimigo se curar também
        if (Math.random() < 0.25) {
          const enemyHealAmount = 30;
          const oldEnemyHealth = enemy.health;
          enemy.health = Math.min(enemy.max_health, enemy.health + enemyHealAmount);
          battleLog.push(`✨ O ${enemy.name} também se curou! +${enemyHealAmount} HP (${oldEnemyHealth} → ${enemy.health})`);
        }
        
        skillActive = null;
        playerTurn = false;
        turn++;
      }

      await continueBattle();
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await updateRPGStats(user.user_id, user.guild_id, { health: user.rpg_health });
        
        const inventory = await getInventory(user.user_id, user.guild_id);
        const luckyItem = inventory.find(i => i.item_id === 'buff_lucky' && i.quantity > 0);
        if (luckyItem) {
          await updateInventory(user.user_id, user.guild_id, 'buff_lucky', -1);
        }
        
        const timeoutEmbed = new EmbedBuilder()
          .setColor('#FFA500')
          .setTitle('⏰ Batalha Encerrada')
          .setDescription('Você fugiu da batalha por inatividade.');
        await context.editReply({ embeds: [timeoutEmbed], components: [] }).catch(() => {});
      }
    });

    await continueBattle();
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lutar')
    .setDescription('Inicie uma batalha contra um inimigo'),
  async execute(interaction, client) {
    return startBattle(interaction, client);
  },
  async prefixExecute(message, args, client) {
    return startBattle(message, client);
  }
};
