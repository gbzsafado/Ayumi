const { SlashCommandBuilder, EmbedBuilder, version } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('Mostra informações detalhadas sobre o bot'),
  async execute(interaction, client) {
    const uptime = formatUptime(client.uptime);
    const commandCount = client.commands.size;
    
    const creationDate = client.user.createdAt;
    const now = new Date();
    const daysAgo = Math.floor((now - creationDate) / (1000 * 60 * 60 * 24));
    const createdAt = `${creationDate.toLocaleDateString('pt-BR')} (há ${daysAgo} ${daysAgo === 1 ? 'dia' : 'dias'})`;
    const creator = '<@1275126713592053780>';
    
    const embed = new EmbedBuilder()
      .setColor(0xFF00FF)
      .setTitle('📊 Informações do Bot')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '👤 Nome do Bot', value: `${client.user.tag}`, inline: true },
        { name: '🎮 ID', value: `${client.user.id}`, inline: true },
        { name: '⏰ Uptime', value: uptime, inline: true },
        { name: '🖥️ Servidores', value: `${client.guilds.cache.size}`, inline: true },
        { name: '👥 Usuários', value: `${client.users.cache.size}`, inline: true },
        { name: '📝 Comandos', value: `${commandCount}`, inline: true },
        { name: '📚 Discord.js', value: `v${version}`, inline: true },
        { name: '🔧 Node.js', value: process.version, inline: true },
        { name: '📅 Data de Criação', value: createdAt, inline: true },
        { name: '👨‍💻 Criador', value: creator, inline: true },
        { name: '💫 Status', value: '✅ Online', inline: true },
      )
      .setFooter({ 
        text: `Solicitado por ${interaction.user.username}`, 
        iconURL: interaction.user.displayAvatarURL({ dynamic: true }) 
      })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};

function formatUptime(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  if (seconds > 0) parts.push(`${seconds}s`);

  return parts.join(' ') || '0s';
}
