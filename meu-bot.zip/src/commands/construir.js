const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFazenda, updateFazenda, getConstrucoes, construir, upgradarConstrucao } = require('../fazenda/database');
const { CONSTRUCOES } = require('../fazenda/data');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('construir')
    .setDescription('Construa ou melhore uma construção na fazenda')
    .addStringOption(option =>
      option.setName('construcao')
        .setDescription('Tipo de construção')
        .setRequired(true)
        .addChoices(
          { name: '🏡 Galinheiro (2000🪙)', value: 'galinheiro' },
          { name: '🏠 Celeiro (5000🪙)', value: 'celeiro' },
          { name: '🏗️ Estufa (10000🪙)', value: 'estufa' },
          { name: '🏭 Silo (8000🪙)', value: 'silo' },
          { name: '⚙️ Moinho (15000🪙)', value: 'moinho' },
          { name: '🧀 Queijaria (20000🪙)', value: 'queijaria' },
          { name: '🔧 Oficina (25000🪙)', value: 'oficina' },
          { name: '👨‍🍳 Cozinha (12000🪙)', value: 'cozinha' },
          { name: '🍷 Destilaria (30000🪙)', value: 'destilaria' },
          { name: '🌡️ Secador (8000🪙)', value: 'secador' },
          { name: '🔬 Laboratório (50000🪙)', value: 'laboratorio' },
          { name: '🏪 Mercado (40000🪙)', value: 'mercado' },
          { name: '🏦 Banco (75000🪙)', value: 'banco' },
          { name: '🚜 Trator (100000🪙)', value: 'trator' },
          { name: '🏘️ Casa (50000🪙)', value: 'casa' }
        )),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const construcaoTipo = interaction.options.getString('construcao');

    const fazenda = await getFazenda(userId, guildId);
    const construcoes = await getConstrucoes(userId, guildId);
    const construcaoData = CONSTRUCOES[construcaoTipo];

    if (!construcaoData) {
      return interaction.reply({ content: '❌ Construção inválida!', ephemeral: true });
    }

    const existente = construcoes.find(c => c.construcao_tipo === construcaoTipo);
    
    if (existente) {
      if (existente.nivel >= construcaoData.max_nivel) {
        return interaction.reply({ content: `❌ ${construcaoData.emoji} ${construcaoData.nome} já está no nível máximo (${construcaoData.max_nivel})!`, ephemeral: true });
      }

      const custoUpgrade = Math.floor(construcaoData.preco_base * Math.pow(construcaoData.upgrade_multiplicador, existente.nivel));
      
      if (fazenda.moedas_fazenda < custoUpgrade) {
        return interaction.reply({ content: `❌ Moedas insuficientes para upgrade! Você tem 🪙 ${fazenda.moedas_fazenda} e precisa de 🪙 ${custoUpgrade}`, ephemeral: true });
      }

      await updateFazenda(userId, guildId, {
        moedas_fazenda: fazenda.moedas_fazenda - custoUpgrade
      });

      await upgradarConstrucao(userId, guildId, construcaoTipo);

      const novoNivel = existente.nivel + 1;
      let bonusTexto = '';

      if (construcaoData.capacidade_animais) {
        bonusTexto = `🐾 Capacidade: ${construcaoData.capacidade_animais * novoNivel} animais`;
      } else if (construcaoData.capacidade_armazenamento) {
        bonusTexto = `📦 Armazenamento: ${construcaoData.capacidade_armazenamento * novoNivel} itens`;
      } else if (construcaoData.slots_planta) {
        bonusTexto = `🌱 Slots de estufa: ${construcaoData.slots_planta * novoNivel}`;
      }

      const embed = new EmbedBuilder()
        .setColor('#9B59B6')
        .setTitle(`${construcaoData.emoji} Upgrade Realizado!`)
        .setDescription(`
**${construcaoData.nome}** melhorado para nível ${novoNivel}!

💰 **Custo:** 🪙 ${custoUpgrade}
${bonusTexto}
        `)
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (fazenda.moedas_fazenda < construcaoData.preco_base) {
      return interaction.reply({ content: `❌ Moedas insuficientes! Você tem 🪙 ${fazenda.moedas_fazenda} e precisa de 🪙 ${construcaoData.preco_base}`, ephemeral: true });
    }

    await updateFazenda(userId, guildId, {
      moedas_fazenda: fazenda.moedas_fazenda - construcaoData.preco_base
    });

    await construir(userId, guildId, construcaoTipo);

    let bonusTexto = '';
    if (construcaoData.capacidade_animais) {
      bonusTexto = `🐾 Capacidade: ${construcaoData.capacidade_animais} animais`;
    } else if (construcaoData.capacidade_armazenamento) {
      bonusTexto = `📦 Armazenamento: ${construcaoData.capacidade_armazenamento} itens`;
    } else if (construcaoData.bonus) {
      bonusTexto = `✨ Bônus: ${construcaoData.bonus}`;
    } else if (construcaoData.receitas) {
      bonusTexto = `📜 Receitas: ${Array.isArray(construcaoData.receitas) ? construcaoData.receitas.join(', ') : construcaoData.receitas}`;
    }

    if (construcaoTipo === 'estufa') {
      await updateFazenda(userId, guildId, {
        slots_plantio: fazenda.slots_plantio + 6
      });
      bonusTexto += `\n🌱 +6 slots de plantio (ignoram estação!)`;
    }

    const embed = new EmbedBuilder()
      .setColor('#27AE60')
      .setTitle(`${construcaoData.emoji} Nova Construção!`)
      .setDescription(`
Você construiu: **${construcaoData.nome}**!

💰 **Custo:** 🪙 ${construcaoData.preco_base}
${bonusTexto}

Use \`/construir ${construcaoTipo}\` novamente para melhorar (máx nível ${construcaoData.max_nivel})
      `)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
