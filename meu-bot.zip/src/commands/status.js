const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../database');

function calculateLevel(xp) {
  return Math.floor(xp / 100) + 1;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Mostra o status do seu personagem RPG'),
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);

    if (!user.rpg_class) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Erro')
          .setDescription('Use `/registrar` primeiro!')
        ],
        ephemeral: true
      });
    }

    const health = Number(user.rpg_health) || 0;
    const maxHealth = Number(user.rpg_max_health) || 100;
    const attack = Number(user.rpg_attack) || 50;
    const defense = Number(user.rpg_defense) || 30;
    const mobility = Number(user.rpg_mobility) || 50;
    const moedas = Number(user.moedas) || 0;
    const xp = Number(user.rpg_exp) || 0;
    const level = calculateLevel(xp);
    const xpInLevel = xp - ((level - 1) * 100);
    const xpNeeded = 100;

    function createHealthBar(current, max) {
      const percentage = Math.max(0, (current / max) * 100);
      const filled = Math.floor(percentage / 10);
      const empty = 10 - filled;
      const bar = '█'.repeat(filled) + '░'.repeat(empty);
      if (percentage > 50) return `🟩 ${bar}`;
      if (percentage > 25) return `🟨 ${bar}`;
      return `🟥 ${bar}`;
    }

    function createXPBar(current, needed) {
      const percentage = Math.min(100, (current / needed) * 100);
      const filled = Math.floor(percentage / 10);
      const empty = 10 - filled;
      return `⭐ ${'▰'.repeat(filled)}${'▱'.repeat(empty)}`;
    }

    const classEmojis = {
      'Guerreiro': '⚔️',
      'Mago': '🔮',
      'Assassino': '🗡️',
      'Tanque': '🛡️',
      'Arqueiro': '🏹'
    };

    const classEmoji = classEmojis[user.rpg_class] || '👤';
    const healthBar = createHealthBar(health, maxHealth);
    const xpBar = createXPBar(xpInLevel, xpNeeded);

    const embed = new EmbedBuilder()
      .setColor('#FF6B6B')
      .setTitle(`${classEmoji} Status de ${user.character_name}`)
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '⚔️ Classe', value: `\`${user.rpg_class}\``, inline: true },
        { name: '⭐ Nível', value: `\`${level}\``, inline: true },
        { name: '🪙 Moedas', value: `\`${moedas.toLocaleString('pt-BR')}\``, inline: true },
        { name: '❤️ Saúde', value: `${healthBar}\n\`${health}/${maxHealth} HP\``, inline: false },
        { name: '📊 Experiência', value: `${xpBar}\n\`${xpInLevel}/${xpNeeded} XP\``, inline: false },
        { name: '⚡ Ataque', value: `\`${attack}\``, inline: true },
        { name: '🛡️ Defesa', value: `\`${defense}\``, inline: true },
        { name: '💨 Velocidade', value: `\`${mobility}\``, inline: true }
      )
      .setFooter({ text: `XP Total: ${xp} | Use /lutar para batalhar!` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
