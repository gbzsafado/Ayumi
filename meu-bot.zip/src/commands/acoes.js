const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const ACTIONS = {
  tapa: { emoji: '👋', color: '#FF4444', texto: 'levou um tapa de' },
  beijo: { emoji: '💋', color: '#FF69B4', texto: 'recebeu um beijo de' },
  abraço: { emoji: '🤗', color: '#00CCFF', texto: 'recebeu um abraço de' },
  cafuné: { emoji: '✋', color: '#FFD700', texto: 'recebeu um cafuné de' },
  soco: { emoji: '👊', color: '#FF0000', texto: 'levou um soco de' },
  mordida: { emoji: '🦷', color: '#8B4513', texto: 'foi mordido(a) por' },
  poke: { emoji: '👉', color: '#FF8C00', texto: 'foi puxado(a) por' },
  bully: { emoji: '😈', color: '#FFB6C1', texto: 'foi zoado(a) por' },
  dança: { emoji: '💃', color: '#FF1493', texto: 'dançou com' },
  piscada: { emoji: '😉', color: '#FFFF00', texto: 'recebeu uma piscada de' }
};

async function getWaifuGif(action) {
  try {
    const response = await axios.get(`https://api.waifu.pics/sfw/${action}`);
    return response.data.url;
  } catch (error) {
    console.log(`Erro ao buscar GIF de ${action}:`, error.message);
    return null;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tapa')
    .setDescription('Dê um tapa em alguém!')
    .addUserOption(option =>
      option.setName('alvo')
        .setDescription('Quem vai levar o tapa?')
        .setRequired(true)
    ),
  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');
    
    if (alvo.id === interaction.user.id) {
      return interaction.reply({ content: '❌ Você não pode fazer isso consigo mesmo!', ephemeral: true });
    }
    
    if (alvo.bot) {
      return interaction.reply({ content: '❌ Não posso levar tapas! 😢', ephemeral: true });
    }

    const gif = await getWaifuGif('slap');
    if (!gif) {
      return interaction.reply({ content: '❌ Erro ao buscar GIF, tente novamente!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(ACTIONS.tapa.color)
      .setTitle(`${ACTIONS.tapa.emoji} ${interaction.user.username} ${ACTIONS.tapa.texto} ${alvo.username}!`)
      .setImage(gif)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
