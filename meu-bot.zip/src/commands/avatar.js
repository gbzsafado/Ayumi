const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Mostra o avatar de um usuário')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('O usuário para ver o avatar')
        .setRequired(false)),
  async execute(interaction, client) {
    const user = interaction.options.getUser('usuario') || interaction.user;
    
    const embed = new EmbedBuilder()
      .setColor(0xFF00FF)
      .setTitle(`Avatar de ${user.tag}`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
