const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, getGuardian, updateGuardianAfinidade, updateGuardianLastAffection } = require('../database');
const { GUARDIAN_TYPES } = require('./guardiao');

const MESSAGES = ['😊 Ficou feliz!', '💕 Se sente amado!', '🥰 Ronrona feliz!', '😍 Pulou de alegria!', '✨ Brilha!'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('carinho')
    .setDescription('Dê carinho ao seu Guardião Mirim (+1% afinidade)!'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    
    const guardian = await getGuardian(userId, guildId);
    
    if (!guardian) {
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor('#FF0000').setTitle('❌ Sem Guardião!')],
        ephemeral: true
      });
    }
    
    const COOLDOWN = 10 * 60 * 1000;
    const now = new Date();
    const lastAffection = guardian.last_affection ? new Date(guardian.last_affection) : null;
    
    if (lastAffection && now - lastAffection < COOLDOWN) {
      const remaining = Math.ceil((COOLDOWN - (now - lastAffection)) / 60000);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor('#FFA500').setTitle('⏰ Guardião Satisfeito').setDescription(`Próximo carinho em ${remaining}m`)],
        ephemeral: true
      });
    }
    
    await updateGuardianAfinidade(userId, guildId, 1);
    await updateGuardianLastAffection(userId, guildId);
    
    const updated = await getGuardian(userId, guildId);
    const type = GUARDIAN_TYPES[guardian.guardian_type];
    const emoji = type.evolutionEmojis[updated.evolution_stage - 1];
    
    let desc = `${MESSAGES[Math.floor(Math.random() * MESSAGES.length)]}\n❤️ Afinidade: ${updated.afinidade}%`;
    if (updated.afinidade >= 75 && !guardian.traits && updated.traits) desc += `\n\n🌟 TRAIT DESBLOQUEADO!\n${updated.traits}`;
    if (updated.afinidade >= 100 && !guardian.talento_especial && updated.talento_especial) desc += `\n\n✨ TALENTO DESBLOQUEADO!\n${updated.talento_especial}`;
    
    return interaction.reply({
      embeds: [new EmbedBuilder().setColor('#FF69B4').setTitle(`${emoji} Carinho`).setDescription(desc)]
    });
  }
};
