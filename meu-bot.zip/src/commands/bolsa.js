const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser } = require('../database');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const STOCKS = {
  'CRIS': { name: 'Cristal Corp', basePrice: 1000 },
  'MINA': { name: 'Mina Ouro', basePrice: 800 },
  'FORT': { name: 'Fortuna Inc', basePrice: 1200 },
  'MAGI': { name: 'Magia Ltd', basePrice: 1500 },
  'DRAC': { name: 'Draconium Co', basePrice: 2000 }
};

async function getOrCreateStockPrice(guildId, symbol) {
  const result = await pool.query(
    'SELECT * FROM stock_prices WHERE guild_id = $1 AND stock_symbol = $2',
    [guildId, symbol]
  );

  if (result.rows.length === 0) {
    const basePrice = STOCKS[symbol].basePrice;
    await pool.query(
      'INSERT INTO stock_prices (guild_id, stock_symbol, current_price) VALUES ($1, $2, $3)',
      [guildId, symbol, basePrice]
    );
    return basePrice;
  }

  return result.rows[0].current_price;
}

async function getUserStocks(userId, guildId) {
  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2',
    [userId, guildId]
  );
  return result.rows;
}

async function buyStock(userId, guildId, symbol, quantity) {
  const price = await getOrCreateStockPrice(guildId, symbol);
  const cost = price * quantity;

  const user = await getUser(userId, guildId);
  if (user.cristais < cost) {
    return { success: false, message: 'Cristais insuficientes!' };
  }

  await pool.query('UPDATE users SET cristais = cristais - $1 WHERE user_id = $2 AND guild_id = $3', [cost, userId, guildId]);

  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3',
    [userId, guildId, symbol]
  );

  if (result.rows.length === 0) {
    await pool.query(
      'INSERT INTO user_stocks (user_id, guild_id, stock_symbol, quantity) VALUES ($1, $2, $3, $4)',
      [userId, guildId, symbol, quantity]
    );
  } else {
    await pool.query(
      'UPDATE user_stocks SET quantity = quantity + $1 WHERE user_id = $2 AND guild_id = $3 AND stock_symbol = $4',
      [quantity, userId, guildId, symbol]
    );
  }

  return { success: true, cost };
}

async function sellStock(userId, guildId, symbol, quantity) {
  const price = await getOrCreateStockPrice(guildId, symbol);
  const result = await pool.query(
    'SELECT * FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3',
    [userId, guildId, symbol]
  );

  if (result.rows.length === 0 || result.rows[0].quantity < quantity) {
    return { success: false, message: 'Você não tem essa quantidade de ações!' };
  }

  const profit = price * quantity;
  await pool.query('UPDATE users SET cristais = cristais + $1 WHERE user_id = $2 AND guild_id = $3', [profit, userId, guildId]);

  if (result.rows[0].quantity === quantity) {
    await pool.query('DELETE FROM user_stocks WHERE user_id = $1 AND guild_id = $2 AND stock_symbol = $3', [userId, guildId, symbol]);
  } else {
    await pool.query(
      'UPDATE user_stocks SET quantity = quantity - $1 WHERE user_id = $2 AND guild_id = $3 AND stock_symbol = $4',
      [quantity, userId, guildId, symbol]
    );
  }

  return { success: true, profit };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bolsa')
    .setDescription('Sistema de bolsa de valores em cristais')
    .addSubcommand(subcommand =>
      subcommand
        .setName('ver')
        .setDescription('Ver ações disponíveis'))
    .addSubcommand(subcommand =>
      subcommand
        .setName('comprar')
        .setDescription('Comprar ações')
        .addStringOption(option =>
          option.setName('simbolo')
            .setDescription('Símbolo da ação (CRIS, MINA, FORT, MAGI, DRAC)')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('quantidade')
            .setDescription('Quantidade de ações')
            .setRequired(true)
            .setMinValue(1)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('vender')
        .setDescription('Vender ações')
        .addStringOption(option =>
          option.setName('simbolo')
            .setDescription('Símbolo da ação')
            .setRequired(true))
        .addIntegerOption(option =>
          option.setName('quantidade')
            .setDescription('Quantidade de ações')
            .setRequired(true)
            .setMinValue(1)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('carteira')
        .setDescription('Ver sua carteira de ações')),
  async execute(interaction, client) {
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'ver') {
      const prices = {};
      for (const symbol in STOCKS) {
        prices[symbol] = await getOrCreateStockPrice(guildId, symbol);
      }

      const stockList = Object.entries(prices)
        .map(([symbol, price]) => `\`${symbol}\` - ${STOCKS[symbol].name}: **${price.toLocaleString('pt-BR')}** 💎`)
        .join('\n');

      const embed = new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('📈 Bolsa de Valores')
        .setDescription('Preços das ações disponíveis:')
        .addFields(
          { name: '🏢 Ações', value: stockList, inline: false },
          { name: 'Comandos', value: '`/bolsa comprar` - Comprar ações\n`/bolsa vender` - Vender ações\n`/bolsa carteira` - Ver sua carteira', inline: false }
        )
        .setFooter({ text: 'Preços mudam a cada atividade!' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (subcommand === 'comprar') {
      const symbol = interaction.options.getString('simbolo').toUpperCase();
      const quantity = interaction.options.getInteger('quantidade');

      if (!STOCKS[symbol]) {
        return interaction.reply({ content: '❌ Símbolo inválido! Use: CRIS, MINA, FORT, MAGI ou DRAC', ephemeral: true });
      }

      const result = await buyStock(userId, guildId, symbol, quantity);
      if (!result.success) {
        return interaction.reply({ content: '❌ ' + result.message, ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('✅ Ação Comprada!')
        .addFields(
          { name: 'Ação', value: `${STOCKS[symbol].name} (${symbol})`, inline: true },
          { name: 'Quantidade', value: `${quantity}`, inline: true },
          { name: 'Custo Total', value: `${result.cost.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (subcommand === 'vender') {
      const symbol = interaction.options.getString('simbolo').toUpperCase();
      const quantity = interaction.options.getInteger('quantidade');

      if (!STOCKS[symbol]) {
        return interaction.reply({ content: '❌ Símbolo inválido!', ephemeral: true });
      }

      const result = await sellStock(userId, guildId, symbol, quantity);
      if (!result.success) {
        return interaction.reply({ content: '❌ ' + result.message, ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('✅ Ação Vendida!')
        .addFields(
          { name: 'Ação', value: `${STOCKS[symbol].name} (${symbol})`, inline: true },
          { name: 'Quantidade', value: `${quantity}`, inline: true },
          { name: 'Lucro', value: `${result.profit.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (subcommand === 'carteira') {
      const stocks = await getUserStocks(userId, guildId);

      if (stocks.length === 0) {
        return interaction.reply({ content: '❌ Você não tem nenhuma ação!', ephemeral: true });
      }

      let totalValue = 0;
      const stocksInfo = [];

      for (const stock of stocks) {
        const price = await getOrCreateStockPrice(guildId, stock.stock_symbol);
        const value = price * stock.quantity;
        totalValue += value;

        stocksInfo.push(`\`${stock.stock_symbol}\` - ${STOCKS[stock.stock_symbol].name}: ${stock.quantity}x @ ${price.toLocaleString('pt-BR')} 💎 = ${value.toLocaleString('pt-BR')} 💎`);
      }

      const embed = new EmbedBuilder()
        .setColor(0xBA55D3)
        .setTitle('💼 Sua Carteira')
        .setDescription(stocksInfo.join('\n'))
        .addFields(
          { name: 'Valor Total', value: `${totalValue.toLocaleString('pt-BR')} 💎`, inline: false }
        )
        .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  }
};
