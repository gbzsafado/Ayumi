const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { getUser, getInventory, updateInventory } = require('../database');

const CRAFTS = {
  guerreiro: {
    name: '⚔️ Armaduras',
    items: [
      { id: 'armadura_ferro', name: 'Armadura de Ferro (x1)', requires: { ferro: 5, madeira: 50 }, defense: 15, quantity: 1 },
      { id: 'armadura_diamante', name: 'Armadura de Diamante (x1)', requires: { diamante: 2, ferro: 8 }, defense: 30, quantity: 1 }
    ]
  },
  mago: {
    name: '🔮 Poções',
    items: [
      { id: 'pocao_cura', name: 'Poção de Cura (x3)', requires: { erva_curativa: 5, essencia_monstro: 2 }, healing: 80, quantity: 3, description: 'Recupera 80 HP' },
      { id: 'pocao_dano', name: 'Poção de Dano (x3)', requires: { presas: 3, po_magico: 2, coracao_monstro: 1 }, attackBoost: 25, duration: 3, quantity: 3, description: '+25% dano por 3 batalhas' },
      { id: 'pocao_lucky', name: 'Poção da Sorte (x1)', requires: { po_magico: 5, escama_dragao: 1, fragmento_sombrio: 3 }, lucky: true, duration: 5, quantity: 1, description: '+25% chance de drops por 5 batalhas' }
    ]
  },
  assassino: {
    name: '🗡️ Armas',
    items: [
      { id: 'adaga_ferro', name: 'Adaga de Ferro (x1)', requires: { ferro: 3, madeira: 50 }, attack: 10, quantity: 1 },
      { id: 'espada_veneno', name: 'Espada de Veneno (x1)', requires: { cobre: 4, diamante: 1 }, attack: 20, poison: true, quantity: 1 }
    ]
  },
  tanque: {
    name: '🛡️ Escudos',
    items: [
      { id: 'escudo_ferro', name: 'Escudo de Ferro (x1)', requires: { ferro: 6, madeira: 50 }, defense: 20, quantity: 1 },
      { id: 'escudo_diamante', name: 'Escudo de Diamante (x1)', requires: { diamante: 3, ferro: 10 }, defense: 40, quantity: 1 }
    ]
  },
  arqueiro: {
    name: '🏹 Flechas',
    items: [
      { id: 'flechas_simples', name: 'Flechas Simples (x5)', requires: { madeira: 50, cobre: 2 }, arrows: 5, quantity: 5 },
      { id: 'flechas_veneno', name: 'Flechas de Veneno (x5)', requires: { madeira: 50, diamante: 1 }, arrows: 5, poison: true, quantity: 5 }
    ]
  }
};

const POTION_CRAFTS = {
  name: '🧪 Poções (Todas as Classes)',
  items: [
    { id: 'pocao_cura', name: 'Poção de Cura (x3)', requires: { erva_curativa: 5, essencia_monstro: 2 }, healing: 80, quantity: 3, description: 'Recupera 80 HP' },
    { id: 'pocao_dano', name: 'Poção de Dano (x3)', requires: { presas: 3, po_magico: 2, coracao_monstro: 1 }, attackBoost: 25, duration: 3, quantity: 3, description: '+25% dano por 3 batalhas' },
    { id: 'pocao_lucky', name: 'Poção da Sorte (x1)', requires: { po_magico: 5, escama_dragao: 1, fragmento_sombrio: 3 }, lucky: true, duration: 5, quantity: 1, description: '+25% chance de drops por 5 batalhas' }
  ]
};

async function startCrafting(context, client) {
  const user = await getUser(context.user.id, context.guildId);
  
  if (!user.rpg_class) {
    return context.reply({ content: 'Use `/registrar` primeiro!', ephemeral: true });
  }

  const classKey = user.rpg_class.toLowerCase();
  const craftData = CRAFTS[classKey];
  
  if (!craftData) {
    return context.reply({ content: 'Sua classe não tem habilidades de crafting ainda!', ephemeral: true });
  }

  const classItemIds = craftData.items.map(i => i.id);
  const potionsToAdd = POTION_CRAFTS.items.filter(p => !classItemIds.includes(p.id));
  const allItems = [...craftData.items, ...potionsToAdd];

  const select = new StringSelectMenuBuilder()
    .setCustomId('craft_select')
    .setPlaceholder('Escolha um item para craftear...')
    .addOptions(
      allItems.map(item => ({
        label: item.name,
        value: item.id,
        description: `Requer: ${Object.entries(item.requires).map(([k, v]) => `${v} ${k}`).join(', ').slice(0, 50)}`
      }))
    );

  const row = new ActionRowBuilder().addComponents(select);
  const embed = new EmbedBuilder()
    .setColor('#9370DB')
    .setTitle(`${craftData.name} + 🧪 Poções`)
    .setDescription('Selecione um item para craftear\n\n**Poções estão disponíveis para todas as classes!**');

  const response = await context.reply({ embeds: [embed], components: [row], fetchReply: true });
  
  const filter = (i) => i.user.id === context.user.id && i.customId === 'craft_select';
  const collector = response.createMessageComponentCollector({ filter, time: 60000, max: 1 });

  collector.on('collect', async (selectInteraction) => {
    const itemId = selectInteraction.values[0];
    const item = allItems.find(i => i.id === itemId);
    
    if (!item) return;

    const inventory = await getInventory(context.user.id, context.guildId);
    const hasEnough = Object.entries(item.requires).every(([mat, needed]) => {
      const current = inventory.find(i => i.item_id === mat)?.quantity || 0;
      return current >= needed;
    });

    if (!hasEnough) {
      return selectInteraction.reply({ 
        content: '❌ Você não tem materiais suficientes!', 
        ephemeral: true 
      });
    }

    for (const [mat, needed] of Object.entries(item.requires)) {
      await updateInventory(context.user.id, context.guildId, mat, -needed);
    }

    await updateInventory(context.user.id, context.guildId, item.id, item.quantity);

    if (item.lucky) {
      await updateInventory(context.user.id, context.guildId, 'buff_lucky', item.duration || 5);
    }

    let effectText = '';
    if (item.healing) effectText = `❤️ Recupera ${item.healing} HP`;
    if (item.attackBoost) effectText = `⚔️ +${item.attackBoost}% dano por ${item.duration} batalhas`;
    if (item.lucky) effectText = `🍀 +25% chance de drops por ${item.duration} batalhas`;
    if (item.defense) effectText = `🛡️ +${item.defense} defesa`;
    if (item.attack) effectText = `⚔️ +${item.attack} ataque`;

    const resultEmbed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('✅ Item Craftado!')
      .setDescription(`Você craftou: **${item.name}**${effectText ? `\n\n${effectText}` : ''}`)
      .setTimestamp();

    await selectInteraction.update({ embeds: [resultEmbed], components: [] });
  });
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('habilidade')
    .setDescription('Craftar itens da sua classe'),
  async execute(interaction, client) {
    return startCrafting(interaction, client);
  },
  async prefixExecute(message, args, client) {
    return startCrafting(message, client);
  }
};
