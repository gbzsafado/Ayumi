const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getTopUsers } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ranking')
    .setDescription('Mostra o ranking de cristais do servidor'),
  async execute(interaction, client) {
    const topUsers = await getTopUsers(interaction.guild.id, 10);
    
    if (topUsers.length === 0) {
      return interaction.reply({ content: 'Ainda não há usuários no ranking!', ephemeral: true });
    }
    
    const medals = ['🥇', '🥈', '🥉'];
    
    let description = '';
    
    for (let i = 0; i < topUsers.length; i++) {
      const user = topUsers[i];
      const medal = medals[i] || `**${i + 1}.**`;
      const member = await interaction.guild.members.fetch(user.user_id).catch(() => null);
      const username = member ? member.user.tag : 'Usuário Desconhecido';
      
      description += `${medal} ${username} - \`${user.cristais.toLocaleString('pt-BR')}\` 💎\n`;
    }
    
    const embed = new EmbedBuilder()
      .setColor(0xFF00FF)
      .setTitle(`🏆 Ranking de Cristais - ${interaction.guild.name}`)
      .setDescription(description)
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: `Top ${topUsers.length} usuários` });

    await interaction.reply({ embeds: [embed] });
  },
};
