const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getUser, updateCristais } = require('../database');

const EMOJIS = ['0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
const MINE_EMOJI = '💣';
const HIDDEN_EMOJI = '🟫';

const DIFFICULTY_LEVELS = [
  { mines: 3, label: 'Fácil (3💣)', multiplier: 1.0 },
  { mines: 5, label: 'Normal (5💣)', multiplier: 1.3 },
  { mines: 7, label: 'Difícil (7💣)', multiplier: 1.9 },
  { mines: 10, label: 'Extremo (10💣)', multiplier: 2.35 },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mines')
    .setDescription('Jogue Mines e ganhe cristais com multiplicadores!')
    .addIntegerOption(option =>
      option.setName('aposta')
        .setDescription('Valor da aposta (mínimo 10)')
        .setRequired(true)
        .setMinValue(10)),
  async execute(interaction, client) {
    const bet = interaction.options.getInteger('aposta');
    const userData = await getUser(interaction.user.id, interaction.guildId);

    if (userData.cristais < bet) {
      return interaction.reply({ content: `❌ Você não tem cristais suficientes! Sua carteira: \`${userData.cristais}\` 💎`, ephemeral: true });
    }

    const difficultyEmbed = new EmbedBuilder()
      .setColor(0xBA55D3)
      .setTitle('⛏️ Escolha a Dificuldade')
      .setDescription(`Aposta: \`${bet}\` 💎`)
      .addFields(
        { name: 'Fácil', value: '3 minas - Multiplicador base: 1.0x', inline: false },
        { name: 'Normal', value: '5 minas - Multiplicador base: 1.3x', inline: false },
        { name: 'Difícil', value: '7 minas - Multiplicador base: 1.9x', inline: false },
        { name: 'Extremo', value: '10 minas - Multiplicador base: 2.35x', inline: false }
      );

    const difficultyButtons = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder().setCustomId('diff_0').setLabel('Fácil').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('diff_1').setLabel('Normal').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('diff_2').setLabel('Difícil').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('diff_3').setLabel('Extremo').setStyle(ButtonStyle.Secondary)
      );

    const response = await interaction.reply({ embeds: [difficultyEmbed], components: [difficultyButtons], fetchReply: true });

    const diffCollector = response.createMessageComponentCollector({ time: 30000 });

    diffCollector.on('collect', async (diffInteraction) => {
      if (diffInteraction.user.id !== interaction.user.id) {
        return diffInteraction.reply({ content: '❌ Você não pode usar esse botão!', ephemeral: true });
      }

      const diffIndex = parseInt(diffInteraction.customId.split('_')[1]);
      const difficulty = DIFFICULTY_LEVELS[diffIndex];
      const mineCount = difficulty.mines;
      const baseMultiplier = difficulty.multiplier;
      const safeCount = 25 - mineCount;

      const grid = createGrid(mineCount);
      let revealed = new Set();
      let gameOver = false;
      let currentMultiplier = baseMultiplier;

      const createEmbed = () => {
        let description = '';
        for (let i = 0; i < 25; i++) {
          if (revealed.has(i)) {
            description += grid[i] === 'M' ? MINE_EMOJI : EMOJIS[grid[i]];
          } else {
            description += HIDDEN_EMOJI;
          }
          if ((i + 1) % 5 === 0) description += '\n';
        }

        const safeRevealed = Array.from(revealed).filter(i => grid[i] !== 'M').length;
        currentMultiplier = baseMultiplier + safeRevealed * 0.08;

        return new EmbedBuilder()
          .setColor(gameOver ? 0xFF0000 : 0xBA55D3)
          .setTitle('⛏️ Mines')
          .setDescription(description)
          .addFields(
            { name: 'Aposta', value: `\`${bet}\` 💎`, inline: true },
            { name: 'Dificuldade', value: `\`${mineCount} 💣\``, inline: true },
            { name: 'Multiplicador', value: `\`${currentMultiplier.toFixed(2)}x\``, inline: true },
            { name: 'Ganho Potencial', value: `\`${Math.floor(bet * currentMultiplier)}\` 💎`, inline: true }
          )
          .setFooter({ text: `${safeRevealed}/${safeCount} tiles seguros | Clique nos botões para revelar` });
      };

      await diffInteraction.update({ embeds: [createEmbed()], components: [] });

      const gameButtons = createGameButtons();
      const cashoutButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder().setCustomId('mines_cashout').setLabel('Cashout 💰').setStyle(ButtonStyle.Success)
        );

      const buttonMsg = await interaction.channel.send({ components: [...gameButtons, cashoutButtons] });

      const gameCollector = buttonMsg.createMessageComponentCollector({ time: 120000 });

      gameCollector.on('collect', async (gameInteraction) => {
        if (gameInteraction.user.id !== interaction.user.id || gameOver) {
          return gameInteraction.reply({ content: '❌ Você não pode usar esse botão!', ephemeral: true });
        }

        if (gameInteraction.customId === 'mines_cashout') {
          const safeRevealed = Array.from(revealed).filter(i => grid[i] !== 'M').length;
          if (safeRevealed === 0) {
            return gameInteraction.reply({ content: '❌ Revele pelo menos um tile antes de sacar!', ephemeral: true });
          }

          gameOver = true;
          const finalMultiplier = (baseMultiplier + safeRevealed * 0.08).toFixed(2);
          const winAmount = Math.floor(bet * parseFloat(finalMultiplier));
          await updateCristais(interaction.user.id, interaction.guildId, winAmount);
          
          await response.edit({ embeds: [createEmbed().setColor(0x00FF00).addFields({ name: '💰 Sacou!', value: `Você sacou \`${winAmount}\` 💎 (${finalMultiplier}x)` })] });
          await gameInteraction.reply({ content: `✅ Você sacou \`${winAmount}\` 💎!`, ephemeral: true });
          await buttonMsg.delete().catch(() => {});
          gameCollector.stop();
          return;
        }

        const tileIndex = parseInt(gameInteraction.customId.split('_')[1]);

        if (revealed.has(tileIndex)) {
          return gameInteraction.reply({ content: '❌ Esse tile já foi revelado!', ephemeral: true });
        }

        revealed.add(tileIndex);

        if (grid[tileIndex] === 'M') {
          gameOver = true;
          await updateCristais(interaction.user.id, interaction.guildId, -bet);
          await response.edit({ embeds: [createEmbed().setColor(0xFF0000).addFields({ name: '💔 Perdeu!', value: `Bateu em uma mina! Perdeu \`${bet}\` 💎` })] });
          await gameInteraction.reply({ content: '💣 **BOOM!** Você perdeu!', ephemeral: true });
          await buttonMsg.delete().catch(() => {});
          gameCollector.stop();
        } else {
          const safeRevealed = Array.from(revealed).filter(i => grid[i] !== 'M').length;
          if (safeRevealed === safeCount) {
            gameOver = true;
            const finalMultiplier = (baseMultiplier + safeRevealed * 0.08).toFixed(2);
            const winAmount = Math.floor(bet * parseFloat(finalMultiplier));
            await updateCristais(interaction.user.id, interaction.guildId, winAmount);
            await response.edit({ embeds: [createEmbed().setColor(0x00FF00).addFields({ name: '🎉 Venceu!', value: `Ganhou \`${winAmount}\` 💎 (${finalMultiplier}x)` })] });
            await gameInteraction.reply({ content: `🎊 Parabéns! Você venceu \`${winAmount}\` 💎!`, ephemeral: true });
            await buttonMsg.delete().catch(() => {});
            gameCollector.stop();
          } else {
            await response.edit({ embeds: [createEmbed()] });
            await gameInteraction.reply({ content: `✅ Tile revelado! ${grid[tileIndex]} | Multiplicador: ${(baseMultiplier + safeRevealed * 0.08).toFixed(2)}x`, ephemeral: true });
          }
        }
      });

      diffCollector.stop();
    });
  },
};

function createGrid(mineCount) {
  const grid = Array(25).fill(0);
  
  let minesPlaced = 0;
  while (minesPlaced < mineCount) {
    const randomIndex = Math.floor(Math.random() * 25);
    if (grid[randomIndex] !== 'M') {
      grid[randomIndex] = 'M';
      minesPlaced++;
    }
  }

  for (let i = 0; i < 25; i++) {
    if (grid[i] === 'M') continue;
    let count = 0;
    const row = Math.floor(i / 5);
    const col = i % 5;

    for (let r = row - 1; r <= row + 1; r++) {
      for (let c = col - 1; c <= col + 1; c++) {
        if (r >= 0 && r < 5 && c >= 0 && c < 5) {
          if (grid[r * 5 + c] === 'M') count++;
        }
      }
    }
    grid[i] = count;
  }

  return grid;
}

function createGameButtons() {
  const rows = [];
  for (let row = 0; row < 5; row++) {
    const buttonRow = new ActionRowBuilder();
    for (let col = 0; col < 5; col++) {
      buttonRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`mine_${row * 5 + col}`)
          .setLabel('🟫')
          .setStyle(ButtonStyle.Secondary)
      );
    }
    rows.push(buttonRow);
  }
  return rows;
}
