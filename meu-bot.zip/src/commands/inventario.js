const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { getInventory, getUser, updateInventory, updateRPGStats } = require('../database');

const ITEM_EMOJI = {
  madeira: '🪵',
  ferro: '⚙️',
  cobre: '🟠',
  diamante: '💎',
  essencia_monstro: '💜',
  fragmento_osso: '🦴',
  presas: '🦷',
  fragmento_sombrio: '🖤',
  escama_dragao: '🐲',
  coracao_monstro: '❤️‍🔥',
  erva_curativa: '🌿',
  po_magico: '✨',
  pocao_cura: '❤️',
  pocao_dano: '⚔️',
  pocao_lucky: '🍀',
  buff_lucky: '🍀',
  armadura_ferro: '🛡️',
  armadura_diamante: '💎',
  adaga_ferro: '🗡️',
  espada_veneno: '☠️',
  escudo_ferro: '🛡️',
  escudo_diamante: '💠',
  flechas_simples: '🏹',
  flechas_veneno: '🏹'
};

const ITEM_NAMES = {
  madeira: 'Madeira',
  ferro: 'Ferro',
  cobre: 'Cobre',
  diamante: 'Diamante',
  essencia_monstro: 'Essência de Monstro',
  fragmento_osso: 'Fragmento de Osso',
  presas: 'Presas',
  fragmento_sombrio: 'Fragmento Sombrio',
  escama_dragao: 'Escama de Dragão',
  coracao_monstro: 'Coração de Monstro',
  erva_curativa: 'Erva Curativa',
  po_magico: 'Pó Mágico',
  pocao_cura: 'Poção de Cura',
  pocao_dano: 'Poção de Dano',
  pocao_lucky: 'Poção da Sorte',
  buff_lucky: 'Buff de Sorte (batalhas)',
  armadura_ferro: 'Armadura de Ferro',
  armadura_diamante: 'Armadura de Diamante',
  adaga_ferro: 'Adaga de Ferro',
  espada_veneno: 'Espada de Veneno',
  escudo_ferro: 'Escudo de Ferro',
  escudo_diamante: 'Escudo de Diamante',
  flechas_simples: 'Flechas Simples',
  flechas_veneno: 'Flechas de Veneno'
};

const ITEM_BONUSES = {
  pocao_cura: { heal: 50 },
  pocao_dano: { attack: 15 },
  armadura_ferro: { defense: 5 },
  armadura_diamante: { defense: 10 },
  escudo_ferro: { defense: 3 },
  escudo_diamante: { defense: 8 },
  adaga_ferro: { attack: 5 },
  espada_veneno: { attack: 10, poison: true },
  flechas_simples: { attack: 3 },
  flechas_veneno: { attack: 5, poison: true }
};

const buildInventoryEmbed = (inventory, username, user) => {
  if (inventory.length === 0) {
    return null;
  }

  const materials = [];
  const drops = [];
  const potions = [];
  const equipment = [];

  for (const item of inventory) {
    const emoji = ITEM_EMOJI[item.item_id] || '❓';
    const name = ITEM_NAMES[item.item_id] || item.item_id;
    const line = `${emoji} **${name}**: ${item.quantity}`;

    if (['madeira', 'ferro', 'cobre', 'diamante'].includes(item.item_id)) {
      materials.push(line);
    } else if (['essencia_monstro', 'fragmento_osso', 'presas', 'fragmento_sombrio', 'escama_dragao', 'coracao_monstro', 'erva_curativa', 'po_magico'].includes(item.item_id)) {
      drops.push(line);
    } else if (['pocao_cura', 'pocao_dano', 'pocao_lucky', 'buff_lucky'].includes(item.item_id)) {
      potions.push(line);
    } else {
      equipment.push(line);
    }
  }

  let description = '';
  
  if (materials.length > 0) {
    description += '⛏️ **Materiais de Mineração:**\n' + materials.join('\n') + '\n\n';
  }
  if (drops.length > 0) {
    description += '🎁 **Drops de Monstros:**\n' + drops.join('\n') + '\n\n';
  }
  if (potions.length > 0) {
    description += '🧪 **Poções e Buffs:**\n' + potions.join('\n') + '\n\n';
  }
  if (equipment.length > 0) {
    description += '⚔️ **Equipamentos:**\n' + equipment.join('\n') + '\n\n';
  }

  // Mostrar equipamento atual
  let equippedText = '';
  if (user.equipped_weapon) equippedText += `⚔️ Arma: ${ITEM_NAMES[user.equipped_weapon] || user.equipped_weapon}\n`;
  if (user.equipped_armor) equippedText += `🛡️ Armadura: ${ITEM_NAMES[user.equipped_armor] || user.equipped_armor}\n`;
  if (user.equipped_shield) equippedText += `🛡️ Escudo: ${ITEM_NAMES[user.equipped_shield] || user.equipped_shield}\n`;
  
  if (equippedText) {
    description += '\n**⚔️ Equipado:**\n' + equippedText;
  }

  const totalItems = inventory.reduce((sum, item) => sum + item.quantity, 0);
  description += `\n**Total**: ${totalItems} itens`;

  return new EmbedBuilder()
    .setColor('#3498db')
    .setTitle('📦 Inventário')
    .setDescription(description)
    .setFooter({ text: username })
    .setTimestamp();
};

const USABLE_ITEMS = ['pocao_cura', 'pocao_dano', 'pocao_lucky'];
const ARMOR_ITEMS = ['armadura_ferro', 'armadura_diamante'];
const SHIELD_ITEMS = ['escudo_ferro', 'escudo_diamante'];
const WEAPON_ITEMS = ['adaga_ferro', 'espada_veneno', 'flechas_simples', 'flechas_veneno'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('inventario')
    .setDescription('Veja seu inventário com opções de usar/equipar itens'),
  async execute(interaction, client) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const inventory = await getInventory(userId, guildId);
    const user = await getUser(userId, guildId);

    if (inventory.length === 0) {
      return interaction.reply({ content: '📦 Seu inventário está vazio! Use `/minerar` para coletar materiais.', ephemeral: true });
    }

    const embed = buildInventoryEmbed(inventory, interaction.user.username, user);
    
    // Criar menu de seleção para usar/equipar itens
    const usableInv = inventory.filter(i => 
      USABLE_ITEMS.includes(i.item_id) || 
      ARMOR_ITEMS.includes(i.item_id) || 
      SHIELD_ITEMS.includes(i.item_id) || 
      WEAPON_ITEMS.includes(i.item_id)
    );

    let components = [];
    
    if (usableInv.length > 0) {
      const selectOptions = usableInv.map(item => ({
        label: ITEM_NAMES[item.item_id],
        value: item.item_id,
        emoji: ITEM_EMOJI[item.item_id]
      }));

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('inventory_action')
        .setPlaceholder('📦 Escolha um item para usar/equipar')
        .addOptions(selectOptions);

      components.push(new ActionRowBuilder().addComponents(selectMenu));
    }

    const response = await interaction.reply({ embeds: [embed], components, fetchReply: true });

    const filter = (i) => i.user.id === userId;
    const collector = response.createMessageComponentCollector({ filter, time: 120000 });

    collector.on('collect', async (selectInteraction) => {
      const selectedItemId = selectInteraction.values[0];
      const item = inventory.find(i => i.item_id === selectedItemId);

      if (!item) {
        await selectInteraction.reply({ content: '❌ Item não encontrado!', ephemeral: true });
        return;
      }

      if (USABLE_ITEMS.includes(selectedItemId)) {
        // Usar poção
        const bonus = ITEM_BONUSES[selectedItemId];
        let result = '';

        if (bonus.heal) {
          const oldHealth = user.rpg_health;
          user.rpg_health = Math.min(user.rpg_max_health, user.rpg_health + bonus.heal);
          result = `❤️ Sua vida aumentou de **${oldHealth}** para **${user.rpg_health}**/${user.rpg_max_health}`;
        }
        if (bonus.attack) {
          result = `⚔️ Seu ataque foi aumentado em **${bonus.attack}** dano!`;
        }

        await updateRPGStats(userId, guildId, { health: user.rpg_health });
        await updateInventory(userId, guildId, selectedItemId, -1);

        const useEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle(`✅ ${ITEM_NAMES[selectedItemId]} usada!`)
          .setDescription(result)
          .setTimestamp();

        await selectInteraction.reply({ embeds: [useEmbed], ephemeral: false });
      } else if (ARMOR_ITEMS.includes(selectedItemId)) {
        // Equipar armadura
        const bonus = ITEM_BONUSES[selectedItemId].defense;
        const oldArmor = user.equipped_armor;
        
        user.equipped_armor = selectedItemId;
        user.armor_bonus = bonus;
        
        if (oldArmor) {
          await updateInventory(userId, guildId, oldArmor, 1);
        }

        await updateRPGStats(userId, guildId, { equipped_armor: selectedItemId, armor_bonus: bonus });
        await updateInventory(userId, guildId, selectedItemId, -1);

        const equipEmbed = new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('🛡️ Armadura Equipada!')
          .setDescription(`Você equipou **${ITEM_NAMES[selectedItemId]}** (+${bonus} DEF)`)
          .setTimestamp();

        await selectInteraction.reply({ embeds: [equipEmbed], ephemeral: false });
      } else if (SHIELD_ITEMS.includes(selectedItemId)) {
        // Equipar escudo
        const bonus = ITEM_BONUSES[selectedItemId].defense;
        const oldShield = user.equipped_shield;
        
        user.equipped_shield = selectedItemId;
        user.shield_bonus = bonus;
        
        if (oldShield) {
          await updateInventory(userId, guildId, oldShield, 1);
        }

        await updateRPGStats(userId, guildId, { equipped_shield: selectedItemId, shield_bonus: bonus });
        await updateInventory(userId, guildId, selectedItemId, -1);

        const equipEmbed = new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('🛡️ Escudo Equipado!')
          .setDescription(`Você equipou **${ITEM_NAMES[selectedItemId]}** (+${bonus} DEF)`)
          .setTimestamp();

        await selectInteraction.reply({ embeds: [equipEmbed], ephemeral: false });
      } else if (WEAPON_ITEMS.includes(selectedItemId)) {
        // Equipar arma
        const bonus = ITEM_BONUSES[selectedItemId].attack;
        const oldWeapon = user.equipped_weapon;
        
        user.equipped_weapon = selectedItemId;
        user.weapon_bonus = bonus;
        user.rpg_attack = (Number(user.rpg_attack) || 50) + bonus - (Number(user.weapon_bonus) || 0);
        
        if (oldWeapon) {
          await updateInventory(userId, guildId, oldWeapon, 1);
        }

        await updateRPGStats(userId, guildId, { equipped_weapon: selectedItemId, weapon_bonus: bonus });
        await updateInventory(userId, guildId, selectedItemId, -1);

        const equipEmbed = new EmbedBuilder()
          .setColor('#FFD700')
          .setTitle('⚔️ Arma Equipada!')
          .setDescription(`Você equipou **${ITEM_NAMES[selectedItemId]}** (+${bonus} ATK)`)
          .setTimestamp();

        await selectInteraction.reply({ embeds: [equipEmbed], ephemeral: false });
      }
    });

    collector.on('end', () => {
      // Coletor finalizado
    });
  },
  async prefixExecute(message, args, client) {
    const userId = message.author.id;
    const guildId = message.guildId;
    const inventory = await getInventory(userId, guildId);
    const user = await getUser(userId, guildId);

    if (inventory.length === 0) {
      return message.reply('📦 Seu inventário está vazio! Use o comando de minerar para coletar materiais.');
    }

    const embed = buildInventoryEmbed(inventory, message.author.username, user);
    await message.reply({ embeds: [embed] });
  }
};
