const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const OpenAI = require('openai').default;

const COLORS = ['#F4A6D7', '#FF69B4', '#FF1493', '#FFB6C1', '#DB7093', '#FF00FF', '#DA70D6', '#BA55D3', '#EE82EE'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ia')
    .setDescription('Chat com IA para fazer comandos e resolver dúvidas')
    .addStringOption(option =>
      option.setName('pergunta')
        .setDescription('Sua pergunta para a IA')
        .setRequired(true)),
  async execute(interaction, client) {
    if (!process.env.OPENAI_API_KEY) {
      return interaction.reply({ content: '❌ A chave da API OpenAI não foi configurada! Peça ao dono do bot para adicionar.', ephemeral: true });
    }

    await interaction.deferReply();

    try {
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      const prompt = interaction.options.getString('pergunta');

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'Você é um assistente IA especializado e versátil, parecido com um engenheiro de software senior. Você pode:\n\n1. Programação: Ajude com código em QUALQUER linguagem (JavaScript, Python, Java, C++, Go, Rust, TypeScript, etc)\n2. Resolução de Problemas: Analise erros, debug de código, otimizações\n3. Explicações: Conceitos técnicos, arquitetura, design patterns, best practices\n4. Dúvidas Gerais: Respostas úteis e precisas sobre qualquer tema\n5. Boas Práticas: Security, performance, código limpo\n\nSeu estilo:\n- Prático e direto, sem floreios desnecessários\n- Use blocos de código formatados com a linguagem\n- Se for código complexo, explique a lógica\n- Reconheça limitações quando existirem\n- Mantenha respostas concisas mas completas\n- Use português do Brasil\n\nContexto do Bot Discord:\n- Nome: Ayumi (Scooby Doo no Discord)\n- Plataforma: Replit com Node.js\n- Banco de dados: PostgreSQL\n\nCOMandos Disponíveis do Bot (slash commands):\nGeral: /ping, /info, /botinfo, /ajuda, /servidor, /avatar\nEconomia: /daily, /trabalhar, /atm, /pagar, /ranking\nJogos: /coinflip, /blackjack, /mines, /crime\nPerfil: /perfil, /setbio\nRPG: /registrar, /status, /lutar, /minerar, /habilidade, /aldeia, /descansar\nAdmin: /setcristal, /limpar, /ia\n\nVocê pode explicar como usar qualquer comando, ajudar a entender a mecânica do jogo, sugerir estratégias ou responder qualquer dúvida sobre o bot.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 2048,
      });

      const content = response.choices[0].message.content;
      const color = COLORS[Math.floor(Math.random() * COLORS.length)];

      const chunks = [];
      for (let i = 0; i < content.length; i += 1024) {
        chunks.push(content.slice(i, i + 1024));
      }

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle('🤖 Resposta da IA')
        .setDescription(chunks[0])
        .setFooter({ 
          text: `Pergunta de ${interaction.user.username}`,
          iconURL: interaction.user.displayAvatarURL({ dynamic: true })
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      for (let i = 1; i < chunks.length; i++) {
        const followUpEmbed = new EmbedBuilder()
          .setColor(color)
          .setDescription(chunks[i]);

        await interaction.followUp({ embeds: [followUpEmbed] });
      }

    } catch (error) {
      console.error('Erro ao chamar OpenAI:', error);
      
      if (error.status === 401) {
        return interaction.editReply('❌ Chave da API OpenAI inválida!');
      } else if (error.status === 429) {
        return interaction.editReply('⏳ Muitas requisições! Tente novamente em alguns segundos.');
      } else if (error.status === 500) {
        return interaction.editReply('❌ Erro nos servidores da OpenAI. Tente novamente mais tarde.');
      }
      
      return interaction.editReply('❌ Ocorreu um erro ao processar sua pergunta. Tente novamente!');
    }
  },
};
