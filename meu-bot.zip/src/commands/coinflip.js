const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, updateCristais } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Cara ou Coroa com apostas')
    .addStringOption(option =>
      option.setName('escolha')
        .setDescription('Escolha cara ou coroa')
        .setRequired(true)
        .addChoices(
          { name: 'Cara', value: 'cara' },
          { name: 'Coroa', value: 'coroa' }
        ))
    .addIntegerOption(option =>
      option.setName('aposta')
        .setDescription('Valor da aposta')
        .setRequired(true)
        .setMinValue(1)),
  async execute(interaction, client) {
    const choice = interaction.options.getString('escolha');
    const amount = interaction.options.getInteger('aposta');
    
    const userId = interaction.user.id;
    const guildId = interaction.guild.id;
    const userData = await getUser(userId, guildId);
    const userCristais = Number(userData.cristais);
    
    if (userCristais < amount) {
      const embed = new EmbedBuilder()
        .setColor(0xFF69B4)
        .setTitle('❌ Saldo Insuficiente!')
        .setDescription(`Você não tem cristais suficientes para essa aposta.`)
        .addFields(
          { name: '💰 Seu Saldo', value: `\`${userCristais.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💸 Valor Apostado', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    
    const result = Math.random() < 0.5 ? 'Cara' : 'Coroa';
    const userChoice = choice.charAt(0).toUpperCase() + choice.slice(1);
    const won = result === userChoice;
    
    if (won) {
      const winnings = amount * 2;
      await updateCristais(userId, guildId, winnings);
      const newBalance = userCristais + winnings;
      
      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('🎉 VITÓRIA! 🎉')
        .setDescription(`Você acertou em **${result}**!`)
        .addFields(
          { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '🏆 Ganho', value: `\`${winnings.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setFooter({ text: `Solicitado por ${interaction.user.tag}` })
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    } else {
      await updateCristais(userId, guildId, -amount);
      const newBalance = userCristais - amount;
      
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('☠️ DERROTA! ☠️')
        .setDescription(`Saiu **${result}**, você escolheu **${userChoice}**!`)
        .addFields(
          { name: '🎲 Aposta', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💸 Perdido', value: `\`${amount.toLocaleString('pt-BR')}\` 💎`, inline: true },
          { name: '💰 Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` 💎`, inline: true }
        )
        .setFooter({ text: `Solicitado por ${interaction.user.tag}` })
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    }
  },
};
