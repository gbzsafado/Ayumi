const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('limpar')
    .setDescription('Limpa mensagens do canal')
    .addIntegerOption(option =>
      option.setName('quantidade')
        .setDescription('Número de mensagens para limpar (1-100)')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    const amount = interaction.options.getInteger('quantidade');

    try {
      const deleted = await interaction.channel.bulkDelete(amount, true);
      
      const embed = new EmbedBuilder()
        .setColor(0xDA70D6)
        .setTitle('🗑️ Mensagens Apagadas')
        .setDescription(`${deleted.size} mensagens foram removidas do canal!`)
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'Ocorreu um erro ao tentar limpar as mensagens!', ephemeral: true });
    }
  },
};
