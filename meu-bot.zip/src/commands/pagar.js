const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, transferCristais } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pagar')
    .setDescription('Transfere cristais para outro usuário')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('Usuário para transferir')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('quantidade')
        .setDescription('Quantidade de cristais')
        .setRequired(true)
        .setMinValue(1)),
  async execute(interaction, client) {
    const targetUser = interaction.options.getUser('usuario');
    const amount = interaction.options.getInteger('quantidade');
    
    if (targetUser.id === interaction.user.id) {
      return interaction.reply({ content: 'Você não pode transferir cristais para si mesmo!', ephemeral: true });
    }
    
    if (targetUser.bot) {
      return interaction.reply({ content: 'Você não pode transferir cristais para um bot!', ephemeral: true });
    }
    
    const userData = await getUser(interaction.user.id, interaction.guild.id);
    const userCristais = Number(userData.cristais);
    
    if (userCristais < amount) {
      const embed = new EmbedBuilder()
        .setColor(0xDB7093)
        .setTitle('❌ Saldo Insuficiente!')
        .setDescription(`Você não tem cristais suficientes para essa transferência.`)
        .addFields(
          { name: '💰 Seu Saldo', value: `\`${userCristais.toLocaleString('pt-BR')}\` cristais`, inline: true },
          { name: '💸 Valor Solicitado', value: `\`${amount.toLocaleString('pt-BR')}\` cristais`, inline: true }
        )
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed] });
    }
    
    const result = await transferCristais(interaction.user.id, targetUser.id, interaction.guild.id, amount);
    
    if (!result.success) {
      return interaction.reply({ content: result.message, ephemeral: true });
    }
    
    const newBalance = userCristais - amount;
    
    const embed = new EmbedBuilder()
      .setColor(0xDB7093)
      .setTitle('💸 Transferência Realizada!')
      .setDescription(`Você transferiu **${amount.toLocaleString('pt-BR')}** 💎 cristais para ${targetUser}!`)
      .addFields(
        { name: '💰 Seu Novo Saldo', value: `\`${newBalance.toLocaleString('pt-BR')}\` cristais`, inline: true }
      )
      .setTimestamp()
      .setFooter({ text: `Transferência de ${interaction.user.tag}` });

    await interaction.reply({ embeds: [embed] });
  },
};
