const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { query } = require('../database');

const OWNER_ID = '1275126713592053780';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('listar-bugs')
    .setDescription('Lista todos os bugs reportados (apenas para o dono)'),

  async execute(interaction) {
    // Apenas o dono pode usar esse comando
    if (interaction.user.id !== OWNER_ID) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Acesso Negado')
          .setDescription('Apenas o dono do bot pode usar este comando.')
        ],
        ephemeral: true
      });
    }

    try {
      const result = await query('SELECT * FROM bug_reports ORDER BY timestamp DESC LIMIT 50');
      const bugs = result.rows || [];

      if (bugs.length === 0) {
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Sem Bugs')
            .setDescription('Nenhum bug foi reportado.')
          ],
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setColor('#9B59B6')
        .setTitle(`🐛 BUGS REPORTADOS (${bugs.length})`)
        .setDescription(bugs.map((bug, idx) => {
          const date = new Date(bug.timestamp).toLocaleDateString('pt-BR');
          return `**${idx + 1}. ${bug.titulo}** (${bug.username})\n${bug.descricao}\n_${date}_`;
        }).join('\n\n'))
        .setTimestamp();

      await interaction.reply({
        embeds: [embed],
        ephemeral: true
      });
    } catch (err) {
      console.error('Erro ao listar bugs:', err);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Erro')
          .setDescription('Erro ao buscar bugs.')
        ],
        ephemeral: true
      });
    }
  }
};
