const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, getGuardian } = require('../database');
const { GUARDIAN_TYPES } = require('./guardiao');

function createProgressBar(current, max) {
  const percentage = Math.min(100, (current / max) * 100);
  const filled = Math.floor(percentage / 10);
  const empty = 10 - filled;
  return '▰'.repeat(filled) + '▱'.repeat(empty);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('guardiao-info')
    .setDescription('Veja as informações completas do seu Guardião Mirim!'),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    
    const user = await getUser(userId, guildId);
    const guardian = await getGuardian(userId, guildId);
    
    if (!guardian) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('❌ Sem Guardião')
          .setDescription('Você não tem um Guardião Mirim!')
        ],
        ephemeral: true
      });
    }
    
    const type = GUARDIAN_TYPES[guardian.guardian_type];
    const stage = guardian.evolution_stage;
    const currentEvolution = type.evolutions[stage - 1];
    const currentEmoji = type.evolutionEmojis[stage - 1];
    const abilityValue = type.abilityValues[stage - 1];
    const damage = type.damages[stage - 1];
    
    const xpNeeded = guardian.level * 50;
    const xpProgress = Math.min(guardian.xp, xpNeeded);
    const xpBar = createProgressBar(xpProgress, xpNeeded);
    const afinidade = guardian.afinidade || 0;
    const afinidadeBar = createProgressBar(afinidade, 100);
    
    let nextEvolution = '';
    if (stage === 1) {
      nextEvolution = `📈 Próxima: ${type.evolutions[1]} (Nv.10)`;
    } else if (stage === 2) {
      nextEvolution = `📈 Próxima: ${type.evolutions[2]} (Nv.20)`;
    } else {
      nextEvolution = '🏆 Evolução Máxima!';
    }
    
    let traitsText = guardian.traits ? `🌟 ${guardian.traits}` : '❌ Nenhum trait (atinja 75% afinidade)';
    let talentoText = guardian.talento_especial ? `✨ ${guardian.talento_especial}` : '❌ Nenhum talento (atinja 100% afinidade)';
    
    const embed = new EmbedBuilder()
      .setColor('#9B59B6')
      .setTitle(`${currentEmoji} ${guardian.guardian_name || currentEvolution}`)
      .setDescription(`**Guardião Mirim de ${user.character_name || 'Aventureiro'}**\n${nextEvolution}`)
      .addFields(
        { name: '📊 Status', value: `Tipo: ${currentEvolution}\nNível: ${guardian.level}\nEstágio: ${stage}/3`, inline: true },
        { name: '⚔️ Atributos', value: `❤️ ${guardian.health}/${guardian.max_health}\n⚔️ ${guardian.attack}\n🛡️ ${guardian.defense}`, inline: true },
        { name: '❤️ Afinidade', value: `${afinidadeBar}\n${afinidade}%`, inline: false },
        { name: '✨ Habilidade', value: `${type.ability}: +${abilityValue}% | Dano reduzido: ${damage}%`, inline: false },
        { name: '🌟 Trait', value: traitsText, inline: true },
        { name: '✨ Talento', value: talentoText, inline: true },
        { name: '⭐ XP', value: `${xpBar}\n${xpProgress}/${xpNeeded}`, inline: false }
      )
      .setFooter({ text: 'Use /carinho, /treinar-guardiao e /batalha-dupla!' })
      .setTimestamp();
    
    return interaction.reply({ embeds: [embed] });
  }
};
