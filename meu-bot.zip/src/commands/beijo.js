const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

async function getWaifuGif(action) {
  try {
    const response = await axios.get(`https://api.waifu.pics/sfw/${action}`);
    return response.data.url;
  } catch (error) {
    return null;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('beijo')
    .setDescription('Dê um beijo em alguém! 💋')
    .addUserOption(option =>
      option.setName('alvo')
        .setDescription('Quem vai receber o beijo?')
        .setRequired(true)
    ),
  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');
    
    if (alvo.id === interaction.user.id) {
      return interaction.reply({ content: '❌ Que narcisista! 😅', ephemeral: true });
    }
    
    if (alvo.bot) {
      return interaction.reply({ content: '❌ Robôs não sentem beijos! 🤖', ephemeral: true });
    }

    const gif = await getWaifuGif('kiss');
    if (!gif) {
      return interaction.reply({ content: '❌ Erro ao buscar GIF, tente novamente!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#FF69B4')
      .setTitle(`💋 ${interaction.user.username} deu um beijo em ${alvo.username}!`)
      .setImage(gif)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
