const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, updateRPGStats } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('descansar')
    .setDescription('Descanse para recuperar sua saúde'),
  async execute(interaction, client) {
    const user = await getUser(interaction.user.id, interaction.guildId);
    
    if (!user.rpg_class) {
      return interaction.reply({ content: 'Use `/registrar` primeiro!', ephemeral: true });
    }

    const now = Date.now();
    const lastRest = user.last_rest ? new Date(user.last_rest).getTime() : 0;
    const cooldownMs = 4 * 60 * 1000;
    
    if (now - lastRest < cooldownMs) {
      const timeLeft = Math.ceil((cooldownMs - (now - lastRest)) / 1000);
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      
      const embed = new EmbedBuilder()
        .setColor('#FFA500')
        .setTitle('😴 Ainda está cansado!')
        .setDescription(`Você já descansou recentemente.\nVolte em **${minutes}m ${seconds}s**`)
        .setTimestamp();
      
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const maxHealth = Number(user.rpg_max_health) || 100;
    const currentHealth = Number(user.rpg_health) || 0;
    
    if (currentHealth >= maxHealth) {
      return interaction.reply({ content: '❌ Você já está com saúde máxima!', ephemeral: true });
    }

    await updateRPGStats(user.user_id, user.guild_id, { 
      health: maxHealth,
      last_rest: new Date()
    });

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('😴 Você descansou!')
      .setDescription(`Sua saúde foi **totalmente recuperada**!`)
      .addFields(
        { name: '❤️ Saúde Anterior', value: `${currentHealth}/${maxHealth}`, inline: true },
        { name: '❤️ Saúde Atual', value: `${maxHealth}/${maxHealth}`, inline: true },
        { name: '⏱️ Próximo Descanso', value: 'Em 4 minutos', inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
