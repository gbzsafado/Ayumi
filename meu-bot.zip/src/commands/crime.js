const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getUser, updateCristais, updateLastCrime } = require('../database');

const BAIL_AMOUNT = 500;
const COOLDOWN_MINUTES = 10;
const SUCCESS_REWARD_MIN = 100;
const SUCCESS_REWARD_MAX = 300;
const ARREST_CHANCE = 0.4;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('crime')
    .setDescription('Cometa um crime e tente ganhar cristais! (Risco de fiança)'),
  async execute(interaction, client) {
    const userData = await getUser(interaction.user.id, interaction.guildId);
    const now = Date.now();
    const cooldownMs = COOLDOWN_MINUTES * 60 * 1000;

    if (userData.last_crime) {
      const lastCrimeTime = new Date(userData.last_crime).getTime();
      const timeLeft = cooldownMs - (now - lastCrimeTime);

      if (timeLeft > 0) {
        const minutes = Math.ceil(timeLeft / 60000);
        const embed = new EmbedBuilder()
          .setColor(0xFF6B6B)
          .setTitle('⏳ Você está sendo procurado!')
          .setDescription(`Aguarde ${minutes} minuto${minutes > 1 ? 's' : ''} antes de cometer outro crime.`)
          .setTimestamp();
        return interaction.reply({ embeds: [embed] });
      }
    }

    const isArrested = Math.random() < ARREST_CHANCE;
    const reward = Math.floor(Math.random() * (SUCCESS_REWARD_MAX - SUCCESS_REWARD_MIN + 1)) + SUCCESS_REWARD_MIN;

    await updateLastCrime(interaction.user.id, interaction.guildId);

    const userBalance = Number(userData.cristais);

    if (isArrested) {
      if (userBalance < BAIL_AMOUNT) {
        const lostAmount = userBalance;
        await updateCristais(interaction.user.id, interaction.guildId, -lostAmount);
        const updatedUser = await getUser(interaction.user.id, interaction.guildId);
        const newBalance = Number(updatedUser.cristais);
        const embed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('👮 Você foi preso!')
          .setDescription(`Você tentou cometer um crime, mas foi **preso**!`)
          .addFields(
            { name: 'Fiança', value: `\`${BAIL_AMOUNT}\` 💎`, inline: true },
            { name: 'Seu Saldo Anterior', value: `\`${lostAmount}\` 💎`, inline: true },
            { name: 'Resultado', value: `Perdeu \`${lostAmount}\` 💎 (você não tinha o suficiente)`, inline: false },
            { name: 'Novo Saldo', value: `\`${newBalance}\` 💎`, inline: true }
          )
          .setTimestamp();
        return interaction.reply({ embeds: [embed] });
      }

      await updateCristais(interaction.user.id, interaction.guildId, -BAIL_AMOUNT);
      const updatedUser = await getUser(interaction.user.id, interaction.guildId);
      const newBalance = Number(updatedUser.cristais);
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('👮 Você foi preso!')
        .setDescription(`Você tentou cometer um crime, mas foi **preso**!`)
        .addFields(
          { name: 'Fiança Paga', value: `\`${BAIL_AMOUNT}\` 💎`, inline: true },
          { name: 'Novo Saldo', value: `\`${newBalance}\` 💎`, inline: true },
          { name: 'Moral', value: 'Tente sua sorte em outro momento! 😅', inline: false }
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    await updateCristais(interaction.user.id, interaction.guildId, reward);
    const updatedUser = await getUser(interaction.user.id, interaction.guildId);
    const newBalance = Number(updatedUser.cristais);
    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('💰 Crime Bem Sucedido!')
      .setDescription(`Você cometeu um crime e conseguiu escapar!`)
      .addFields(
        { name: 'Ganho', value: `\`${reward}\` 💎`, inline: true },
        { name: 'Novo Saldo', value: `\`${newBalance}\` 💎`, inline: true },
        { name: 'Status', value: 'Fugiu sem deixar rastros! 👻', inline: false }
      )
      .setTimestamp();
    return interaction.reply({ embeds: [embed] });
  },
};
