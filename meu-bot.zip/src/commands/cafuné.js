const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

async function getWaifuGif(action) {
  try {
    const response = await axios.get(`https://api.waifu.pics/sfw/${action}`);
    return response.data.url;
  } catch (error) {
    return null;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cafuné')
    .setDescription('Faça um cafuné em alguém! ✋')
    .addUserOption(option =>
      option.setName('alvo')
        .setDescription('Quem você quer fazer cafuné?')
        .setRequired(true)
    ),
  async execute(interaction) {
    const alvo = interaction.options.getUser('alvo');
    
    if (alvo.id === interaction.user.id) {
      return interaction.reply({ content: '🙈 Você fez cafuné em si mesmo(a)...', ephemeral: true });
    }
    
    if (alvo.bot) {
      return interaction.reply({ content: '🤖 Boa, o bot adora cafuné!', ephemeral: true });
    }

    const gif = await getWaifuGif('pat');
    if (!gif) {
      return interaction.reply({ content: '❌ Erro ao buscar GIF, tente novamente!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor('#FFD700')
      .setTitle(`✋ ${interaction.user.username} fez um cafuné em ${alvo.username}!`)
      .setImage(gif)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
