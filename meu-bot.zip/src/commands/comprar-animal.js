const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getFazenda, updateFazenda, getAnimais, getConstrucoes, adicionarAnimal } = require('../fazenda/database');
const { ANIMAIS, CONSTRUCOES } = require('../fazenda/data');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('comprar-animal')
    .setDescription('Compre um animal para sua fazenda')
    .addStringOption(option =>
      option.setName('animal')
        .setDescription('Tipo de animal')
        .setRequired(true)
        .addChoices(
          { name: '🐔 Galinha (500🪙)', value: 'galinha' },
          { name: '🦆 Pato (600🪙)', value: 'pato' },
          { name: '🐰 Coelho (800🪙)', value: 'coelho' },
          { name: '🐑 Ovelha (1500🪙)', value: 'ovelha' },
          { name: '🐷 Porco (1800🪙)', value: 'porco' },
          { name: '🐄 Vaca (2000🪙)', value: 'vaca' },
          { name: '🐐 Cabra (2500🪙)', value: 'cabra' },
          { name: '🐝 Abelha (3000🪙)', value: 'abelha' },
          { name: '🐴 Cavalo (10000🪙)', value: 'cavalo' }
        ))
    .addStringOption(option =>
      option.setName('nome')
        .setDescription('Nome do animal')
        .setMaxLength(50)),

  async execute(interaction) {
    const userId = interaction.user.id;
    const guildId = interaction.guildId;
    const animalTipo = interaction.options.getString('animal');
    const nome = interaction.options.getString('nome');

    const fazenda = await getFazenda(userId, guildId);
    const animal = ANIMAIS[animalTipo];
    const animais = await getAnimais(userId, guildId);
    const construcoes = await getConstrucoes(userId, guildId);

    if (!animal) {
      return interaction.reply({ content: '❌ Animal inválido!', ephemeral: true });
    }

    if (fazenda.moedas_fazenda < animal.preco) {
      return interaction.reply({ content: `❌ Moedas insuficientes! Você tem 🪙 ${fazenda.moedas_fazenda} e precisa de 🪙 ${animal.preco}`, ephemeral: true });
    }

    let construcaoId = null;
    let capacidadeTotal = 0;

    if (['galinha', 'pato'].includes(animalTipo)) {
      const galinheiro = construcoes.find(c => c.construcao_tipo === 'galinheiro');
      if (!galinheiro) {
        return interaction.reply({ content: '❌ Você precisa construir um **Galinheiro** primeiro! Use `/construir galinheiro`', ephemeral: true });
      }
      construcaoId = galinheiro.id;
      capacidadeTotal = CONSTRUCOES.galinheiro.capacidade_animais * galinheiro.nivel;
    } else if (animalTipo === 'abelha') {
      capacidadeTotal = 999;
    } else {
      const celeiro = construcoes.find(c => c.construcao_tipo === 'celeiro');
      if (!celeiro) {
        return interaction.reply({ content: '❌ Você precisa construir um **Celeiro** primeiro! Use `/construir celeiro`', ephemeral: true });
      }
      construcaoId = celeiro.id;
      capacidadeTotal = CONSTRUCOES.celeiro.capacidade_animais * celeiro.nivel;
    }

    const animaisNaConstrucao = animais.filter(a => a.construcao_id === construcaoId);
    if (animaisNaConstrucao.length >= capacidadeTotal) {
      return interaction.reply({ content: `❌ Sua construção está cheia! Capacidade: ${animaisNaConstrucao.length}/${capacidadeTotal}. Faça upgrade!`, ephemeral: true });
    }

    await updateFazenda(userId, guildId, {
      moedas_fazenda: fazenda.moedas_fazenda - animal.preco
    });

    await adicionarAnimal(userId, guildId, animalTipo, nome || animal.nome, construcaoId);

    const embed = new EmbedBuilder()
      .setColor('#E74C3C')
      .setTitle(`${animal.emoji} Novo Animal!`)
      .setDescription(`
Você comprou um(a) **${animal.nome}**!

🏷️ **Nome:** ${nome || animal.nome}
💰 **Custo:** 🪙 ${animal.preco}
${animal.produto ? `📦 **Produz:** ${animal.emoji_produto} ${animal.produto} a cada ${animal.tempo_producao} min` : ''}
🍖 **Alimentação:** ${animal.alimentacao}

Use \`/alimentar\` para manter seu animal feliz!
Use \`/coletar-produto\` para coletar produtos.
      `)
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
