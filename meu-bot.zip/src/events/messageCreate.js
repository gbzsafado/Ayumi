const { Events } = require('discord.js');
const { getPrefix } = require('../database');

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const prefix = await getPrefix(message.guildId);
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
      if (command.prefixExecute) {
        await command.prefixExecute(message, args, client);
      } else if (command.execute) {
        await command.execute(message, args, client);
      }
    } catch (error) {
      console.error(error);
      await message.reply({ content: '❌ Ocorreu um erro ao executar esse comando!', flags: 4096 }).catch(() => {});
    }
  },
};
