const { EmbedBuilder, Events } = require('discord.js');
const { getPrefix } = require('../database');

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    if (message.mentions.has(client.user)) {
      const prefix = await getPrefix(message.guildId);

      const embed = new EmbedBuilder()
        .setColor(0xBA55D3)
        .setTitle('👋 Olá! Sou a Ayumi ✨')
        .setDescription('Sou um bot para entreter o servidor com diversas funcionalidades!')
        .addFields(
          { name: '📌 Meu Prefixo', value: `\`${prefix}\` ou use **Slash Commands** (\`/\`)` },
          { name: 'Exemplos', value: `\`${prefix}ajuda\` - Ver todos os comandos\n\`/ajuda\` - Versão em slash command` },
          { name: '💡 Dica', value: 'Use `/ajuda` para ver tudo o que posso fazer!' }
        )
        .setTimestamp()
        .setFooter({ text: 'Ayumi Bot - Desenvolvida para diversão! 🎮' });

      await message.reply({ embeds: [embed] });
    }
  },
};
