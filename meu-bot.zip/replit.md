# Ayumi Bot - Discord Bot

## Overview
Ayumi Bot is a Discord bot built with Node.js and discord.js v14. It features a dual-economy system (crystals for normal economy, medieval coins for RPG), moderation tools, gambling games, and a complete RPG system with classes, battles, crafting, and missions.

## Current State
- **Status**: Running and connected
- **Command System**: Slash commands (/)
- **Framework**: discord.js v14

## Project Structure
```
src/
├── index.js          # Main bot file with slash command registration
├── database.js       # PostgreSQL database handler
├── commands/         # All slash commands
│   ├── ajuda.js      # Help command (Portuguese)
│   ├── aldeia.js     # Village missions (RPG)
│   ├── atm.js        # ATM/balance command
│   ├── avatar.js     # User avatar command
│   ├── blackjack.js  # Blackjack game with buttons
│   ├── bolsa.js      # Stock market system
│   ├── botinfo.js    # Bot information
│   ├── coinflip.js   # Coinflip gambling
│   ├── crime.js      # Crime command (economy)
│   ├── daily.js      # Daily rewards
│   ├── descansar.js  # Rest to recover health (RPG)
│   ├── habilidade.js # Class crafting abilities (RPG)
│   ├── help.js       # Help command (English)
│   ├── ia.js         # AI chat integration (OpenAI)
│   ├── info.js       # User info
│   ├── limpar.js     # Clear messages (moderation)
│   ├── lutar.js      # Battle system (RPG)
│   ├── minerar.js    # Mining for materials (RPG)
│   ├── mines.js      # Mines game with buttons
│   ├── pagar.js      # Pay/transfer currency
│   ├── perfil.js     # User profile
│   ├── ping.js       # Bot latency
│   ├── ranking.js    # Leaderboard
│   ├── registrar.js  # Character registration (RPG)
│   ├── servidor.js   # Server info
│   ├── setbio.js     # Set user bio
│   ├── setcristal.js # Admin: Set crystals
│   ├── status.js     # Character stats (RPG)
│   └── trabalhar.js  # Work command (economy)
└── events/           # Discord events
    ├── ready.js      # Bot ready event
    ├── mention.js    # Mention handler
    └── guildMemberAdd.js # Welcome new members
```

## Features

### Economy System (Crystals 💎)
- `/daily` - Daily rewards (500-1000 crystals)
- `/trabalhar` - Work for crystals (30min cooldown)
- `/crime` - Commit crime for crystals (risk of losing 500)
- `/atm` - Check balance
- `/pagar` - Transfer crystals to another user
- `/ranking` - Server leaderboard
- `/bolsa` - Stock market trading system

### Gambling Games
- `/coinflip` - Heads or tails betting
- `/blackjack` - Interactive blackjack with buttons
- `/mines` - Minesweeper-style game with multipliers

### RPG System (Medieval Coins 🪙)
**Character System:**
- `/registrar` - Create character, choose class
- `/status` - View character stats
- `/descansar` - Recover health (4min cooldown)

**Classes:**
- ⚔️ Guerreiro - Medium damage, high defense
- 🔮 Mago - High damage, low defense
- 🗡️ Assassino - High damage, high mobility
- 🛡️ Tanque - Low damage, very high defense
- 🏹 Arqueiro - High damage, high mobility

**Combat:**
- `/lutar` - Battle enemies, earn XP and coins
- Class abilities with 45% success rate
- Level-scaled enemies

**Crafting:**
- `/minerar` - Mine materials (5min cooldown)
- `/habilidade` - Craft class-specific items

**Missions:**
- `/aldeia` - Accept village missions for rewards

### Utility Commands
- `/ping` - Bot latency
- `/avatar` - User avatar
- `/perfil` - User profile with bio
- `/info` - User information
- `/servidor` - Server information
- `/botinfo` - Bot information
- `/setbio` - Set profile bio
- `/ajuda` - Help menu (Portuguese)
- `/help` - Help menu (English)

### Moderation
- `/limpar` - Clear messages (requires Manage Messages)

### Admin
- `/setcristal` - Set user crystals (owner only)
- `/ia` - AI chat with OpenAI GPT-4

## Database
PostgreSQL database with the following tables:
- `users` - User data, economy, RPG stats
- `guilds` - Server settings
- `inventory` - Player materials
- `stock_prices` - Stock market prices
- `user_stocks` - Player stock holdings

## Environment Variables
- `DISCORD_BOT_TOKEN` - Discord bot token (required)
- `DISCORD_CLIENT_ID` - Discord application client ID (required for slash commands)
- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key (optional, for /ia command)

## Recent Changes
- December 4, 2025: Drop system and new potions
  - Added monster drop system when defeating enemies
  - Drops include: Essência de Monstro, Fragmento de Osso, Presas, Fragmento Sombrio, Escama de Dragão, Coração de Monstro, Erva Curativa, Pó Mágico
  - Each enemy has specific drop tables with different chances
  - Removed Poção de Mana from crafting
  - Added new potions craftable by ALL classes:
    - Poção de Cura: Recovers 80 HP (requires erva_curativa + essencia_monstro)
    - Poção de Dano: +25% damage for 3 battles (requires presas + po_magico + coracao_monstro)
    - Poção da Sorte: +25% drop chance for 5 battles (requires po_magico + escama_dragao + fragmento_sombrio)
  - Lucky buff is consumed per battle (victory, defeat, or timeout)
  - Inventory now shows items organized by category: Materials, Drops, Potions, Equipment
  - Added prefix command support alongside slash commands

- December 3, 2025: Complete refactor to slash commands
  - Converted all 29 commands from prefix (ay.) to slash commands (/)
  - Removed setprefix command (not needed with slash commands)
  - Added interactive buttons for games (blackjack, mines)
  - Full RPG system implemented with 5 classes
  - Crafting system with class-specific items
  - Village missions system

## Development Notes
- The bot uses discord.js v14 with Gateway Intents
- All commands use SlashCommandBuilder format
- Interactive components (buttons, select menus) for better UX
- Health endpoint available at `/health` for uptime monitoring
- Slash commands are registered globally on bot startup
